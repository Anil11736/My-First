// Dashboard JavaScript for International Export/Import Business Management
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard components
    initializeCharts();
    initializeMetrics();
    initializeRecentActivities();
    initializeNotifications();
    setupEventListeners();

    // Auto-refresh data every 5 minutes
    setInterval(refreshDashboardData, 300000);
});

// Chart instances
let revenueChart, shipmentChart, inventoryChart, regionChart;

// Initialize all charts
function initializeCharts() {
    initializeRevenueChart();
    initializeShipmentChart();
    initializeInventoryChart();
    initializeRegionChart();
}

// Revenue Chart
function initializeRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;

    revenueChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Revenue ($)',
                data: [],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });

    loadRevenueData();
}

// Shipment Status Chart
function initializeShipmentChart() {
    const ctx = document.getElementById('shipmentChart');
    if (!ctx) return;

    shipmentChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['In Transit', 'Delivered', 'Pending', 'Delayed'],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#3b82f6',
                    '#10b981',
                    '#f59e0b',
                    '#ef4444'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    loadShipmentData();
}

// Inventory Chart
function initializeInventoryChart() {
    const ctx = document.getElementById('inventoryChart');
    if (!ctx) return;

    inventoryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Stock Level',
                data: [],
                backgroundColor: '#10b981',
                borderColor: '#059669',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    loadInventoryData();
}

// Regional Sales Chart
function initializeRegionChart() {
    const ctx = document.getElementById('regionChart');
    if (!ctx) return;

    regionChart = new Chart(ctx, {
        type: 'polarArea',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(139, 92, 246, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    loadRegionalData();
}

// Load revenue data
function loadRevenueData() {
    fetch('/api/dashboard/revenue/')
        .then(response => response.json())
        .then(data => {
            if (revenueChart) {
                revenueChart.data.labels = data.labels;
                revenueChart.data.datasets[0].data = data.values;
                revenueChart.update();
            }
        })
        .catch(error => console.error('Error loading revenue data:', error));
}

// Load shipment data
function loadShipmentData() {
    fetch('/api/dashboard/shipments/')
        .then(response => response.json())
        .then(data => {
            if (shipmentChart) {
                shipmentChart.data.datasets[0].data = data.values;
                shipmentChart.update();
            }
            updateShipmentMetrics(data);
        })
        .catch(error => console.error('Error loading shipment data:', error));
}

// Load inventory data
function loadInventoryData() {
    fetch('/api/dashboard/inventory/')
        .then(response => response.json())
        .then(data => {
            if (inventoryChart) {
                inventoryChart.data.labels = data.labels;
                inventoryChart.data.datasets[0].data = data.values;
                inventoryChart.update();
            }
        })
        .catch(error => console.error('Error loading inventory data:', error));
}

// Load regional data
function loadRegionalData() {
    fetch('/api/dashboard/regions/')
        .then(response => response.json())
        .then(data => {
            if (regionChart) {
                regionChart.data.labels = data.labels;
                regionChart.data.datasets[0].data = data.values;
                regionChart.update();
            }
        })
        .catch(error => console.error('Error loading regional data:', error));
}

// Initialize metrics
function initializeMetrics() {
    loadMetrics();
}

// Load dashboard metrics
function loadMetrics() {
    fetch('/api/dashboard/metrics/')
        .then(response => response.json())
        .then(data => {
            updateMetricCard('total-revenue', data.total_revenue, '$');
            updateMetricCard('total-shipments', data.total_shipments);
            updateMetricCard('active-customers', data.active_customers);
            updateMetricCard('pending-orders', data.pending_orders);
            updateMetricCard('monthly-growth', data.monthly_growth, '%');
            updateMetricCard('avg-delivery-time', data.avg_delivery_time, ' days');
        })
        .catch(error => console.error('Error loading metrics:', error));
}

// Update metric card
function updateMetricCard(cardId, value, suffix = '') {
    const element = document.getElementById(cardId);
    if (element) {
        const formattedValue = typeof value === 'number' ? value.toLocaleString() : value;
        element.textContent = formattedValue + suffix;

        // Add animation
        element.classList.add('metric-update');
        setTimeout(() => element.classList.remove('metric-update'), 500);
    }
}

// Update shipment metrics
function updateShipmentMetrics(data) {
    const total = data.values.reduce((sum, val) => sum + val, 0);
    const delivered = data.values[1] || 0;
    const deliveryRate = total > 0 ? ((delivered / total) * 100).toFixed(1) : 0;

    updateMetricCard('delivery-rate', deliveryRate, '%');
}

// Initialize recent activities
function initializeRecentActivities() {
    loadRecentActivities();
}

// Load recent activities
function loadRecentActivities() {
    fetch('/api/dashboard/activities/')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('recent-activities');
            if (container) {
                container.innerHTML = '';
                data.activities.forEach(activity => {
                    const activityElement = createActivityElement(activity);
                    container.appendChild(activityElement);
                });
            }
        })
        .catch(error => console.error('Error loading activities:', error));
}

// Create activity element
function createActivityElement(activity) {
    const div = document.createElement('div');
    div.className = 'activity-item d-flex align-items-center mb-3';

    const iconClass = getActivityIcon(activity.type);
    const timeAgo = formatTimeAgo(activity.timestamp);

    div.innerHTML = `
        <div class="activity-icon me-3">
            <i class="${iconClass}"></i>
        </div>
        <div class="activity-content flex-grow-1">
            <div class="activity-text">${activity.description}</div>
            <div class="activity-time text-muted small">${timeAgo}</div>
        </div>
    `;

    return div;
}

// Get activity icon
function getActivityIcon(type) {
    const icons = {
        'shipment': 'fas fa-shipping-fast text-primary',
        'order': 'fas fa-shopping-cart text-success',
        'payment': 'fas fa-credit-card text-info',
        'customer': 'fas fa-user text-warning',
        'inventory': 'fas fa-boxes text-secondary'
    };
    return icons[type] || 'fas fa-bell text-muted';
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInSeconds = Math.floor((now - time) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    return `${Math.floor(diffInSeconds / 86400)} days ago`;
}

// Initialize notifications
function initializeNotifications() {
    loadNotifications();
}

// Load notifications
function loadNotifications() {
    fetch('/api/dashboard/notifications/')
        .then(response => response.json())
        .then(data => {
            updateNotificationBadge(data.unread_count);
            populateNotificationDropdown(data.notifications);
        })
        .catch(error => console.error('Error loading notifications:', error));
}

// Update notification badge
function updateNotificationBadge(count) {
    const badge = document.getElementById('notification-badge');
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline' : 'none';
    }
}

// Populate notification dropdown
function populateNotificationDropdown(notifications) {
    const container = document.getElementById('notification-list');
    if (container) {
        container.innerHTML = '';
        notifications.forEach(notification => {
            const notificationElement = createNotificationElement(notification);
            container.appendChild(notificationElement);
        });
    }
}

// Create notification element
function createNotificationElement(notification) {
    const div = document.createElement('div');
    div.className = `dropdown-item notification-item ${notification.is_read ? '' : 'unread'}`;
    div.innerHTML = `
        <div class="notification-content">
            <div class="notification-title">${notification.title}</div>
            <div class="notification-text text-muted small">${notification.message}</div>
            <div class="notification-time text-muted small">${formatTimeAgo(notification.created_at)}</div>
        </div>
    `;

    div.addEventListener('click', () => markNotificationAsRead(notification.id));
    return div;
}

// Mark notification as read
function markNotificationAsRead(notificationId) {
    fetch(`/api/notifications/${notificationId}/read/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCsrfToken(),
            'Content-Type': 'application/json'
        }
    })
    .then(() => loadNotifications())
    .catch(error => console.error('Error marking notification as read:', error));
}

// Setup event listeners
function setupEventListeners() {
    // Refresh button
    const refreshBtn = document.getElementById('refresh-dashboard');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', refreshDashboardData);
    }

    // Date range selector
    const dateRange = document.getElementById('date-range');
    if (dateRange) {
        dateRange.addEventListener('change', handleDateRangeChange);
    }

    // Export buttons
    const exportBtns = document.querySelectorAll('.export-btn');
    exportBtns.forEach(btn => {
        btn.addEventListener('click', handleExport);
    });

    // Quick action buttons
    setupQuickActions();
}

// Handle date range change
function handleDateRangeChange(event) {
    const range = event.target.value;
    refreshDashboardData(range);
}

// Handle export
function handleExport(event) {
    const format = event.target.dataset.format;
    const type = event.target.dataset.type;

    window.open(`/api/dashboard/export/?format=${format}&type=${type}`, '_blank');
}

// Setup quick actions
function setupQuickActions() {
    const quickActions = document.querySelectorAll('.quick-action');
    quickActions.forEach(action => {
        action.addEventListener('click', handleQuickAction);
    });
}

// Handle quick action
function handleQuickAction(event) {
    const action = event.target.dataset.action;

    switch(action) {
        case 'new-shipment':
            window.location.href = '/shipments/new/';
            break;
        case 'new-customer':
            window.location.href = '/customers/new/';
            break;
        case 'new-order':
            window.location.href = '/orders/new/';
            break;
        case 'view-reports':
            window.location.href = '/reports/';
            break;
    }
}

// Refresh dashboard data
function refreshDashboardData(dateRange = null) {
    showLoadingSpinner();

    const params = dateRange ? `?range=${dateRange}` : '';

    Promise.all([
        loadRevenueData(),
        loadShipmentData(),
        loadInventoryData(),
        loadRegionalData(),
        loadMetrics(),
        loadRecentActivities(),
        loadNotifications()
    ]).then(() => {
        hideLoadingSpinner();
        showSuccessMessage('Dashboard updated successfully');
    }).catch(error => {
        hideLoadingSpinner();
        showErrorMessage('Error updating dashboard');
        console.error('Dashboard refresh error:', error);
    });
}

// Show loading spinner
function showLoadingSpinner() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) {
        spinner.style.display = 'block';
    }
}

// Hide loading spinner
function hideLoadingSpinner() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) {
        spinner.style.display = 'none';
    }
}

// Show success message
function showSuccessMessage(message) {
    showToast(message, 'success');
}

// Show error message
function showErrorMessage(message) {
    showToast(message, 'error');
}

// Show toast notification
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}-circle"></i>
            <span>${message}</span>
        </div>
    `;

    document.body.appendChild(toast);

    // Show toast
    setTimeout(() => toast.classList.add('show'), 100);

    // Hide toast after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => document.body.removeChild(toast), 300);
    }, 3000);
}

// Get CSRF token
function getCsrfToken() {
    return document.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatNumber(number) {
    return new Intl.NumberFormat('en-US').format(number);
}

function formatPercentage(value) {
    return `${value.toFixed(1)}%`;
}

// Real-time updates via WebSocket (if available)
function initializeWebSocket() {
    if (typeof WebSocket !== 'undefined') {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.host}/ws/dashboard/`;

        const socket = new WebSocket(wsUrl);

        socket.onmessage = function(event) {
            const data = JSON.parse(event.data);
            handleRealtimeUpdate(data);
        };

        socket.onclose = function() {
            console.log('WebSocket connection closed');
            // Attempt to reconnect after 5 seconds
            setTimeout(initializeWebSocket, 5000);
        };
    }
}

// Handle real-time updates
function handleRealtimeUpdate(data) {
    switch(data.type) {
        case 'metric_update':
            updateMetricCard(data.metric, data.value, data.suffix);
            break;
        case 'new_activity':
            prependActivity(data.activity);
            break;
        case 'new_notification':
            loadNotifications();
            break;
        case 'chart_update':
            refreshChart(data.chart, data.data);
            break;
    }
}

// Prepend new activity
function prependActivity(activity) {
    const container = document.getElementById('recent-activities');
    if (container) {
        const activityElement = createActivityElement(activity);
        container.insertBefore(activityElement, container.firstChild);

        // Remove last activity if more than 10
        const activities = container.children;
        if (activities.length > 10) {
            container.removeChild(activities[activities.length - 1]);
        }
    }
}

// Refresh specific chart
function refreshChart(chartName, data) {
    const charts = {
        'revenue': revenueChart,
        'shipment': shipmentChart,
        'inventory': inventoryChart,
        'region': regionChart
    };

    const chart = charts[chartName];
    if (chart) {
        chart.data = data;
        chart.update();
    }
}

// Initialize WebSocket connection
initializeWebSocket();
