// Main JavaScript file for Export-Import Business Management System
// Handles interactive features, AJAX calls, and dynamic UI updates

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeNavigation();
    initializeModals();
    initializeFormValidation();
    initializeDataTables();
    initializeCharts();
    initializeNotifications();
    initializeFileUpload();
    initializeSearchAndFilters();
    initializeShipmentTracking();
    initializeInvoiceCalculations();
});

// Navigation and Menu Handling
function initializeNavigation() {
    const navToggle = document.querySelector('.navbar-toggler');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');

    if (navToggle) {
        navToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        });
    }

    // Active menu highlighting
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
            const parentDropdown = link.closest('.dropdown');
            if (parentDropdown) {
                parentDropdown.querySelector('.dropdown-toggle').classList.add('active');
            }
        }
    });
}

// Modal Management
function initializeModals() {
    // Generic modal handler
    document.addEventListener('click', function(e) {
        if (e.target.matches('[data-bs-toggle="modal"]')) {
            const targetModal = e.target.getAttribute('data-bs-target');
            const modalElement = document.querySelector(targetModal);

            if (modalElement) {
                const modal = new bootstrap.Modal(modalElement);
                modal.show();
            }
        }
    });

    // Confirmation modals
    window.confirmAction = function(message, callback) {
        const confirmModal = document.getElementById('confirmModal');
        if (confirmModal) {
            document.getElementById('confirmMessage').textContent = message;
            const modal = new bootstrap.Modal(confirmModal);
            modal.show();

            document.getElementById('confirmButton').onclick = function() {
                callback();
                modal.hide();
            };
        }
    };
}

// Form Validation and Submission
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');

    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // AJAX form submission
    const ajaxForms = document.querySelectorAll('.ajax-form');
    ajaxForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            submitFormAjax(form);
        });
    });
}

// AJAX Form Submission
function submitFormAjax(form) {
    const formData = new FormData(form);
    const url = form.action || window.location.href;
    const method = form.method || 'POST';

    showLoading(true);

    fetch(url, {
        method: method,
        body: formData,
        headers: {
            'X-CSRFToken': getCsrfToken(),
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        showLoading(false);

        if (data.success) {
            showNotification('Success', data.message || 'Operation completed successfully', 'success');

            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            } else if (data.reload) {
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            }
        } else {
            showNotification('Error', data.message || 'An error occurred', 'error');

            if (data.errors) {
                displayFormErrors(form, data.errors);
            }
        }
    })
    .catch(error => {
        showLoading(false);
        showNotification('Error', 'Network error occurred', 'error');
        console.error('Error:', error);
    });
}

// Data Tables Initialization
function initializeDataTables() {
    const tables = document.querySelectorAll('.data-table');

    tables.forEach(table => {
        if ($.fn.DataTable.isDataTable(table)) {
            $(table).DataTable().destroy();
        }

        $(table).DataTable({
            responsive: true,
            pageLength: 25,
            order: [[0, 'desc']],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            },
            columnDefs: [
                {
                    targets: 'no-sort',
                    orderable: false
                }
            ]
        });
    });
}

// Charts and Analytics
function initializeCharts() {
    // Revenue Chart
    const revenueChart = document.getElementById('revenueChart');
    if (revenueChart) {
        loadRevenueChart();
    }

    // Shipment Status Chart
    const shipmentChart = document.getElementById('shipmentChart');
    if (shipmentChart) {
        loadShipmentChart();
    }

    // Product Category Chart
    const categoryChart = document.getElementById('categoryChart');
    if (categoryChart) {
        loadCategoryChart();
    }
}

// Load Revenue Chart
function loadRevenueChart() {
    fetch('/api/analytics/revenue/', {
        headers: {
            'X-CSRFToken': getCsrfToken(),
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Revenue',
                    data: data.values,
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error loading revenue chart:', error));
}

// Load Shipment Status Chart
function loadShipmentChart() {
    fetch('/api/analytics/shipments/', {
        headers: {
            'X-CSRFToken': getCsrfToken(),
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const ctx = document.getElementById('shipmentChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        '#28a745',
                        '#ffc107',
                        '#dc3545',
                        '#17a2b8',
                        '#6f42c1'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error loading shipment chart:', error));
}

// Notification System
function initializeNotifications() {
    // Auto-hide alerts
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });
}

// Show Notification
function showNotification(title, message, type = 'info') {
    const alertClass = {
        'success': 'alert-success',
        'error': 'alert-danger',
        'warning': 'alert-warning',
        'info': 'alert-info'
    }[type] || 'alert-info';

    const alertHtml = `
        <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
            <strong>${title}:</strong> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    const container = document.querySelector('.notifications-container') || document.querySelector('.container-fluid');
    if (container) {
        container.insertAdjacentHTML('afterbegin', alertHtml);
    }
}

// File Upload Handling
function initializeFileUpload() {
    const fileInputs = document.querySelectorAll('input[type="file"]');

    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const files = e.target.files;
            const preview = document.querySelector(`#${input.id}-preview`);

            if (preview && files.length > 0) {
                preview.innerHTML = '';

                Array.from(files).forEach(file => {
                    const fileItem = document.createElement('div');
                    fileItem.className = 'file-preview-item';
                    fileItem.innerHTML = `
                        <i class="fas fa-file"></i>
                        <span>${file.name}</span>
                        <small>(${formatFileSize(file.size)})</small>
                    `;
                    preview.appendChild(fileItem);
                });
            }
        });
    });

    // Drag and drop
    const dropZones = document.querySelectorAll('.drop-zone');
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', function(e) {
            e.preventDefault();
            zone.classList.add('drag-over');
        });

        zone.addEventListener('dragleave', function() {
            zone.classList.remove('drag-over');
        });

        zone.addEventListener('drop', function(e) {
            e.preventDefault();
            zone.classList.remove('drag-over');

            const files = e.dataTransfer.files;
            const input = zone.querySelector('input[type="file"]');
            if (input && files.length > 0) {
                input.files = files;
                input.dispatchEvent(new Event('change'));
            }
        });
    });
}

// Search and Filters
function initializeSearchAndFilters() {
    // Live search
    const searchInputs = document.querySelectorAll('.live-search');
    searchInputs.forEach(input => {
        let timeout;
        input.addEventListener('input', function() {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                performLiveSearch(input);
            }, 300);
        });
    });

    // Filter forms
    const filterForms = document.querySelectorAll('.filter-form');
    filterForms.forEach(form => {
        form.addEventListener('change', function() {
            submitFilterForm(form);
        });
    });
}

// Perform Live Search
function performLiveSearch(input) {
    const query = input.value.trim();
    const targetTable = input.getAttribute('data-target');

    if (targetTable) {
        const table = document.querySelector(targetTable);
        if (table && $.fn.DataTable.isDataTable(table)) {
            $(table).DataTable().search(query).draw();
        }
    }
}

// Shipment Tracking
function initializeShipmentTracking() {
    const trackingForms = document.querySelectorAll('.tracking-form');

    trackingForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const trackingNumber = form.querySelector('input[name="tracking_number"]').value;
            trackShipment(trackingNumber);
        });
    });

    // Auto-refresh tracking status
    const trackingContainers = document.querySelectorAll('.tracking-container');
    trackingContainers.forEach(container => {
        const shipmentId = container.getAttribute('data-shipment-id');
        if (shipmentId) {
            setInterval(() => {
                updateTrackingStatus(shipmentId);
            }, 30000); // Update every 30 seconds
        }
    });
}

// Track Shipment
function trackShipment(trackingNumber) {
    showLoading(true);

    fetch(`/api/shipments/track/${trackingNumber}/`, {
        headers: {
            'X-CSRFToken': getCsrfToken(),
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        showLoading(false);

        if (data.success) {
            displayTrackingResults(data.tracking_info);
        } else {
            showNotification('Error', data.message || 'Shipment not found', 'error');
        }
    })
    .catch(error => {
        showLoading(false);
        showNotification('Error', 'Failed to track shipment', 'error');
        console.error('Error:', error);
    });
}

// Invoice Calculations
function initializeInvoiceCalculations() {
    const invoiceForms = document.querySelectorAll('.invoice-form');

    invoiceForms.forEach(form => {
        const quantityInputs = form.querySelectorAll('input[name*="quantity"]');
        const priceInputs = form.querySelectorAll('input[name*="price"]');

        [...quantityInputs, ...priceInputs].forEach(input => {
            input.addEventListener('input', function() {
                calculateInvoiceTotal(form);
            });
        });
    });
}

// Calculate Invoice Total
function calculateInvoiceTotal(form) {
    let subtotal = 0;
    const rows = form.querySelectorAll('.invoice-row');

    rows.forEach(row => {
        const quantity = parseFloat(row.querySelector('input[name*="quantity"]').value) || 0;
        const price = parseFloat(row.querySelector('input[name*="price"]').value) || 0;
        const lineTotal = quantity * price;

        const totalCell = row.querySelector('.line-total');
        if (totalCell) {
            totalCell.textContent = '$' + lineTotal.toFixed(2);
        }

        subtotal += lineTotal;
    });

    const taxRate = parseFloat(form.querySelector('input[name="tax_rate"]')?.value) || 0;
    const tax = subtotal * (taxRate / 100);
    const total = subtotal + tax;

    // Update totals
    const subtotalElement = form.querySelector('.subtotal');
    const taxElement = form.querySelector('.tax-amount');
    const totalElement = form.querySelector('.total-amount');

    if (subtotalElement) subtotalElement.textContent = '$' + subtotal.toFixed(2);
    if (taxElement) taxElement.textContent = '$' + tax.toFixed(2);
    if (totalElement) totalElement.textContent = '$' + total.toFixed(2);
}

// Utility Functions
function getCsrfToken() {
    return document.querySelector('[name=csrfmiddlewaretoken]')?.value ||
           document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
}

function showLoading(show) {
    const loader = document.querySelector('.loading-overlay');
    if (loader) {
        loader.style.display = show ? 'flex' : 'none';
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function displayFormErrors(form, errors) {
    // Clear previous errors
    form.querySelectorAll('.invalid-feedback').forEach(el => el.remove());
    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

    // Display new errors
    Object.keys(errors).forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (field) {
            field.classList.add('is-invalid');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = errors[fieldName][0];
            field.parentNode.appendChild(errorDiv);
        }
    });
}

function displayTrackingResults(trackingInfo) {
    const container = document.querySelector('.tracking-results');
    if (container) {
        container.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h5>Tracking Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Tracking Number:</strong> ${trackingInfo.tracking_number}</p>
                            <p><strong>Status:</strong> <span class="badge bg-${getStatusColor(trackingInfo.status)}">${trackingInfo.status}</span></p>
                            <p><strong>Origin:</strong> ${trackingInfo.origin}</p>
                            <p><strong>Destination:</strong> ${trackingInfo.destination}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Estimated Delivery:</strong> ${trackingInfo.estimated_delivery}</p>
                            <p><strong>Last Update:</strong> ${trackingInfo.last_update}</p>
                        </div>
                    </div>
                    <div class="tracking-timeline">
                        ${trackingInfo.events.map(event => `
                            <div class="timeline-item">
                                <div class="timeline-date">${event.date}</div>
                                <div class="timeline-content">
                                    <h6>${event.status}</h6>
                                    <p>${event.location}</p>
                                    <small>${event.description}</small>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }
}

function getStatusColor(status) {
    const statusColors = {
        'pending': 'warning',
        'in_transit': 'info',
        'delivered': 'success',
        'delayed': 'danger',
        'cancelled': 'secondary'
    };
    return statusColors[status.toLowerCase()] || 'secondary';
}

// Export functions for global access
window.showNotification = showNotification;
window.confirmAction = confirmAction;
window.trackShipment = trackShipment;
window.submitFormAjax = submitFormAjax;
