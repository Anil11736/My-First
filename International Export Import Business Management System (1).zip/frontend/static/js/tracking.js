// Real-time shipment tracking JavaScript
class ShipmentTracker {
    constructor() {
        this.trackingNumber = null;
        this.updateInterval = null;
        this.websocket = null;
        this.isTracking = false;
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeTracking();
        this.setupWebSocket();
    }

    bindEvents() {
        // Track button click
        const trackBtn = document.getElementById('trackBtn');
        if (trackBtn) {
            trackBtn.addEventListener('click', () => this.startTracking());
        }

        // Enter key on tracking input
        const trackingInput = document.getElementById('trackingNumber');
        if (trackingInput) {
            trackingInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.startTracking();
                }
            });
        }

        // Auto-refresh toggle
        const autoRefreshToggle = document.getElementById('autoRefresh');
        if (autoRefreshToggle) {
            autoRefreshToggle.addEventListener('change', (e) => {
                this.toggleAutoRefresh(e.target.checked);
            });
        }

        // Refresh button
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshTracking());
        }

        // Share tracking button
        const shareBtn = document.getElementById('shareBtn');
        if (shareBtn) {
            shareBtn.addEventListener('click', () => this.shareTracking());
        }
    }

    initializeTracking() {
        // Check if we're on a tracking page with existing tracking number
        const urlParams = new URLSearchParams(window.location.search);
        const trackingFromUrl = urlParams.get('tracking');

        if (trackingFromUrl) {
            document.getElementById('trackingNumber').value = trackingFromUrl;
            this.startTracking();
        }
    }

    setupWebSocket() {
        // Setup WebSocket for real-time updates (if available)
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/tracking/`;

        try {
            this.websocket = new WebSocket(wsUrl);

            this.websocket.onopen = () => {
                console.log('WebSocket connected for tracking updates');
            };

            this.websocket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleWebSocketUpdate(data);
            };

            this.websocket.onclose = () => {
                console.log('WebSocket disconnected');
                // Fallback to polling if WebSocket fails
                this.fallbackToPolling();
            };

            this.websocket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.fallbackToPolling();
            };
        } catch (error) {
            console.log('WebSocket not available, using polling');
            this.fallbackToPolling();
        }
    }

    async startTracking() {
        const trackingInput = document.getElementById('trackingNumber');
        const trackingNumber = trackingInput.value.trim();

        if (!trackingNumber) {
            this.showError('Please enter a tracking number');
            return;
        }

        this.trackingNumber = trackingNumber;
        this.showLoading(true);

        try {
            await this.fetchTrackingData();
            this.isTracking = true;

            // Subscribe to WebSocket updates if available
            if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
                this.websocket.send(JSON.stringify({
                    action: 'subscribe',
                    tracking_number: trackingNumber
                }));
            }

            // Update URL without page reload
            const newUrl = `${window.location.pathname}?tracking=${encodeURIComponent(trackingNumber)}`;
            window.history.pushState({}, '', newUrl);

        } catch (error) {
            this.showError('Failed to fetch tracking information');
            console.error('Tracking error:', error);
        } finally {
            this.showLoading(false);
        }
    }

    async fetchTrackingData() {
        const response = await fetch(`/api/shipments/track/${encodeURIComponent(this.trackingNumber)}/`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.getCSRFToken()
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        this.updateTrackingDisplay(data);
        return data;
    }

    updateTrackingDisplay(data) {
        // Update shipment info
        this.updateShipmentInfo(data.shipment);

        // Update tracking timeline
        this.updateTrackingTimeline(data.tracking_events);

        // Update current status
        this.updateCurrentStatus(data.current_status);

        // Update estimated delivery
        this.updateEstimatedDelivery(data.estimated_delivery);

        // Show tracking results
        document.getElementById('trackingResults').style.display = 'block';

        // Update last updated time
        this.updateLastUpdated();
    }

    updateShipmentInfo(shipment) {
        const infoContainer = document.getElementById('shipmentInfo');
        if (!infoContainer || !shipment) return;

        infoContainer.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <h5>Shipment Details</h5>
                    <p><strong>Tracking Number:</strong> ${shipment.tracking_number}</p>
                    <p><strong>Origin:</strong> ${shipment.origin_country}</p>
                    <p><strong>Destination:</strong> ${shipment.destination_country}</p>
                    <p><strong>Service Type:</strong> ${shipment.service_type}</p>
                </div>
                <div class="col-md-6">
                    <h5>Package Information</h5>
                    <p><strong>Weight:</strong> ${shipment.weight} kg</p>
                    <p><strong>Dimensions:</strong> ${shipment.dimensions || 'N/A'}</p>
                    <p><strong>Value:</strong> $${shipment.declared_value}</p>
                    <p><strong>Ship Date:</strong> ${this.formatDate(shipment.ship_date)}</p>
                </div>
            </div>
        `;
    }

    updateTrackingTimeline(events) {
        const timelineContainer = document.getElementById('trackingTimeline');
        if (!timelineContainer || !events) return;

        const timelineHTML = events.map((event, index) => `
            <div class="timeline-item ${index === 0 ? 'active' : ''}">
                <div class="timeline-marker">
                    <i class="fas ${this.getEventIcon(event.status)}"></i>
                </div>
                <div class="timeline-content">
                    <h6>${event.status}</h6>
                    <p>${event.description}</p>
                    <small class="text-muted">
                        ${this.formatDateTime(event.timestamp)} - ${event.location}
                    </small>
                </div>
            </div>
        `).join('');

        timelineContainer.innerHTML = timelineHTML;
    }

    updateCurrentStatus(status) {
        const statusContainer = document.getElementById('currentStatus');
        if (!statusContainer || !status) return;

        const statusClass = this.getStatusClass(status.code);
        const progressPercentage = this.getProgressPercentage(status.code);

        statusContainer.innerHTML = `
            <div class="status-badge ${statusClass}">
                <i class="fas ${this.getEventIcon(status.code)}"></i>
                ${status.description}
            </div>
            <div class="progress mt-3">
                <div class="progress-bar ${statusClass}"
                     style="width: ${progressPercentage}%"
                     aria-valuenow="${progressPercentage}"
                     aria-valuemin="0"
                     aria-valuemax="100">
                    ${progressPercentage}%
                </div>
            </div>
        `;
    }

    updateEstimatedDelivery(estimatedDelivery) {
        const deliveryContainer = document.getElementById('estimatedDelivery');
        if (!deliveryContainer) return;

        if (estimatedDelivery) {
            deliveryContainer.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-clock"></i>
                    <strong>Estimated Delivery:</strong> ${this.formatDate(estimatedDelivery)}
                </div>
            `;
        } else {
            deliveryContainer.innerHTML = `
                <div class="alert alert-secondary">
                    <i class="fas fa-question-circle"></i>
                    Estimated delivery date will be updated soon
                </div>
            `;
        }
    }

    handleWebSocketUpdate(data) {
        if (data.tracking_number === this.trackingNumber) {
            this.updateTrackingDisplay(data);
            this.showNotification('Tracking information updated', 'info');
        }
    }

    fallbackToPolling() {
        if (this.isTracking && this.trackingNumber) {
            this.updateInterval = setInterval(() => {
                this.refreshTracking();
            }, 30000); // Poll every 30 seconds
        }
    }

    toggleAutoRefresh(enabled) {
        if (enabled && this.isTracking) {
            this.updateInterval = setInterval(() => {
                this.refreshTracking();
            }, 30000);
        } else {
            if (this.updateInterval) {
                clearInterval(this.updateInterval);
                this.updateInterval = null;
            }
        }
    }

    async refreshTracking() {
        if (!this.trackingNumber) return;

        try {
            await this.fetchTrackingData();
            this.showNotification('Tracking information refreshed', 'success');
        } catch (error) {
            this.showNotification('Failed to refresh tracking information', 'error');
        }
    }

    shareTracking() {
        if (!this.trackingNumber) return;

        const trackingUrl = `${window.location.origin}/shipments/tracking/?tracking=${encodeURIComponent(this.trackingNumber)}`;

        if (navigator.share) {
            navigator.share({
                title: 'Shipment Tracking',
                text: `Track shipment: ${this.trackingNumber}`,
                url: trackingUrl
            });
        } else {
            // Fallback: copy to clipboard
            navigator.clipboard.writeText(trackingUrl).then(() => {
                this.showNotification('Tracking link copied to clipboard', 'success');
            }).catch(() => {
                this.showNotification('Failed to copy tracking link', 'error');
            });
        }
    }

    getEventIcon(status) {
        const icons = {
            'PICKED_UP': 'fa-box',
            'IN_TRANSIT': 'fa-truck',
            'OUT_FOR_DELIVERY': 'fa-shipping-fast',
            'DELIVERED': 'fa-check-circle',
            'EXCEPTION': 'fa-exclamation-triangle',
            'CUSTOMS_CLEARANCE': 'fa-passport',
            'DEPARTED_FACILITY': 'fa-plane-departure',
            'ARRIVED_FACILITY': 'fa-plane-arrival'
        };
        return icons[status] || 'fa-circle';
    }

    getStatusClass(status) {
        const classes = {
            'PICKED_UP': 'bg-primary',
            'IN_TRANSIT': 'bg-info',
            'OUT_FOR_DELIVERY': 'bg-warning',
            'DELIVERED': 'bg-success',
            'EXCEPTION': 'bg-danger',
            'CUSTOMS_CLEARANCE': 'bg-secondary'
        };
        return classes[status] || 'bg-secondary';
    }

    getProgressPercentage(status) {
        const percentages = {
            'PICKED_UP': 25,
            'IN_TRANSIT': 50,
            'CUSTOMS_CLEARANCE': 60,
            'OUT_FOR_DELIVERY': 85,
            'DELIVERED': 100,
            'EXCEPTION': 0
        };
        return percentages[status] || 10;
    }

    showLoading(show) {
        const loadingElement = document.getElementById('loadingSpinner');
        if (loadingElement) {
            loadingElement.style.display = show ? 'block' : 'none';
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show notification`;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        // Add to page
        const container = document.querySelector('.container') || document.body;
        container.insertBefore(notification, container.firstChild);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    updateLastUpdated() {
        const lastUpdatedElement = document.getElementById('lastUpdated');
        if (lastUpdatedElement) {
            lastUpdatedElement.textContent = `Last updated: ${new Date().toLocaleString()}`;
        }
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString();
    }

    formatDateTime(dateString) {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleString();
    }

    getCSRFToken() {
        return document.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
    }

    // Cleanup method
    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        if (this.websocket) {
            this.websocket.close();
        }
    }
}

// Initialize tracking when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.shipmentTracker = new ShipmentTracker();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.shipmentTracker) {
        window.shipmentTracker.destroy();
    }
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShipmentTracker;
}
