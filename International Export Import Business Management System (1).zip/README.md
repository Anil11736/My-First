# International Export & Import Business Management System

A comprehensive Django-based web application for managing international trade operations, including shipment tracking, inventory management, customer relations, document handling, and financial reporting.

## 🚀 Features

### Core Modules
- **Customer Management**: Complete CRM for importers and exporters
- **Inventory Management**: Product catalog with stock tracking
- **Shipment Management**: End-to-end shipment lifecycle management
- **Document Management**: Digital document storage and compliance tracking
- **Financial Management**: Invoicing, payments, and financial reporting
- **User Authentication**: Secure login with role-based access control

### Key Capabilities
- Real-time shipment tracking with status updates
- Automated invoice generation and payment processing
- Document upload and management with compliance checks
- Comprehensive financial reporting and analytics
- Multi-currency support for international transactions
- Export/Import documentation automation
- Dashboard with business insights and KPIs

## 🛠️ Tech Stack

- **Backend**: Django 4.2, Django REST Framework
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Database**: MySQL 8.0
- **Task Queue**: Celery with Redis
- **Authentication**: Django Auth + JWT tokens
- **Containerization**: Docker & Docker Compose

## 📋 Prerequisites

- Python 3.9+
- MySQL 8.0+
- Redis 6.0+
- Docker & Docker Compose (for containerized deployment)
- Node.js 16+ (for frontend dependencies)

## 🔧 Installation & Setup

### Local Development Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd export-import-management
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Environment Configuration**
```bash
cp .env.example .env
# Edit .env with your database and Redis configurations
```

5. **Database Setup**
```bash
# Create MySQL database
mysql -u root -p
CREATE DATABASE export_import_db;
CREATE USER 'django_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON export_import_db.* TO 'django_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Run migrations
python manage.py makemigrations
python manage.py migrate
```

6. **Create Superuser**
```bash
python manage.py createsuperuser
```

7. **Collect Static Files**
```bash
python manage.py collectstatic
```

8. **Start Development Server**
```bash
python manage.py runserver
```

9. **Start Celery Worker** (in separate terminal)
```bash
celery -A export_import worker -l info
```

10. **Start Celery Beat** (in separate terminal)
```bash
celery -A export_import beat -l info
```

### Docker Deployment

1. **Build and run with Docker Compose**
```bash
docker-compose up --build
```

2. **Run migrations in container**
```bash
docker-compose exec web python manage.py migrate
```

3. **Create superuser in container**
```bash
docker-compose exec web python manage.py createsuperuser
```

4. **Collect static files**
```bash
docker-compose exec web python manage.py collectstatic --noinput
```

## 🐳 Docker Configuration

### docker-compose.yml Structure
- **web**: Django application server
- **db**: MySQL database
- **redis**: Redis for caching and Celery
- **celery**: Background task worker
- **celery-beat**: Periodic task scheduler

### Environment Variables
```env
DEBUG=False
SECRET_KEY=your-secret-key
DATABASE_NAME=export_import_db
DATABASE_USER=django_user
DATABASE_PASSWORD=your_password
DATABASE_HOST=db
DATABASE_PORT=3306
REDIS_URL=redis://redis:6379/0
```

## 📁 Project Structure

```
export-import-management/
├── apps/
│   ├── accounts/          # User management
│   ├── customers/         # Customer CRM
│   ├── inventory/         # Product & inventory
│   ├── shipments/         # Shipment management
│   ├── documents/         # Document handling
│   └── financials/        # Financial operations
├── templates/
│   ├── base.html
│   ├── accounts/
│   ├── customers/
│   ├── inventory/
│   ├── shipments/
│   ├── documents/
│   └── financials/
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── export_import/         # Main project settings
├── requirements.txt
├── docker-compose.yml
├── Dockerfile
└── manage.py
```

## 🔐 Authentication & Authorization

### User Roles
- **Admin**: Full system access
- **Manager**: Business operations management
- **Operator**: Day-to-day operations
- **Viewer**: Read-only access

### API Authentication
- JWT tokens for API access
- Session-based authentication for web interface
- Role-based permissions for different modules

## 📊 API Endpoints

### Core APIs
```
GET/POST   /api/customers/           # Customer management
GET/POST   /api/products/            # Product catalog
GET/POST   /api/shipments/           # Shipment operations
GET/POST   /api/documents/           # Document management
GET/POST   /api/invoices/            # Financial operations
GET        /api/reports/             # Business reports
```

### Authentication
```
POST       /api/auth/login/          # User login
POST       /api/auth/logout/         # User logout
POST       /api/auth/refresh/        # Token refresh
GET        /api/auth/user/           # Current user info
```

## 🧪 Testing

### Run Tests
```bash
# All tests
python manage.py test

# Specific app tests
python manage.py test apps.customers
python manage.py test apps.shipments

# Coverage report
coverage run manage.py test
coverage report
coverage html
```

### Test Data
```bash
# Load sample data
python manage.py loaddata fixtures/sample_data.json
```

## 📈 Monitoring & Logging

### Application Logs
- Django logs: `logs/django.log`
- Celery logs: `logs/celery.log`
- Error logs: `logs/error.log`

### Health Checks
```bash
# Database connectivity
python manage.py dbshell

# Redis connectivity
redis-cli ping

# Celery status
celery -A export_import inspect active
```

## 🔧 Configuration

### Key Settings
- **Time Zone**: Configurable for international operations
- **Currency**: Multi-currency support
- **Email**: SMTP configuration for notifications
- **File Storage**: Local/Cloud storage options
- **Backup**: Automated database backups

### Performance Optimization
- Database indexing for frequently queried fields
- Redis caching for session and query optimization
- Static file compression and CDN integration
- Background task processing with Celery

## 🚀 Deployment

### Production Checklist
- [ ] Set `DEBUG=False`
- [ ] Configure secure `SECRET_KEY`
- [ ] Set up SSL certificates
- [ ] Configure email settings
- [ ] Set up database backups
- [ ] Configure monitoring and logging
- [ ] Set up reverse proxy (Nginx)
- [ ] Configure firewall rules

### Scaling Considerations
- Load balancing with multiple Django instances
- Database read replicas for reporting
- Redis clustering for high availability
- CDN for static file delivery
- Container orchestration with Kubernetes

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/new-feature`)
5. Create Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

For support and questions:
- Create an issue in the repository
- Email: support@export-import-system.com
- Documentation: [Wiki](wiki-url)

## 🔄 Version History

- **v1.0.0** - Initial release with core functionality
- **v1.1.0** - Added financial reporting module
- **v1.2.0** - Enhanced shipment tracking
- **v2.0.0** - API improvements and Docker support

---

**Note**: This is an academic project designed for learning purposes. For production use, ensure proper security audits and compliance with international trade regulations.
