# -*- coding: utf-8 -*-
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import Document, DocumentType, DocumentTemplate

@admin.register(DocumentType)
class DocumentTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'description', 'is_required', 'is_active', 'created_at')
    list_filter = ('is_required', 'is_active', 'created_at')
    search_fields = ('name', 'code', 'description')
    ordering = ('name',)

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'code', 'description')
        }),
        ('Settings', {
            'fields': ('is_required', 'is_active')
        }),
    )

@admin.register(DocumentTemplate)
class DocumentTemplateAdmin(admin.ModelAdmin):
    list_display = ('name', 'document_type', 'version', 'is_active', 'created_at')
    list_filter = ('document_type', 'is_active', 'created_at')
    search_fields = ('name', 'document_type__name')
    ordering = ('document_type', 'name')

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'document_type', 'description')
        }),
        ('Template Content', {
            'fields': ('template_content',)
        }),
        ('Settings', {
            'fields': ('version', 'is_active')
        }),
    )

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ('document_number', 'document_type', 'shipment_link', 'status', 'file_preview', 'created_at', 'updated_at')
    list_filter = ('document_type', 'status', 'created_at', 'updated_at')
    search_fields = ('document_number', 'title', 'shipment__shipment_number')
    ordering = ('-created_at',)
    readonly_fields = ('document_number', 'file_size', 'created_at', 'updated_at', 'created_by', 'updated_by')

    fieldsets = (
        ('Document Information', {
            'fields': ('document_number', 'title', 'document_type', 'description')
        }),
        ('Shipment Association', {
            'fields': ('shipment',)
        }),
        ('File Information', {
            'fields': ('file', 'file_size', 'status')
        }),
        ('Metadata', {
            'fields': ('metadata', 'tags')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at', 'created_by', 'updated_by'),
            'classes': ('collapse',)
        }),
    )

    def shipment_link(self, obj):
        if obj.shipment:
            url = reverse('admin:shipments_shipment_change', args=[obj.shipment.pk])
            return format_html('<a href="{}">{}</a>', url, obj.shipment.shipment_number)
        return '-'
    shipment_link.short_description = 'Shipment'
    shipment_link.admin_order_field = 'shipment__shipment_number'

    def file_preview(self, obj):
        if obj.file:
            file_url = obj.file.url
            file_name = obj.file.name.split('/')[-1]

            # Check file type for preview
            if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
                return format_html(
                    '<a href="{}" target="_blank"><img src="{}" style="max-height: 50px; max-width: 100px;" /></a>',
                    file_url, file_url
                )
            elif file_name.lower().endswith('.pdf'):
                return format_html(
                    '<a href="{}" target="_blank">📄 {}</a>',
                    file_url, file_name
                )
            else:
                return format_html(
                    '<a href="{}" target="_blank">📎 {}</a>',
                    file_url, file_name
                )
        return '-'
    file_preview.short_description = 'File'

    def save_model(self, request, obj, form, change):
        if not change:  # Creating new document
            obj.created_by = request.user
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            'document_type', 'shipment', 'created_by', 'updated_by'
        )

    class Media:
        css = {
            'all': ('admin/css/custom_admin.css',)
        }
        js = ('admin/js/document_admin.js',)

# Inline admin for documents in shipment admin
class DocumentInline(admin.TabularInline):
    model = Document
    extra = 0
    readonly_fields = ('document_number', 'file_size', 'created_at')
    fields = ('document_type', 'title', 'file', 'status', 'document_number', 'created_at')

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('document_type')
