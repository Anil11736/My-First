from django.urls import path
from . import views

app_name = 'documents'

urlpatterns = [
    # Document list and management
    path('', views.DocumentListView.as_view(), name='document_list'),
    path('create/', views.DocumentCreateView.as_view(), name='document_create'),
    path('<int:pk>/', views.DocumentDetailView.as_view(), name='document_detail'),
    path('<int:pk>/edit/', views.DocumentUpdateView.as_view(), name='document_edit'),
    path('<int:pk>/delete/', views.DocumentDeleteView.as_view(), name='document_delete'),
    path('<int:pk>/download/', views.document_download, name='document_download'),

    # Document generation
    path('generate/invoice/', views.generate_invoice, name='generate_invoice'),
    path('generate/packing-list/', views.generate_packing_list, name='generate_packing_list'),
    path('generate/bill-of-lading/', views.generate_bill_of_lading, name='generate_bill_of_lading'),
    path('generate/commercial-invoice/', views.generate_commercial_invoice, name='generate_commercial_invoice'),
    path('generate/certificate-of-origin/', views.generate_certificate_of_origin, name='generate_certificate_of_origin'),
    path('generate/export-declaration/', views.generate_export_declaration, name='generate_export_declaration'),
    path('generate/import-declaration/', views.generate_import_declaration, name='generate_import_declaration'),
    path('generate/customs-declaration/', views.generate_customs_declaration, name='generate_customs_declaration'),

    # Document templates
    path('templates/', views.DocumentTemplateListView.as_view(), name='template_list'),
    path('templates/create/', views.DocumentTemplateCreateView.as_view(), name='template_create'),
    path('templates/<int:pk>/', views.DocumentTemplateDetailView.as_view(), name='template_detail'),
    path('templates/<int:pk>/edit/', views.DocumentTemplateUpdateView.as_view(), name='template_edit'),
    path('templates/<int:pk>/delete/', views.DocumentTemplateDeleteView.as_view(), name='template_delete'),
    path('templates/<int:pk>/use/', views.use_template, name='use_template'),

    # Document approval workflow
    path('<int:pk>/approve/', views.approve_document, name='document_approve'),
    path('<int:pk>/reject/', views.reject_document, name='document_reject'),
    path('<int:pk>/submit-for-approval/', views.submit_for_approval, name='submit_for_approval'),
    path('pending-approval/', views.PendingApprovalListView.as_view(), name='pending_approval'),

    # Document sharing and collaboration
    path('<int:pk>/share/', views.share_document, name='document_share'),
    path('<int:pk>/revoke-access/', views.revoke_document_access, name='revoke_document_access'),
    path('shared-with-me/', views.SharedDocumentsListView.as_view(), name='shared_documents'),

    # Document versioning
    path('<int:pk>/versions/', views.DocumentVersionListView.as_view(), name='document_versions'),
    path('<int:pk>/create-version/', views.create_document_version, name='create_document_version'),
    path('versions/<int:version_id>/', views.DocumentVersionDetailView.as_view(), name='document_version_detail'),
    path('versions/<int:version_id>/restore/', views.restore_document_version, name='restore_document_version'),

    # Bulk operations
    path('bulk-download/', views.bulk_document_download, name='bulk_document_download'),
    path('bulk-delete/', views.bulk_document_delete, name='bulk_document_delete'),
    path('bulk-approve/', views.bulk_document_approve, name='bulk_document_approve'),

    # Document search and filtering
    path('search/', views.DocumentSearchView.as_view(), name='document_search'),
    path('filter/', views.DocumentFilterView.as_view(), name='document_filter'),
    path('by-type/<str:doc_type>/', views.DocumentsByTypeView.as_view(), name='documents_by_type'),
    path('by-status/<str:status>/', views.DocumentsByStatusView.as_view(), name='documents_by_status'),

    # Document analytics and reports
    path('analytics/', views.DocumentAnalyticsView.as_view(), name='document_analytics'),
    path('reports/generation-summary/', views.document_generation_report, name='document_generation_report'),
    path('reports/approval-summary/', views.document_approval_report, name='document_approval_report'),

    # API endpoints for AJAX operations
    path('api/validate/', views.validate_document_data, name='validate_document_data'),
    path('api/preview/', views.preview_document, name='preview_document'),
    path('api/auto-save/', views.auto_save_document, name='auto_save_document'),
    path('api/check-compliance/', views.check_document_compliance, name='check_document_compliance'),

    # Document archiving
    path('<int:pk>/archive/', views.archive_document, name='archive_document'),
    path('<int:pk>/unarchive/', views.unarchive_document, name='unarchive_document'),
    path('archived/', views.ArchivedDocumentsListView.as_view(), name='archived_documents'),

    # Document export/import
    path('export/', views.export_documents, name='export_documents'),
    path('import/', views.import_documents, name='import_documents'),
    path('export-template/', views.export_document_template, name='export_document_template'),
]
