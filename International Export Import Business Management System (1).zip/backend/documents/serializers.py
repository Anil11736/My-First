from rest_framework import serializers
from .models import Document, DocumentTemplate, DocumentType
from customers.serializers import CustomerSerializer
from shipments.serializers import ShipmentSerializer


class DocumentTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DocumentType
        fields = ['id', 'name', 'description', 'is_active']
        read_only_fields = ['id']


class DocumentTemplateSerializer(serializers.ModelSerializer):
    document_type = DocumentTypeSerializer(read_only=True)
    document_type_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = DocumentTemplate
        fields = [
            'id', 'name', 'document_type', 'document_type_id',
            'template_content', 'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class DocumentSerializer(serializers.ModelSerializer):
    document_type = DocumentTypeSerializer(read_only=True)
    document_type_id = serializers.IntegerField(write_only=True)
    customer = CustomerSerializer(read_only=True)
    customer_id = serializers.IntegerField(write_only=True, required=False)
    shipment = ShipmentSerializer(read_only=True)
    shipment_id = serializers.IntegerField(write_only=True, required=False)
    file_size = serializers.SerializerMethodField()

    class Meta:
        model = Document
        fields = [
            'id', 'title', 'document_type', 'document_type_id',
            'customer', 'customer_id', 'shipment', 'shipment_id',
            'file', 'file_size', 'description', 'tags', 'is_confidential',
            'expiry_date', 'version', 'created_at', 'updated_at', 'created_by'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by']

    def get_file_size(self, obj):
        if obj.file:
            return obj.file.size
        return None


class DocumentUploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = [
            'title', 'document_type_id', 'customer_id', 'shipment_id',
            'file', 'description', 'tags', 'is_confidential', 'expiry_date'
        ]

    def validate_file(self, value):
        # Validate file size (max 10MB)
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("File size cannot exceed 10MB")

        # Validate file type
        allowed_types = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/png',
            'text/plain'
        ]

        if value.content_type not in allowed_types:
            raise serializers.ValidationError("File type not supported")

        return value


class DocumentListSerializer(serializers.ModelSerializer):
    document_type_name = serializers.CharField(source='document_type.name', read_only=True)
    customer_name = serializers.CharField(source='customer.company_name', read_only=True)
    shipment_number = serializers.CharField(source='shipment.shipment_number', read_only=True)
    file_size = serializers.SerializerMethodField()

    class Meta:
        model = Document
        fields = [
            'id', 'title', 'document_type_name', 'customer_name',
            'shipment_number', 'file_size', 'is_confidential',
            'expiry_date', 'version', 'created_at'
        ]

    def get_file_size(self, obj):
        if obj.file:
            size = obj.file.size
            if size < 1024:
                return f"{size} B"
            elif size < 1024 * 1024:
                return f"{size / 1024:.1f} KB"
            else:
                return f"{size / (1024 * 1024):.1f} MB"
        return None


class DocumentGenerationSerializer(serializers.Serializer):
    template_id = serializers.IntegerField()
    customer_id = serializers.IntegerField(required=False)
    shipment_id = serializers.IntegerField(required=False)
    invoice_id = serializers.IntegerField(required=False)
    custom_data = serializers.JSONField(required=False)

    def validate_template_id(self, value):
        try:
            DocumentTemplate.objects.get(id=value, is_active=True)
        except DocumentTemplate.DoesNotExist:
            raise serializers.ValidationError("Template not found or inactive")
        return value

    def validate(self, attrs):
        # At least one reference (customer, shipment, or invoice) should be provided
        if not any([attrs.get('customer_id'), attrs.get('shipment_id'), attrs.get('invoice_id')]):
            raise serializers.ValidationError(
                "At least one reference (customer, shipment, or invoice) is required"
            )
        return attrs


class DocumentSearchSerializer(serializers.Serializer):
    query = serializers.CharField(required=False)
    document_type = serializers.IntegerField(required=False)
    customer = serializers.IntegerField(required=False)
    shipment = serializers.IntegerField(required=False)
    date_from = serializers.DateField(required=False)
    date_to = serializers.DateField(required=False)
    tags = serializers.CharField(required=False)
    is_confidential = serializers.BooleanField(required=False)
