from django import forms
from django.core.validators import FileExtensionValidator
from .models import Document, DocumentType


class DocumentUploadForm(forms.ModelForm):
    """Form for uploading documents with metadata"""

    class Meta:
        model = Document
        fields = [
            'title',
            'document_type',
            'file',
            'description',
            'shipment',
            'customer',
            'is_required',
            'expiry_date'
        ]
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter document title'
            }),
            'document_type': forms.Select(attrs={
                'class': 'form-select'
            }),
            'file': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '.pdf,.doc,.docx,.jpg,.jpeg,.png'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter document description'
            }),
            'shipment': forms.Select(attrs={
                'class': 'form-select'
            }),
            'customer': forms.Select(attrs={
                'class': 'form-select'
            }),
            'is_required': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'expiry_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['file'].validators.append(
            FileExtensionValidator(
                allowed_extensions=['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png']
            )
        )
        self.fields['file'].help_text = 'Allowed formats: PDF, DOC, DOCX, JPG, PNG (Max 10MB)'

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file:
            if file.size > 10 * 1024 * 1024:  # 10MB limit
                raise forms.ValidationError('File size cannot exceed 10MB')
        return file


class DocumentTypeForm(forms.ModelForm):
    """Form for creating and editing document types"""

    class Meta:
        model = DocumentType
        fields = ['name', 'description', 'is_required', 'category']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter document type name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter description'
            }),
            'is_required': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'category': forms.Select(attrs={
                'class': 'form-select'
            })
        }


class DocumentSearchForm(forms.Form):
    """Form for searching and filtering documents"""

    CATEGORY_CHOICES = [
        ('', 'All Categories'),
        ('export', 'Export Documents'),
        ('import', 'Import Documents'),
        ('customs', 'Customs Documents'),
        ('shipping', 'Shipping Documents'),
        ('financial', 'Financial Documents'),
        ('legal', 'Legal Documents'),
    ]

    STATUS_CHOICES = [
        ('', 'All Status'),
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('expired', 'Expired'),
    ]

    search_query = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search documents...'
        })
    )

    document_type = forms.ModelChoiceField(
        queryset=DocumentType.objects.all(),
        required=False,
        empty_label="All Types",
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    category = forms.ChoiceField(
        choices=CATEGORY_CHOICES,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )

    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )


class BulkDocumentUploadForm(forms.Form):
    """Form for bulk document upload"""

    files = forms.FileField(
        widget=forms.ClearableFileInput(attrs={
            'class': 'form-control',
            'multiple': True,
            'accept': '.pdf,.doc,.docx,.jpg,.jpeg,.png'
        }),
        help_text='Select multiple files (PDF, DOC, DOCX, JPG, PNG)'
    )

    document_type = forms.ModelChoiceField(
        queryset=DocumentType.objects.all(),
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    shipment = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Shipment reference (optional)'
        })
    )

    customer = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Customer name (optional)'
        })
    )


class DocumentApprovalForm(forms.ModelForm):
    """Form for document approval/rejection"""

    APPROVAL_CHOICES = [
        ('approved', 'Approve'),
        ('rejected', 'Reject'),
    ]

    status = forms.ChoiceField(
        choices=APPROVAL_CHOICES,
        widget=forms.RadioSelect(attrs={
            'class': 'form-check-input'
        })
    )

    approval_notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Enter approval/rejection notes'
        })
    )

    class Meta:
        model = Document
        fields = ['status', 'approval_notes']


class DocumentVersionForm(forms.ModelForm):
    """Form for uploading new document versions"""

    class Meta:
        model = Document
        fields = ['file', 'version_notes']
        widgets = {
            'file': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '.pdf,.doc,.docx,.jpg,.jpeg,.png'
            }),
            'version_notes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter version notes'
            })
        }

    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file:
            if file.size > 10 * 1024 * 1024:  # 10MB limit
                raise forms.ValidationError('File size cannot exceed 10MB')
        return file
