# -*- coding: utf-8 -*-
import os
import io
from datetime import datetime
from decimal import Decimal
from typing import Dict, Any, List, Optional
from django.conf import settings
from django.http import HttpResponse
from django.template.loader import get_template
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.platypus.flowables import HRFlowable
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import qrcode
from PIL import Image as PILImage


class DocumentGenerator:
    """Utility class for generating various business documents"""

    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.setup_custom_styles()

    def setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.darkblue
        ))

        self.styles.add(ParagraphStyle(
            name='CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.darkblue
        ))

        self.styles.add(ParagraphStyle(
            name='CustomNormal',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6
        ))

        self.styles.add(ParagraphStyle(
            name='RightAlign',
            parent=self.styles['Normal'],
            fontSize=10,
            alignment=TA_RIGHT
        ))

    def generate_invoice(self, shipment_data: Dict[str, Any]) -> bytes:
        """Generate commercial invoice PDF"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72,
                              topMargin=72, bottomMargin=18)

        story = []

        # Header
        story.append(Paragraph("COMMERCIAL INVOICE", self.styles['CustomTitle']))
        story.append(Spacer(1, 12))

        # Company info and invoice details
        company_info = [
            ['Company Name:', shipment_data.get('exporter_name', 'N/A')],
            ['Address:', shipment_data.get('exporter_address', 'N/A')],
            ['Phone:', shipment_data.get('exporter_phone', 'N/A')],
            ['Email:', shipment_data.get('exporter_email', 'N/A')]
        ]

        invoice_info = [
            ['Invoice No:', shipment_data.get('invoice_number', 'N/A')],
            ['Date:', shipment_data.get('invoice_date', datetime.now().strftime('%Y-%m-%d'))],
            ['Terms:', shipment_data.get('payment_terms', 'N/A')],
            ['Currency:', shipment_data.get('currency', 'USD')]
        ]

        # Create two-column layout
        header_data = []
        for i in range(max(len(company_info), len(invoice_info))):
            row = []
            if i < len(company_info):
                row.extend(company_info[i])
            else:
                row.extend(['', ''])

            if i < len(invoice_info):
                row.extend(invoice_info[i])
            else:
                row.extend(['', ''])
            header_data.append(row)

        header_table = Table(header_data, colWidths=[1.5*inch, 2*inch, 1.5*inch, 2*inch])
        header_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))

        story.append(header_table)
        story.append(Spacer(1, 20))

        # Buyer information
        story.append(Paragraph("SOLD TO:", self.styles['CustomHeading']))
        buyer_data = [
            ['Company:', shipment_data.get('importer_name', 'N/A')],
            ['Address:', shipment_data.get('importer_address', 'N/A')],
            ['Country:', shipment_data.get('destination_country', 'N/A')]
        ]

        buyer_table = Table(buyer_data, colWidths=[1.5*inch, 4*inch])
        buyer_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ]))

        story.append(buyer_table)
        story.append(Spacer(1, 20))

        # Items table
        story.append(Paragraph("ITEMS:", self.styles['CustomHeading']))

        items_data = [['Description', 'Quantity', 'Unit Price', 'Total']]
        total_amount = Decimal('0.00')

        for item in shipment_data.get('items', []):
            quantity = Decimal(str(item.get('quantity', 0)))
            unit_price = Decimal(str(item.get('unit_price', 0)))
            item_total = quantity * unit_price
            total_amount += item_total

            items_data.append([
                item.get('description', 'N/A'),
                str(quantity),
                f"${unit_price:.2f}",
                f"${item_total:.2f}"
            ])

        # Add total row
        items_data.append(['', '', 'TOTAL:', f"${total_amount:.2f}"])

        items_table = Table(items_data, colWidths=[3*inch, 1*inch, 1.5*inch, 1.5*inch])
        items_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        story.append(items_table)
        story.append(Spacer(1, 20))

        # Terms and conditions
        story.append(Paragraph("TERMS & CONDITIONS:", self.styles['CustomHeading']))
        terms = shipment_data.get('terms_conditions', 'Payment due within 30 days of invoice date.')
        story.append(Paragraph(terms, self.styles['CustomNormal']))

        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    def generate_packing_list(self, shipment_data: Dict[str, Any]) -> bytes:
        """Generate packing list PDF"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72,
                              topMargin=72, bottomMargin=18)

        story = []

        # Header
        story.append(Paragraph("PACKING LIST", self.styles['CustomTitle']))
        story.append(Spacer(1, 12))

        # Shipment details
        shipment_info = [
            ['Shipment ID:', shipment_data.get('shipment_id', 'N/A')],
            ['Date:', shipment_data.get('shipment_date', datetime.now().strftime('%Y-%m-%d'))],
            ['Origin:', shipment_data.get('origin_port', 'N/A')],
            ['Destination:', shipment_data.get('destination_port', 'N/A')],
            ['Container No:', shipment_data.get('container_number', 'N/A')],
            ['Seal No:', shipment_data.get('seal_number', 'N/A')]
        ]

        info_table = Table(shipment_info, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ]))

        story.append(info_table)
        story.append(Spacer(1, 20))

        # Packing details
        story.append(Paragraph("PACKAGE DETAILS:", self.styles['CustomHeading']))

        packing_data = [['Package No.', 'Description', 'Quantity', 'Weight (kg)', 'Dimensions (cm)']]
        total_packages = 0
        total_weight = Decimal('0.00')

        for i, item in enumerate(shipment_data.get('items', []), 1):
            packages = item.get('packages', 1)
            weight = Decimal(str(item.get('weight', 0)))
            dimensions = item.get('dimensions', 'N/A')

            total_packages += packages
            total_weight += weight

            packing_data.append([
                str(i),
                item.get('description', 'N/A'),
                str(packages),
                f"{weight:.2f}",
                dimensions
            ])

        # Add summary row
        packing_data.append(['', 'TOTAL:', str(total_packages), f"{total_weight:.2f}", ''])

        packing_table = Table(packing_data, colWidths=[1*inch, 2.5*inch, 1*inch, 1.5*inch, 1.5*inch])
        packing_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        story.append(packing_table)

        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    def generate_bill_of_lading(self, shipment_data: Dict[str, Any]) -> bytes:
        """Generate Bill of Lading PDF"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72,
                              topMargin=72, bottomMargin=18)

        story = []

        # Header
        story.append(Paragraph("BILL OF LADING", self.styles['CustomTitle']))
        story.append(Spacer(1, 12))

        # B/L details
        bl_info = [
            ['B/L Number:', shipment_data.get('bl_number', 'N/A')],
            ['Date of Issue:', shipment_data.get('bl_date', datetime.now().strftime('%Y-%m-%d'))],
            ['Vessel:', shipment_data.get('vessel_name', 'N/A')],
            ['Voyage:', shipment_data.get('voyage_number', 'N/A')]
        ]

        bl_table = Table(bl_info, colWidths=[2*inch, 4*inch])
        bl_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ]))

        story.append(bl_table)
        story.append(Spacer(1, 20))

        # Shipper and consignee
        parties_data = [
            ['SHIPPER:', 'CONSIGNEE:'],
            [shipment_data.get('shipper_name', 'N/A'), shipment_data.get('consignee_name', 'N/A')],
            [shipment_data.get('shipper_address', 'N/A'), shipment_data.get('consignee_address', 'N/A')]
        ]

        parties_table = Table(parties_data, colWidths=[3*inch, 3*inch])
        parties_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        story.append(parties_table)
        story.append(Spacer(1, 20))

        # Port information
        port_data = [
            ['Port of Loading:', shipment_data.get('port_of_loading', 'N/A')],
            ['Port of Discharge:', shipment_data.get('port_of_discharge', 'N/A')],
            ['Place of Delivery:', shipment_data.get('place_of_delivery', 'N/A')]
        ]

        port_table = Table(port_data, colWidths=[2*inch, 4*inch])
        port_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ]))

        story.append(port_table)
        story.append(Spacer(1, 20))

        # Cargo description
        story.append(Paragraph("DESCRIPTION OF GOODS:", self.styles['CustomHeading']))

        cargo_description = shipment_data.get('cargo_description', 'General Cargo')
        story.append(Paragraph(cargo_description, self.styles['CustomNormal']))
        story.append(Spacer(1, 12))

        # Container details
        container_data = [
            ['Container Number:', shipment_data.get('container_number', 'N/A')],
            ['Container Type:', shipment_data.get('container_type', 'N/A')],
            ['Seal Number:', shipment_data.get('seal_number', 'N/A')],
            ['Gross Weight:', f"{shipment_data.get('gross_weight', 0)} kg"]
        ]

        container_table = Table(container_data, colWidths=[2*inch, 4*inch])
        container_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ]))

        story.append(container_table)
        story.append(Spacer(1, 30))

        # Signature section
        story.append(HRFlowable(width="100%"))
        story.append(Spacer(1, 12))
        story.append(Paragraph("Carrier's Signature", self.styles['RightAlign']))

        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    def generate_qr_code(self, data: str, size: int = 200) -> bytes:
        """Generate QR code for tracking or document verification"""
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        img = img.resize((size, size), PILImage.LANCZOS)

        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        return buffer.getvalue()


def create_pdf_response(pdf_content: bytes, filename: str) -> HttpResponse:
    """Create HTTP response for PDF download"""
    response = HttpResponse(pdf_content, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


def save_document(content: bytes, filename: str, folder: str = 'documents') -> str:
    """Save document to storage and return file path"""
    file_path = f"{folder}/{filename}"
    file_obj = ContentFile(content, name=filename)
    saved_path = default_storage.save(file_path, file_obj)
    return saved_path


def validate_document_data(data: Dict[str, Any], required_fields: List[str]) -> List[str]:
    """Validate document data and return list of missing fields"""
    missing_fields = []
    for field in required_fields:
        if field not in data or not data[field]:
            missing_fields.append(field)
    return missing_fields


def format_currency(amount: Decimal, currency: str = 'USD') -> str:
    """Format currency amount with symbol"""
    symbols = {
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'INR': '₹',
        'JPY': '¥'
    }
    symbol = symbols.get(currency, currency)
    return f"{symbol}{amount:,.2f}"


def calculate_document_hash(content: bytes) -> str:
    """Calculate SHA-256 hash of document content for integrity verification"""
    import hashlib
    return hashlib.sha256(content).hexdigest()


def get_document_metadata(shipment_data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract metadata for document indexing and search"""
    return {
        'shipment_id': shipment_data.get('shipment_id'),
        'invoice_number': shipment_data.get('invoice_number'),
        'bl_number': shipment_data.get('bl_number'),
        'exporter_name': shipment_data.get('exporter_name'),
        'importer_name': shipment_data.get('importer_name'),
        'origin_country': shipment_data.get('origin_country'),
        'destination_country': shipment_data.get('destination_country'),
        'created_date': datetime.now().isoformat(),
        'total_value': shipment_data.get('total_value'),
        'currency': shipment_data.get('currency', 'USD')
    }
