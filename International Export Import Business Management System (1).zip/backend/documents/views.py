# -*- coding: utf-8 -*-
import os
import mimetypes
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, JsonResponse, Http404
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator
from django.db.models import Q
from django.conf import settings
from django.utils import timezone
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import json
import uuid
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.units import inch
from io import BytesIO
from .models import Document, DocumentTemplate, DocumentType
from .forms import DocumentUploadForm, DocumentTemplateForm
from shipments.models import Shipment
from customers.models import Customer


@login_required
def document_list(request):
    """Display list of documents with search and filtering"""
    documents = Document.objects.filter(created_by=request.user).order_by('-created_at')

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        documents = documents.filter(
            Q(title__icontains=search_query) |
            Q(document_type__name__icontains=search_query) |
            Q(description__icontains=search_query)
        )

    # Filter by document type
    doc_type = request.GET.get('type', '')
    if doc_type:
        documents = documents.filter(document_type__slug=doc_type)

    # Filter by status
    status = request.GET.get('status', '')
    if status:
        documents = documents.filter(status=status)

    # Pagination
    paginator = Paginator(documents, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Get document types for filter dropdown
    document_types = DocumentType.objects.all()

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'selected_type': doc_type,
        'selected_status': status,
        'document_types': document_types,
        'status_choices': Document.STATUS_CHOICES,
    }

    return render(request, 'documents/document_list.html', context)


@login_required
def document_detail(request, pk):
    """Display document details"""
    document = get_object_or_404(Document, pk=pk, created_by=request.user)

    context = {
        'document': document,
    }

    return render(request, 'documents/document_detail.html', context)


@login_required
def document_upload(request):
    """Handle document upload"""
    if request.method == 'POST':
        form = DocumentUploadForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.save(commit=False)
            document.created_by = request.user
            document.updated_by = request.user

            # Generate unique filename
            if document.file:
                ext = os.path.splitext(document.file.name)[1]
                filename = f"{uuid.uuid4()}{ext}"
                document.file.name = filename

            document.save()
            messages.success(request, 'Document uploaded successfully.')
            return redirect('documents:document_detail', pk=document.pk)
    else:
        form = DocumentUploadForm()

    context = {
        'form': form,
        'document_types': DocumentType.objects.all(),
    }

    return render(request, 'documents/document_upload.html', context)


@login_required
def document_download(request, pk):
    """Handle document download"""
    document = get_object_or_404(Document, pk=pk, created_by=request.user)

    if not document.file:
        raise Http404("Document file not found")

    try:
        file_path = document.file.path
        if not os.path.exists(file_path):
            raise Http404("Document file not found on disk")

        # Determine content type
        content_type, _ = mimetypes.guess_type(file_path)
        if content_type is None:
            content_type = 'application/octet-stream'

        # Read file content
        with open(file_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type=content_type)

        # Set download headers
        filename = document.original_filename or document.title
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        response['Content-Length'] = os.path.getsize(file_path)

        # Update download count
        document.download_count += 1
        document.save(update_fields=['download_count'])

        return response

    except Exception as e:
        messages.error(request, f'Error downloading document: {str(e)}')
        return redirect('documents:document_detail', pk=document.pk)


@login_required
def document_delete(request, pk):
    """Handle document deletion"""
    document = get_object_or_404(Document, pk=pk, created_by=request.user)

    if request.method == 'POST':
        # Delete file from storage
        if document.file:
            try:
                default_storage.delete(document.file.name)
            except Exception:
                pass  # File might not exist

        document.delete()
        messages.success(request, 'Document deleted successfully.')
        return redirect('documents:document_list')

    context = {
        'document': document,
    }

    return render(request, 'documents/document_confirm_delete.html', context)


@login_required
def generate_invoice(request, shipment_id):
    """Generate commercial invoice PDF"""
    shipment = get_object_or_404(Shipment, pk=shipment_id, created_by=request.user)

    # Create PDF buffer
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1  # Center alignment
    )
    story.append(Paragraph("COMMERCIAL INVOICE", title_style))
    story.append(Spacer(1, 20))

    # Invoice details
    invoice_data = [
        ['Invoice Number:', f'INV-{shipment.tracking_number}'],
        ['Date:', timezone.now().strftime('%Y-%m-%d')],
        ['Shipment ID:', shipment.tracking_number],
        ['Origin:', f'{shipment.origin_country}, {shipment.origin_port}'],
        ['Destination:', f'{shipment.destination_country}, {shipment.destination_port}'],
    ]

    invoice_table = Table(invoice_data, colWidths=[2*inch, 3*inch])
    invoice_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(invoice_table)
    story.append(Spacer(1, 20))

    # Customer information
    if shipment.customer:
        story.append(Paragraph("BILL TO:", styles['Heading3']))
        customer_info = f"""
        {shipment.customer.company_name}<br/>
        {shipment.customer.address}<br/>
        {shipment.customer.city}, {shipment.customer.country}<br/>
        Phone: {shipment.customer.phone}<br/>
        Email: {shipment.customer.email}
        """
        story.append(Paragraph(customer_info, styles['Normal']))
        story.append(Spacer(1, 20))

    # Items table
    story.append(Paragraph("ITEMS:", styles['Heading3']))

    items_data = [['Description', 'Quantity', 'Unit Price', 'Total']]
    total_value = 0

    for item in shipment.shipmentitem_set.all():
        item_total = item.quantity * item.unit_price
        total_value += item_total
        items_data.append([
            item.product.name if item.product else 'N/A',
            str(item.quantity),
            f'${item.unit_price:.2f}',
            f'${item_total:.2f}'
        ])

    # Add total row
    items_data.append(['', '', 'TOTAL:', f'${total_value:.2f}'])

    items_table = Table(items_data, colWidths=[3*inch, 1*inch, 1*inch, 1*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
    ]))
    story.append(items_table)

    # Build PDF
    doc.build(story)
    buffer.seek(0)

    # Create document record
    document = Document.objects.create(
        title=f'Commercial Invoice - {shipment.tracking_number}',
        document_type=DocumentType.objects.get_or_create(
            name='Commercial Invoice',
            defaults={'slug': 'commercial-invoice'}
        )[0],
        shipment=shipment,
        created_by=request.user,
        updated_by=request.user,
        status='generated'
    )

    # Save PDF file
    pdf_content = ContentFile(buffer.getvalue())
    filename = f'invoice_{shipment.tracking_number}_{timezone.now().strftime("%Y%m%d")}.pdf'
    document.file.save(filename, pdf_content)

    # Return PDF response
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    messages.success(request, 'Commercial invoice generated successfully.')
    return response


@login_required
def generate_packing_list(request, shipment_id):
    """Generate packing list PDF"""
    shipment = get_object_or_404(Shipment, pk=shipment_id, created_by=request.user)

    # Create PDF buffer
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1
    )
    story.append(Paragraph("PACKING LIST", title_style))
    story.append(Spacer(1, 20))

    # Shipment details
    packing_data = [
        ['Shipment ID:', shipment.tracking_number],
        ['Date:', timezone.now().strftime('%Y-%m-%d')],
        ['Origin:', f'{shipment.origin_country}, {shipment.origin_port}'],
        ['Destination:', f'{shipment.destination_country}, {shipment.destination_port}'],
        ['Total Weight:', f'{shipment.total_weight} kg'],
        ['Total Volume:', f'{shipment.total_volume} m³'],
    ]

    packing_table = Table(packing_data, colWidths=[2*inch, 3*inch])
    packing_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(packing_table)
    story.append(Spacer(1, 20))

    # Items table
    story.append(Paragraph("PACKAGE CONTENTS:", styles['Heading3']))

    items_data = [['Item', 'Quantity', 'Weight (kg)', 'Dimensions']]

    for item in shipment.shipmentitem_set.all():
        items_data.append([
            item.product.name if item.product else 'N/A',
            str(item.quantity),
            str(item.weight or 'N/A'),
            f'{item.length}x{item.width}x{item.height}' if all([item.length, item.width, item.height]) else 'N/A'
        ])

    items_table = Table(items_data, colWidths=[2.5*inch, 1*inch, 1*inch, 1.5*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    story.append(items_table)

    # Build PDF
    doc.build(story)
    buffer.seek(0)

    # Create document record
    document = Document.objects.create(
        title=f'Packing List - {shipment.tracking_number}',
        document_type=DocumentType.objects.get_or_create(
            name='Packing List',
            defaults={'slug': 'packing-list'}
        )[0],
        shipment=shipment,
        created_by=request.user,
        updated_by=request.user,
        status='generated'
    )

    # Save PDF file
    pdf_content = ContentFile(buffer.getvalue())
    filename = f'packing_list_{shipment.tracking_number}_{timezone.now().strftime("%Y%m%d")}.pdf'
    document.file.save(filename, pdf_content)

    # Return PDF response
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    messages.success(request, 'Packing list generated successfully.')
    return response


@login_required
def template_list(request):
    """Display list of document templates"""
    templates = DocumentTemplate.objects.filter(created_by=request.user).order_by('-created_at')

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        templates = templates.filter(
            Q(name__icontains=search_query) |
            Q(description__icontains=search_query)
        )

    # Pagination
    paginator = Paginator(templates, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }

    return render(request, 'documents/template_list.html', context)


@login_required
def template_create(request):
    """Create new document template"""
    if request.method == 'POST':
        form = DocumentTemplateForm(request.POST, request.FILES)
        if form.is_valid():
            template = form.save(commit=False)
            template.created_by = request.user
            template.updated_by = request.user
            template.save()
            messages.success(request, 'Document template created successfully.')
            return redirect('documents:template_list')
    else:
        form = DocumentTemplateForm()

    context = {
        'form': form,
    }

    return render(request, 'documents/template_form.html', context)


@login_required
@require_http_methods(["POST"])
def bulk_download(request):
    """Handle bulk download of selected documents"""
    document_ids = request.POST.getlist('document_ids')

    if not document_ids:
        messages.error(request, 'No documents selected.')
        return redirect('documents:document_list')

    documents = Document.objects.filter(
        pk__in=document_ids,
        created_by=request.user
    )

    if len(documents) == 1:
        # Single document - direct download
        return document_download(request, documents.first().pk)

    # Multiple documents - create ZIP
    import zipfile
    from django.http import StreamingHttpResponse

    def generate_zip():
        buffer = BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for doc in documents:
                if doc.file and os.path.exists(doc.file.path):
                    filename = doc.original_filename or f"{doc.title}.{doc.file.name.split('.')[-1]}"
                    zip_file.write(doc.file.path, filename)

        buffer.seek(0)
        return buffer.getvalue()

    zip_data = generate_zip()
    response = HttpResponse(zip_data, content_type='application/zip')
    response['Content-Disposition'] = f'attachment; filename="documents_{timezone.now().strftime("%Y%m%d")}.zip"'

    messages.success(request, f'{len(documents)} documents downloaded successfully.')
    return response


@login_required
@csrf_exempt
def ajax_document_status(request, pk):
    """AJAX endpoint to update document status"""
    if request.method == 'POST':
        document = get_object_or_404(Document, pk=pk, created_by=request.user)

        try:
            data = json.loads(request.body)
            new_status = data.get('status')

            if new_status in dict(Document.STATUS_CHOICES):
                document.status = new_status
                document.updated_by = request.user
                document.save(update_fields=['status', 'updated_at', 'updated_by'])

                return JsonResponse({
                    'success': True,
                    'message': 'Status updated successfully.',
                    'status': document.get_status_display()
                })
            else:
                return JsonResponse({
                    'success': False,
                    'message': 'Invalid status value.'
                })

        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'message': 'Invalid JSON data.'
            })

    return JsonResponse({
        'success': False,
        'message': 'Invalid request method.'
    })
