from django.db import models
from django.core.validators import FileExtensionValidator
from django.contrib.auth.models import User
import uuid
import os


def document_upload_path(instance, filename):
    """Generate upload path for documents"""
    ext = filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{ext}"
    return os.path.join('documents', instance.document_type.lower(), filename)


class DocumentType(models.Model):
    """Document type definitions"""
    DOCUMENT_TYPES = [
        ('INVOICE', 'Commercial Invoice'),
        ('PACKING_LIST', 'Packing List'),
        ('BILL_OF_LADING', 'Bill of Lading'),
        ('CERTIFICATE_OF_ORIGIN', 'Certificate of Origin'),
        ('EXPORT_LICENSE', 'Export License'),
        ('IMPORT_LICENSE', 'Import License'),
        ('INSURANCE_CERTIFICATE', 'Insurance Certificate'),
        ('INSPECTION_CERTIFICATE', 'Inspection Certificate'),
        ('PHYTOSANITARY_CERTIFICATE', 'Phytosanitary Certificate'),
        ('HEALTH_CERTIFICATE', 'Health Certificate'),
        ('CUSTOMS_DECLARATION', 'Customs Declaration'),
        ('LETTER_OF_CREDIT', 'Letter of Credit'),
        ('BANK_GUARANTEE', 'Bank Guarantee'),
        ('SHIPPING_INSTRUCTION', 'Shipping Instruction'),
        ('DELIVERY_ORDER', 'Delivery Order'),
        ('WAREHOUSE_RECEIPT', 'Warehouse Receipt'),
        ('OTHER', 'Other Document'),
    ]

    name = models.CharField(max_length=100, choices=DOCUMENT_TYPES, unique=True)
    description = models.TextField(blank=True)
    is_mandatory = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'document_types'
        ordering = ['name']

    def __str__(self):
        return self.get_name_display()


class Document(models.Model):
    """Main document model for all trade documents"""
    STATUS_CHOICES = [
        ('DRAFT', 'Draft'),
        ('PENDING_REVIEW', 'Pending Review'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
        ('EXPIRED', 'Expired'),
        ('CANCELLED', 'Cancelled'),
    ]

    PRIORITY_CHOICES = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('URGENT', 'Urgent'),
    ]

    document_number = models.CharField(max_length=100, unique=True)
    document_type = models.ForeignKey(DocumentType, on_delete=models.CASCADE, related_name='documents')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)

    # Relationships
    shipment = models.ForeignKey('shipments.Shipment', on_delete=models.CASCADE, related_name='documents', null=True, blank=True)
    customer = models.ForeignKey('customers.Customer', on_delete=models.CASCADE, related_name='documents', null=True, blank=True)

    # File information
    file = models.FileField(
        upload_to=document_upload_path,
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'xlsx', 'xls'])],
        null=True,
        blank=True
    )
    file_size = models.PositiveIntegerField(null=True, blank=True, help_text="File size in bytes")
    file_type = models.CharField(max_length=50, blank=True)

    # Document details
    issue_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    issuing_authority = models.CharField(max_length=200, blank=True)
    reference_number = models.CharField(max_length=100, blank=True)

    # Status and workflow
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='DRAFT')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='MEDIUM')
    is_original = models.BooleanField(default=True)
    is_certified = models.BooleanField(default=False)

    # Tracking
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_documents')
    updated_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='updated_documents', null=True, blank=True)
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='reviewed_documents', null=True, blank=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)

    # Metadata
    tags = models.CharField(max_length=500, blank=True, help_text="Comma-separated tags")
    notes = models.TextField(blank=True)
    version = models.PositiveIntegerField(default=1)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'documents'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['document_number']),
            models.Index(fields=['document_type', 'status']),
            models.Index(fields=['shipment', 'document_type']),
            models.Index(fields=['customer', 'document_type']),
            models.Index(fields=['issue_date']),
            models.Index(fields=['expiry_date']),
        ]

    def __str__(self):
        return f"{self.document_number} - {self.title}"

    def save(self, *args, **kwargs):
        if self.file:
            self.file_size = self.file.size
            self.file_type = self.file.name.split('.')[-1].upper()
        super().save(*args, **kwargs)

    @property
    def is_expired(self):
        """Check if document is expired"""
        if self.expiry_date:
            from django.utils import timezone
            return self.expiry_date < timezone.now().date()
        return False

    @property
    def file_size_mb(self):
        """Get file size in MB"""
        if self.file_size:
            return round(self.file_size / (1024 * 1024), 2)
        return 0


class DocumentVersion(models.Model):
    """Document version history"""
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='versions')
    version_number = models.PositiveIntegerField()
    file = models.FileField(upload_to=document_upload_path)
    file_size = models.PositiveIntegerField()
    change_summary = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document_versions'
        ordering = ['-version_number']
        unique_together = ['document', 'version_number']

    def __str__(self):
        return f"{self.document.document_number} v{self.version_number}"


class DocumentApproval(models.Model):
    """Document approval workflow"""
    APPROVAL_STATUS = [
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
        ('DELEGATED', 'Delegated'),
    ]

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='approvals')
    approver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='document_approvals')
    status = models.CharField(max_length=20, choices=APPROVAL_STATUS, default='PENDING')
    comments = models.TextField(blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    delegated_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='delegated_approvals')

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'document_approvals'
        ordering = ['-created_at']
        unique_together = ['document', 'approver']

    def __str__(self):
        return f"{self.document.document_number} - {self.approver.username} ({self.status})"


class DocumentTemplate(models.Model):
    """Document templates for generating standard documents"""
    name = models.CharField(max_length=200)
    document_type = models.ForeignKey(DocumentType, on_delete=models.CASCADE, related_name='templates')
    template_file = models.FileField(upload_to='document_templates/')
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'document_templates'
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.document_type})"


class DocumentShare(models.Model):
    """Document sharing with external parties"""
    SHARE_TYPE = [
        ('VIEW', 'View Only'),
        ('DOWNLOAD', 'Download'),
        ('EDIT', 'Edit'),
    ]

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='shares')
    shared_with_email = models.EmailField()
    share_type = models.CharField(max_length=10, choices=SHARE_TYPE, default='VIEW')
    access_token = models.UUIDField(default=uuid.uuid4, unique=True)
    expires_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    accessed_at = models.DateTimeField(null=True, blank=True)
    access_count = models.PositiveIntegerField(default=0)

    # Tracking
    shared_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document_shares'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.document.document_number} shared with {self.shared_with_email}"

    @property
    def is_expired(self):
        """Check if share link is expired"""
        from django.utils import timezone
        return self.expires_at < timezone.now()


class DocumentComment(models.Model):
    """Comments on documents"""
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.TextField()
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='replies')
    is_internal = models.BooleanField(default=True, help_text="Internal comments not visible to customers")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'document_comments'
        ordering = ['created_at']

    def __str__(self):
        return f"Comment on {self.document.document_number} by {self.user.username}"


class DocumentAuditLog(models.Model):
    """Audit log for document changes"""
    ACTION_CHOICES = [
        ('CREATE', 'Created'),
        ('UPDATE', 'Updated'),
        ('DELETE', 'Deleted'),
        ('APPROVE', 'Approved'),
        ('REJECT', 'Rejected'),
        ('SHARE', 'Shared'),
        ('DOWNLOAD', 'Downloaded'),
        ('VIEW', 'Viewed'),
    ]

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='audit_logs')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    details = models.JSONField(default=dict, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document_audit_logs'
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.action} on {self.document.document_number} by {self.user.username}"
