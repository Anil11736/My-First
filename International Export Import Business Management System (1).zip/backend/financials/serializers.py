from rest_framework import serializers
from .models import Invoice, InvoiceItem, Payment, Currency, ExchangeRate
from customers.serializers import CustomerSerializer


class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = ['id', 'code', 'name', 'symbol', 'is_active']
        read_only_fields = ['id']


class ExchangeRateSerializer(serializers.ModelSerializer):
    from_currency = CurrencySerializer(read_only=True)
    to_currency = CurrencySerializer(read_only=True)

    class Meta:
        model = ExchangeRate
        fields = [
            'id', 'from_currency', 'to_currency', 'rate', 'date', 'source'
        ]
        read_only_fields = ['id']


class InvoiceItemSerializer(serializers.ModelSerializer):
    total_amount = serializers.SerializerMethodField()

    class Meta:
        model = InvoiceItem
        fields = [
            'id', 'description', 'quantity', 'unit_price', 'tax_rate',
            'total_amount'
        ]
        read_only_fields = ['id']

    def get_total_amount(self, obj):
        subtotal = obj.quantity * obj.unit_price
        tax_amount = subtotal * (obj.tax_rate / 100)
        return subtotal + tax_amount


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'id', 'amount', 'payment_date', 'payment_method',
            'reference_number', 'notes', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class InvoiceSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer(read_only=True)
    customer_id = serializers.IntegerField(write_only=True)
    items = InvoiceItemSerializer(many=True, read_only=True)
    payments = PaymentSerializer(many=True, read_only=True)
    currency_info = CurrencySerializer(source='currency', read_only=True)
    subtotal = serializers.SerializerMethodField()
    tax_amount = serializers.SerializerMethodField()
    paid_amount = serializers.SerializerMethodField()
    balance_due = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            'id', 'invoice_number', 'customer', 'customer_id', 'invoice_date',
            'due_date', 'currency', 'currency_info', 'exchange_rate',
            'subtotal_amount', 'tax_amount', 'total_amount', 'status',
            'payment_terms', 'notes', 'created_at', 'updated_at',
            'items', 'payments', 'subtotal', 'paid_amount', 'balance_due'
        ]
        read_only_fields = ['id', 'invoice_number', 'created_at', 'updated_at']

    def get_subtotal(self, obj):
        return sum(item.quantity * item.unit_price for item in obj.items.all())

    def get_tax_amount(self, obj):
        return sum(
            item.quantity * item.unit_price * (item.tax_rate / 100)
            for item in obj.items.all()
        )

    def get_paid_amount(self, obj):
        return sum(payment.amount for payment in obj.payments.all())

    def get_balance_due(self, obj):
        return obj.total_amount - self.get_paid_amount(obj)


class InvoiceCreateSerializer(serializers.ModelSerializer):
    items = InvoiceItemSerializer(many=True)

    class Meta:
        model = Invoice
        fields = [
            'customer_id', 'invoice_date', 'due_date', 'currency',
            'payment_terms', 'notes', 'items'
        ]

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        invoice = Invoice.objects.create(**validated_data)

        subtotal = 0
        tax_total = 0

        for item_data in items_data:
            item = InvoiceItem.objects.create(invoice=invoice, **item_data)
            item_subtotal = item.quantity * item.unit_price
            item_tax = item_subtotal * (item.tax_rate / 100)
            subtotal += item_subtotal
            tax_total += item_tax

        invoice.subtotal_amount = subtotal
        invoice.tax_amount = tax_total
        invoice.total_amount = subtotal + tax_total
        invoice.save()

        return invoice


class InvoiceListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.company_name', read_only=True)
    balance_due = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            'id', 'invoice_number', 'customer_name', 'invoice_date',
            'due_date', 'total_amount', 'status', 'balance_due'
        ]

    def get_balance_due(self, obj):
        paid_amount = sum(payment.amount for payment in obj.payments.all())
        return obj.total_amount - paid_amount


class PaymentCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'invoice', 'amount', 'payment_date', 'payment_method',
            'reference_number', 'notes'
        ]

    def validate(self, attrs):
        invoice = attrs['invoice']
        amount = attrs['amount']

        paid_amount = sum(payment.amount for payment in invoice.payments.all())
        balance_due = invoice.total_amount - paid_amount

        if amount > balance_due:
            raise serializers.ValidationError(
                f"Payment amount cannot exceed balance due of {balance_due}"
            )

        return attrs


class FinancialReportSerializer(serializers.Serializer):
    period = serializers.CharField()
    total_revenue = serializers.DecimalField(max_digits=15, decimal_places=2)
    total_payments = serializers.DecimalField(max_digits=15, decimal_places=2)
    outstanding_amount = serializers.DecimalField(max_digits=15, decimal_places=2)
    invoice_count = serializers.IntegerField()
    paid_invoice_count = serializers.IntegerField()
    overdue_invoice_count = serializers.IntegerField()
