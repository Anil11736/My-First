default_app_config = 'financials.apps.FinancialsConfig'
