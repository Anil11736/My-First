from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.core.paginator import Paginator
from django.db.models import Q, Sum, Count
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.template.loader import render_to_string
from django.conf import settings
import json
from datetime import datetime, timedelta
from decimal import Decimal
import csv
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet

from .models import Invoice, Payment, FinancialReport, PaymentMethod
from .forms import InvoiceForm, PaymentForm, FinancialReportForm
from customers.models import Customer
from shipments.models import Shipment


@login_required
def financial_dashboard(request):
    """Financial dashboard with key metrics and charts"""
    # Calculate key metrics
    total_invoices = Invoice.objects.count()
    pending_invoices = Invoice.objects.filter(status='pending').count()
    paid_invoices = Invoice.objects.filter(status='paid').count()
    overdue_invoices = Invoice.objects.filter(
        status='pending',
        due_date__lt=timezone.now().date()
    ).count()

    # Revenue metrics
    total_revenue = Invoice.objects.filter(status='paid').aggregate(
        total=Sum('total_amount')
    )['total'] or Decimal('0.00')

    pending_amount = Invoice.objects.filter(status='pending').aggregate(
        total=Sum('total_amount')
    )['total'] or Decimal('0.00')

    # Monthly revenue data for charts
    current_year = timezone.now().year
    monthly_revenue = []
    for month in range(1, 13):
        revenue = Invoice.objects.filter(
            status='paid',
            invoice_date__year=current_year,
            invoice_date__month=month
        ).aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')
        monthly_revenue.append(float(revenue))

    # Recent invoices
    recent_invoices = Invoice.objects.select_related('customer').order_by('-created_at')[:5]

    # Recent payments
    recent_payments = Payment.objects.select_related('invoice__customer').order_by('-payment_date')[:5]

    context = {
        'total_invoices': total_invoices,
        'pending_invoices': pending_invoices,
        'paid_invoices': paid_invoices,
        'overdue_invoices': overdue_invoices,
        'total_revenue': total_revenue,
        'pending_amount': pending_amount,
        'monthly_revenue': monthly_revenue,
        'recent_invoices': recent_invoices,
        'recent_payments': recent_payments,
    }

    return render(request, 'financials/dashboard.html', context)


@login_required
def invoice_list(request):
    """List all invoices with filtering and pagination"""
    invoices = Invoice.objects.select_related('customer').order_by('-created_at')

    # Filtering
    status_filter = request.GET.get('status')
    customer_filter = request.GET.get('customer')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    search = request.GET.get('search')

    if status_filter:
        invoices = invoices.filter(status=status_filter)

    if customer_filter:
        invoices = invoices.filter(customer_id=customer_filter)

    if date_from:
        invoices = invoices.filter(invoice_date__gte=date_from)

    if date_to:
        invoices = invoices.filter(invoice_date__lte=date_to)

    if search:
        invoices = invoices.filter(
            Q(invoice_number__icontains=search) |
            Q(customer__company_name__icontains=search) |
            Q(description__icontains=search)
        )

    # Pagination
    paginator = Paginator(invoices, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Get customers for filter dropdown
    customers = Customer.objects.all().order_by('company_name')

    context = {
        'page_obj': page_obj,
        'customers': customers,
        'status_filter': status_filter,
        'customer_filter': customer_filter,
        'date_from': date_from,
        'date_to': date_to,
        'search': search,
    }

    return render(request, 'financials/invoice_list.html', context)


@login_required
def invoice_detail(request, invoice_id):
    """View invoice details"""
    invoice = get_object_or_404(Invoice, id=invoice_id)
    payments = Payment.objects.filter(invoice=invoice).order_by('-payment_date')

    context = {
        'invoice': invoice,
        'payments': payments,
    }

    return render(request, 'financials/invoice_detail.html', context)


@login_required
def invoice_create(request):
    """Create new invoice"""
    if request.method == 'POST':
        form = InvoiceForm(request.POST)
        if form.is_valid():
            invoice = form.save(commit=False)
            invoice.created_by = request.user
            invoice.save()
            messages.success(request, 'Invoice created successfully.')
            return redirect('financials:invoice_detail', invoice_id=invoice.id)
    else:
        form = InvoiceForm()

        # Pre-fill from shipment if provided
        shipment_id = request.GET.get('shipment')
        if shipment_id:
            try:
                shipment = Shipment.objects.get(id=shipment_id)
                form.initial = {
                    'customer': shipment.customer,
                    'description': f'Shipment #{shipment.tracking_number}',
                    'amount': shipment.total_value,
                }
            except Shipment.DoesNotExist:
                pass

    context = {
        'form': form,
        'title': 'Create Invoice',
    }

    return render(request, 'financials/invoice_form.html', context)


@login_required
def invoice_edit(request, invoice_id):
    """Edit existing invoice"""
    invoice = get_object_or_404(Invoice, id=invoice_id)

    if invoice.status == 'paid':
        messages.error(request, 'Cannot edit paid invoices.')
        return redirect('financials:invoice_detail', invoice_id=invoice.id)

    if request.method == 'POST':
        form = InvoiceForm(request.POST, instance=invoice)
        if form.is_valid():
            form.save()
            messages.success(request, 'Invoice updated successfully.')
            return redirect('financials:invoice_detail', invoice_id=invoice.id)
    else:
        form = InvoiceForm(instance=invoice)

    context = {
        'form': form,
        'invoice': invoice,
        'title': 'Edit Invoice',
    }

    return render(request, 'financials/invoice_form.html', context)


@login_required
@require_http_methods(["POST"])
def invoice_delete(request, invoice_id):
    """Delete invoice"""
    invoice = get_object_or_404(Invoice, id=invoice_id)

    if invoice.status == 'paid':
        messages.error(request, 'Cannot delete paid invoices.')
        return redirect('financials:invoice_detail', invoice_id=invoice.id)

    invoice.delete()
    messages.success(request, 'Invoice deleted successfully.')
    return redirect('financials:invoice_list')


@login_required
def invoice_pdf(request, invoice_id):
    """Generate PDF for invoice"""
    invoice = get_object_or_404(Invoice, id=invoice_id)

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="invoice_{invoice.invoice_number}.pdf"'

    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    # Company header
    story.append(Paragraph("Export Import Business", styles['Title']))
    story.append(Paragraph("<br/><br/>", styles['Normal']))

    # Invoice details
    story.append(Paragraph(f"Invoice #{invoice.invoice_number}", styles['Heading1']))
    story.append(Paragraph(f"Date: {invoice.invoice_date}", styles['Normal']))
    story.append(Paragraph(f"Due Date: {invoice.due_date}", styles['Normal']))
    story.append(Paragraph("<br/>", styles['Normal']))

    # Customer details
    story.append(Paragraph("Bill To:", styles['Heading2']))
    story.append(Paragraph(f"{invoice.customer.company_name}", styles['Normal']))
    story.append(Paragraph(f"{invoice.customer.address}", styles['Normal']))
    story.append(Paragraph(f"{invoice.customer.email}", styles['Normal']))
    story.append(Paragraph("<br/>", styles['Normal']))

    # Invoice items table
    data = [
        ['Description', 'Amount', 'Tax', 'Total'],
        [invoice.description, f"${invoice.amount}", f"${invoice.tax_amount}", f"${invoice.total_amount}"]
    ]

    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))

    story.append(table)
    doc.build(story)

    return response


@login_required
def payment_list(request):
    """List all payments with filtering"""
    payments = Payment.objects.select_related('invoice__customer').order_by('-payment_date')

    # Filtering
    method_filter = request.GET.get('method')
    customer_filter = request.GET.get('customer')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')

    if method_filter:
        payments = payments.filter(payment_method=method_filter)

    if customer_filter:
        payments = payments.filter(invoice__customer_id=customer_filter)

    if date_from:
        payments = payments.filter(payment_date__gte=date_from)

    if date_to:
        payments = payments.filter(payment_date__lte=date_to)

    # Pagination
    paginator = Paginator(payments, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Get filter options
    customers = Customer.objects.all().order_by('company_name')
    payment_methods = PaymentMethod.objects.all()

    context = {
        'page_obj': page_obj,
        'customers': customers,
        'payment_methods': payment_methods,
        'method_filter': method_filter,
        'customer_filter': customer_filter,
        'date_from': date_from,
        'date_to': date_to,
    }

    return render(request, 'financials/payment_list.html', context)


@login_required
def payment_create(request):
    """Create new payment"""
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.recorded_by = request.user
            payment.save()

            # Update invoice status if fully paid
            invoice = payment.invoice
            total_payments = Payment.objects.filter(invoice=invoice).aggregate(
                total=Sum('amount')
            )['total'] or Decimal('0.00')

            if total_payments >= invoice.total_amount:
                invoice.status = 'paid'
                invoice.save()

            messages.success(request, 'Payment recorded successfully.')
            return redirect('financials:payment_list')
    else:
        form = PaymentForm()

        # Pre-fill invoice if provided
        invoice_id = request.GET.get('invoice')
        if invoice_id:
            form.initial = {'invoice': invoice_id}

    context = {
        'form': form,
        'title': 'Record Payment',
    }

    return render(request, 'financials/payment_form.html', context)


@login_required
def financial_reports(request):
    """Financial reports dashboard"""
    # Date range for reports
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)

    if request.GET.get('start_date'):
        start_date = datetime.strptime(request.GET.get('start_date'), '%Y-%m-%d').date()
    if request.GET.get('end_date'):
        end_date = datetime.strptime(request.GET.get('end_date'), '%Y-%m-%d').date()

    # Revenue report
    revenue_data = Invoice.objects.filter(
        status='paid',
        invoice_date__range=[start_date, end_date]
    ).aggregate(
        total_revenue=Sum('total_amount'),
        total_invoices=Count('id')
    )

    # Outstanding invoices
    outstanding_data = Invoice.objects.filter(
        status='pending'
    ).aggregate(
        total_outstanding=Sum('total_amount'),
        total_invoices=Count('id')
    )

    # Top customers by revenue
    top_customers = Customer.objects.annotate(
        total_revenue=Sum('invoice__total_amount', filter=Q(invoice__status='paid'))
    ).filter(total_revenue__isnull=False).order_by('-total_revenue')[:10]

    # Monthly trends
    monthly_data = []
    current_date = start_date.replace(day=1)
    while current_date <= end_date:
        next_month = (current_date.replace(day=28) + timedelta(days=4)).replace(day=1)
        revenue = Invoice.objects.filter(
            status='paid',
            invoice_date__range=[current_date, next_month - timedelta(days=1)]
        ).aggregate(total=Sum('total_amount'))['total'] or Decimal('0.00')

        monthly_data.append({
            'month': current_date.strftime('%B %Y'),
            'revenue': revenue
        })
        current_date = next_month

    context = {
        'start_date': start_date,
        'end_date': end_date,
        'revenue_data': revenue_data,
        'outstanding_data': outstanding_data,
        'top_customers': top_customers,
        'monthly_data': monthly_data,
    }

    return render(request, 'financials/reports.html', context)


@login_required
def export_financial_data(request):
    """Export financial data to CSV"""
    format_type = request.GET.get('format', 'csv')
    report_type = request.GET.get('type', 'invoices')

    if report_type == 'invoices':
        queryset = Invoice.objects.select_related('customer').all()
        filename = f'invoices_{timezone.now().strftime("%Y%m%d")}'
    else:
        queryset = Payment.objects.select_related('invoice__customer').all()
        filename = f'payments_{timezone.now().strftime("%Y%m%d")}'

    if format_type == 'csv':
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'

        writer = csv.writer(response)

        if report_type == 'invoices':
            writer.writerow(['Invoice Number', 'Customer', 'Date', 'Amount', 'Status', 'Due Date'])
            for invoice in queryset:
                writer.writerow([
                    invoice.invoice_number,
                    invoice.customer.company_name,
                    invoice.invoice_date,
                    invoice.total_amount,
                    invoice.status,
                    invoice.due_date
                ])
        else:
            writer.writerow(['Payment Date', 'Invoice Number', 'Customer', 'Amount', 'Method'])
            for payment in queryset:
                writer.writerow([
                    payment.payment_date,
                    payment.invoice.invoice_number,
                    payment.invoice.customer.company_name,
                    payment.amount,
                    payment.payment_method
                ])

        return response

    return JsonResponse({'error': 'Invalid format'}, status=400)


@login_required
@csrf_exempt
def ajax_invoice_status(request, invoice_id):
    """Update invoice status via AJAX"""
    if request.method == 'POST':
        invoice = get_object_or_404(Invoice, id=invoice_id)
        new_status = request.POST.get('status')

        if new_status in ['pending', 'paid', 'cancelled']:
            invoice.status = new_status
            invoice.save()

            return JsonResponse({
                'success': True,
                'message': f'Invoice status updated to {new_status}',
                'status': new_status
            })

    return JsonResponse({'success': False, 'message': 'Invalid request'})


@login_required
def get_invoice_data(request, invoice_id):
    """Get invoice data for AJAX requests"""
    invoice = get_object_or_404(Invoice, id=invoice_id)

    data = {
        'invoice_number': invoice.invoice_number,
        'customer': invoice.customer.company_name,
        'amount': str(invoice.total_amount),
        'status': invoice.status,
        'due_date': invoice.due_date.isoformat(),
        'remaining_amount': str(invoice.total_amount - (invoice.payment_set.aggregate(
            total=Sum('amount')
        )['total'] or Decimal('0.00')))
    }

    return JsonResponse(data)
