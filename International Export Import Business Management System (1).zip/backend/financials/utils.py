# -*- coding: utf-8 -*-
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Optional, Union
import requests
from django.conf import settings
from django.core.cache import cache
import logging

logger = logging.getLogger(__name__)

# Default exchange rates (fallback if API fails)
DEFAULT_RATES = {
    'USD': Decimal('1.00'),
    'EUR': Decimal('0.85'),
    'GBP': Decimal('0.73'),
    'JPY': Decimal('110.00'),
    'INR': Decimal('83.00'),
    'CNY': Decimal('7.20'),
    'CAD': Decimal('1.35'),
    'AUD': Decimal('1.50'),
}

class CurrencyConverter:
    """Handle currency conversion with caching and fallback rates"""

    def __init__(self):
        self.base_currency = getattr(settings, 'BASE_CURRENCY', 'USD')
        self.api_key = getattr(settings, 'EXCHANGE_RATE_API_KEY', None)
        self.cache_timeout = 3600  # 1 hour

    def get_exchange_rates(self) -> Dict[str, Decimal]:
        """Get current exchange rates with caching"""
        cache_key = 'exchange_rates'
        rates = cache.get(cache_key)

        if rates is None:
            try:
                rates = self._fetch_rates_from_api()
                cache.set(cache_key, rates, self.cache_timeout)
            except Exception as e:
                logger.warning(f"Failed to fetch exchange rates: {e}")
                rates = DEFAULT_RATES
                cache.set(cache_key, rates, 300)  # Cache for 5 minutes on error

        return rates

    def _fetch_rates_from_api(self) -> Dict[str, Decimal]:
        """Fetch exchange rates from external API"""
        if not self.api_key:
            return DEFAULT_RATES

        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{self.base_currency}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()

            data = response.json()
            rates = {}

            for currency, rate in data.get('rates', {}).items():
                rates[currency] = Decimal(str(rate))

            # Ensure base currency is included
            rates[self.base_currency] = Decimal('1.00')

            return rates
        except Exception as e:
            logger.error(f"API request failed: {e}")
            raise

    def convert(self, amount: Union[Decimal, float, str],
                from_currency: str, to_currency: str) -> Decimal:
        """Convert amount from one currency to another"""
        if from_currency == to_currency:
            return Decimal(str(amount))

        amount = Decimal(str(amount))
        rates = self.get_exchange_rates()

        if from_currency not in rates or to_currency not in rates:
            raise ValueError(f"Currency not supported: {from_currency} or {to_currency}")

        # Convert to base currency first, then to target currency
        if from_currency != self.base_currency:
            amount = amount / rates[from_currency]

        if to_currency != self.base_currency:
            amount = amount * rates[to_currency]

        return amount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

# Global converter instance
converter = CurrencyConverter()

def convert_currency(amount: Union[Decimal, float, str],
                    from_currency: str, to_currency: str) -> Decimal:
    """Convert currency amount"""
    return converter.convert(amount, from_currency, to_currency)

def calculate_total_cost(unit_price: Decimal, quantity: int,
                        currency: str = 'USD') -> Decimal:
    """Calculate total cost for given quantity"""
    total = unit_price * Decimal(str(quantity))
    return total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_profit_margin(cost_price: Decimal, selling_price: Decimal) -> Decimal:
    """Calculate profit margin percentage"""
    if cost_price <= 0:
        return Decimal('0.00')

    profit = selling_price - cost_price
    margin = (profit / cost_price) * Decimal('100')
    return margin.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_markup(cost_price: Decimal, selling_price: Decimal) -> Decimal:
    """Calculate markup percentage"""
    if cost_price <= 0:
        return Decimal('0.00')

    markup = ((selling_price - cost_price) / cost_price) * Decimal('100')
    return markup.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_discount(original_price: Decimal, discounted_price: Decimal) -> Decimal:
    """Calculate discount percentage"""
    if original_price <= 0:
        return Decimal('0.00')

    discount = ((original_price - discounted_price) / original_price) * Decimal('100')
    return discount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_tax(amount: Decimal, tax_rate: Decimal) -> Decimal:
    """Calculate tax amount"""
    tax = amount * (tax_rate / Decimal('100'))
    return tax.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_amount_with_tax(amount: Decimal, tax_rate: Decimal) -> Decimal:
    """Calculate total amount including tax"""
    tax = calculate_tax(amount, tax_rate)
    return amount + tax

def calculate_shipping_cost(weight: Decimal, distance: Decimal,
                          rate_per_kg_km: Decimal = Decimal('0.01')) -> Decimal:
    """Calculate shipping cost based on weight and distance"""
    cost = weight * distance * rate_per_kg_km
    return cost.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_insurance_cost(shipment_value: Decimal,
                           insurance_rate: Decimal = Decimal('0.5')) -> Decimal:
    """Calculate insurance cost as percentage of shipment value"""
    cost = shipment_value * (insurance_rate / Decimal('100'))
    return cost.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def format_currency(amount: Decimal, currency: str = 'USD') -> str:
    """Format currency amount for display"""
    currency_symbols = {
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'JPY': '¥',
        'INR': '₹',
        'CNY': '¥',
        'CAD': 'C$',
        'AUD': 'A$',
    }

    symbol = currency_symbols.get(currency, currency + ' ')

    if currency == 'JPY':
        # Japanese Yen doesn't use decimal places
        return f"{symbol}{amount.quantize(Decimal('1'))}"

    return f"{symbol}{amount:,.2f}"

def validate_currency_code(currency: str) -> bool:
    """Validate if currency code is supported"""
    rates = converter.get_exchange_rates()
    return currency.upper() in rates

def get_supported_currencies() -> list:
    """Get list of supported currency codes"""
    rates = converter.get_exchange_rates()
    return sorted(rates.keys())

def calculate_payment_terms_discount(amount: Decimal, days_early: int,
                                   discount_rate: Decimal = Decimal('2.0')) -> Decimal:
    """Calculate early payment discount"""
    if days_early <= 0:
        return Decimal('0.00')

    # Standard 2/10 net 30 terms - 2% discount if paid within 10 days
    if days_early >= 10:
        discount = amount * (discount_rate / Decimal('100'))
        return discount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    return Decimal('0.00')

def calculate_letter_of_credit_fee(amount: Decimal,
                                  fee_rate: Decimal = Decimal('0.125')) -> Decimal:
    """Calculate Letter of Credit processing fee"""
    fee = amount * (fee_rate / Decimal('100'))
    return fee.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_customs_duty(value: Decimal, duty_rate: Decimal) -> Decimal:
    """Calculate customs duty amount"""
    duty = value * (duty_rate / Decimal('100'))
    return duty.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def calculate_total_landed_cost(product_cost: Decimal, shipping_cost: Decimal,
                               insurance_cost: Decimal, customs_duty: Decimal,
                               other_fees: Decimal = Decimal('0.00')) -> Decimal:
    """Calculate total landed cost including all fees"""
    total = product_cost + shipping_cost + insurance_cost + customs_duty + other_fees
    return total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

class FinancialCalculator:
    """Advanced financial calculations for import/export business"""

    @staticmethod
    def calculate_roi(initial_investment: Decimal, final_value: Decimal) -> Decimal:
        """Calculate Return on Investment percentage"""
        if initial_investment <= 0:
            return Decimal('0.00')

        roi = ((final_value - initial_investment) / initial_investment) * Decimal('100')
        return roi.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    @staticmethod
    def calculate_break_even_quantity(fixed_costs: Decimal, unit_price: Decimal,
                                    variable_cost_per_unit: Decimal) -> int:
        """Calculate break-even quantity"""
        if unit_price <= variable_cost_per_unit:
            return 0

        contribution_margin = unit_price - variable_cost_per_unit
        break_even = fixed_costs / contribution_margin
        return int(break_even.quantize(Decimal('1'), rounding=ROUND_HALF_UP))

    @staticmethod
    def calculate_working_capital(current_assets: Decimal,
                                current_liabilities: Decimal) -> Decimal:
        """Calculate working capital"""
        return current_assets - current_liabilities

    @staticmethod
    def calculate_inventory_turnover(cost_of_goods_sold: Decimal,
                                   average_inventory: Decimal) -> Decimal:
        """Calculate inventory turnover ratio"""
        if average_inventory <= 0:
            return Decimal('0.00')

        turnover = cost_of_goods_sold / average_inventory
        return turnover.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
