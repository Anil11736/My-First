from django.urls import path
from . import views

app_name = 'financials'

urlpatterns = [
    # Dashboard
    path('', views.financial_dashboard, name='dashboard'),

    # Invoices
    path('invoices/', views.invoice_list, name='invoice_list'),
    path('invoices/create/', views.invoice_create, name='invoice_create'),
    path('invoices/<int:pk>/', views.invoice_detail, name='invoice_detail'),
    path('invoices/<int:pk>/edit/', views.invoice_edit, name='invoice_edit'),
    path('invoices/<int:pk>/delete/', views.invoice_delete, name='invoice_delete'),
    path('invoices/<int:pk>/pdf/', views.invoice_pdf, name='invoice_pdf'),
    path('invoices/<int:pk>/send/', views.invoice_send, name='invoice_send'),
    path('invoices/<int:pk>/mark-paid/', views.invoice_mark_paid, name='invoice_mark_paid'),

    # Payments
    path('payments/', views.payment_list, name='payment_list'),
    path('payments/create/', views.payment_create, name='payment_create'),
    path('payments/<int:pk>/', views.payment_detail, name='payment_detail'),
    path('payments/<int:pk>/edit/', views.payment_edit, name='payment_edit'),
    path('payments/<int:pk>/delete/', views.payment_delete, name='payment_delete'),

    # Expenses
    path('expenses/', views.expense_list, name='expense_list'),
    path('expenses/create/', views.expense_create, name='expense_create'),
    path('expenses/<int:pk>/', views.expense_detail, name='expense_detail'),
    path('expenses/<int:pk>/edit/', views.expense_edit, name='expense_edit'),
    path('expenses/<int:pk>/delete/', views.expense_delete, name='expense_delete'),

    # Financial Reports
    path('reports/', views.financial_reports, name='reports'),
    path('reports/profit-loss/', views.profit_loss_report, name='profit_loss_report'),
    path('reports/cash-flow/', views.cash_flow_report, name='cash_flow_report'),
    path('reports/accounts-receivable/', views.accounts_receivable_report, name='accounts_receivable_report'),
    path('reports/accounts-payable/', views.accounts_payable_report, name='accounts_payable_report'),
    path('reports/tax-summary/', views.tax_summary_report, name='tax_summary_report'),
    path('reports/export/', views.export_financial_report, name='export_report'),

    # Currency Management
    path('currencies/', views.currency_list, name='currency_list'),
    path('currencies/rates/', views.exchange_rates, name='exchange_rates'),
    path('currencies/update-rates/', views.update_exchange_rates, name='update_exchange_rates'),

    # Banking
    path('bank-accounts/', views.bank_account_list, name='bank_account_list'),
    path('bank-accounts/create/', views.bank_account_create, name='bank_account_create'),
    path('bank-accounts/<int:pk>/', views.bank_account_detail, name='bank_account_detail'),
    path('bank-accounts/<int:pk>/edit/', views.bank_account_edit, name='bank_account_edit'),
    path('bank-accounts/<int:pk>/delete/', views.bank_account_delete, name='bank_account_delete'),
    path('bank-accounts/<int:pk>/transactions/', views.bank_transactions, name='bank_transactions'),

    # Budget Management
    path('budgets/', views.budget_list, name='budget_list'),
    path('budgets/create/', views.budget_create, name='budget_create'),
    path('budgets/<int:pk>/', views.budget_detail, name='budget_detail'),
    path('budgets/<int:pk>/edit/', views.budget_edit, name='budget_edit'),
    path('budgets/<int:pk>/delete/', views.budget_delete, name='budget_delete'),

    # Tax Management
    path('taxes/', views.tax_list, name='tax_list'),
    path('taxes/create/', views.tax_create, name='tax_create'),
    path('taxes/<int:pk>/', views.tax_detail, name='tax_detail'),
    path('taxes/<int:pk>/edit/', views.tax_edit, name='tax_edit'),
    path('taxes/<int:pk>/delete/', views.tax_delete, name='tax_delete'),

    # Financial Analytics
    path('analytics/', views.financial_analytics, name='analytics'),
    path('analytics/revenue-trends/', views.revenue_trends, name='revenue_trends'),
    path('analytics/expense-breakdown/', views.expense_breakdown, name='expense_breakdown'),
    path('analytics/profitability/', views.profitability_analysis, name='profitability_analysis'),

    # API endpoints for AJAX calls
    path('api/invoice-status/', views.update_invoice_status, name='api_invoice_status'),
    path('api/payment-reminder/', views.send_payment_reminder, name='api_payment_reminder'),
    path('api/financial-summary/', views.financial_summary_api, name='api_financial_summary'),
    path('api/chart-data/', views.chart_data_api, name='api_chart_data'),
]
