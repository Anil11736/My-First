from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from decimal import Decimal
import re

from .models import Invoice, Payment, InvoiceItem


class InvoiceForm(forms.ModelForm):
    """Form for creating and editing invoices"""

    class Meta:
        model = Invoice
        fields = [
            'invoice_number', 'shipment', 'customer_name', 'customer_email',
            'customer_address', 'billing_address', 'invoice_date', 'due_date',
            'currency', 'exchange_rate', 'tax_rate', 'discount_amount',
            'notes', 'terms_conditions'
        ]
        widgets = {
            'invoice_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}
            ),
            'due_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}
            ),
            'customer_name': forms.TextInput(
                attrs={'class': 'form-control', 'placeholder': 'Enter customer name'}
            ),
            'customer_email': forms.EmailInput(
                attrs={'class': 'form-control', 'placeholder': 'customer@example.com'}
            ),
            'customer_address': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Customer address'}
            ),
            'billing_address': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Billing address (if different)'}
            ),
            'currency': forms.Select(
                attrs={'class': 'form-select'}
            ),
            'exchange_rate': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.0001', 'min': '0.0001'}
            ),
            'tax_rate': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0', 'max': '100'}
            ),
            'discount_amount': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0'}
            ),
            'notes': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Additional notes'}
            ),
            'terms_conditions': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Terms and conditions'}
            ),
            'shipment': forms.Select(
                attrs={'class': 'form-select'}
            )
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Set default values
        if not self.instance.pk:
            self.fields['invoice_date'].initial = timezone.now().date()
            self.fields['due_date'].initial = timezone.now().date() + timezone.timedelta(days=30)
            self.fields['currency'].initial = 'USD'
            self.fields['exchange_rate'].initial = Decimal('1.0000')
            self.fields['tax_rate'].initial = Decimal('0.00')

        # Make certain fields required
        self.fields['customer_name'].required = True
        self.fields['customer_email'].required = True
        self.fields['invoice_date'].required = True
        self.fields['due_date'].required = True

    def clean_invoice_number(self):
        invoice_number = self.cleaned_data.get('invoice_number')
        if invoice_number:
            # Check for duplicate invoice numbers
            existing = Invoice.objects.filter(invoice_number=invoice_number)
            if self.instance.pk:
                existing = existing.exclude(pk=self.instance.pk)
            if existing.exists():
                raise ValidationError('Invoice number already exists.')

            # Validate format (alphanumeric with hyphens/underscores)
            if not re.match(r'^[A-Za-z0-9_-]+$', invoice_number):
                raise ValidationError('Invoice number can only contain letters, numbers, hyphens, and underscores.')

        return invoice_number

    def clean_due_date(self):
        due_date = self.cleaned_data.get('due_date')
        invoice_date = self.cleaned_data.get('invoice_date')

        if due_date and invoice_date:
            if due_date < invoice_date:
                raise ValidationError('Due date cannot be earlier than invoice date.')

        return due_date

    def clean_exchange_rate(self):
        exchange_rate = self.cleaned_data.get('exchange_rate')
        if exchange_rate and exchange_rate <= 0:
            raise ValidationError('Exchange rate must be greater than 0.')
        return exchange_rate

    def clean_tax_rate(self):
        tax_rate = self.cleaned_data.get('tax_rate')
        if tax_rate and (tax_rate < 0 or tax_rate > 100):
            raise ValidationError('Tax rate must be between 0 and 100 percent.')
        return tax_rate


class InvoiceItemForm(forms.ModelForm):
    """Form for adding items to an invoice"""

    class Meta:
        model = InvoiceItem
        fields = ['description', 'quantity', 'unit_price', 'discount_percent']
        widgets = {
            'description': forms.TextInput(
                attrs={'class': 'form-control', 'placeholder': 'Item description'}
            ),
            'quantity': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}
            ),
            'unit_price': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}
            ),
            'discount_percent': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0', 'max': '100'}
            )
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['description'].required = True
        self.fields['quantity'].required = True
        self.fields['unit_price'].required = True

        # Set default values
        if not self.instance.pk:
            self.fields['quantity'].initial = 1
            self.fields['discount_percent'].initial = 0

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity and quantity <= 0:
            raise ValidationError('Quantity must be greater than 0.')
        return quantity

    def clean_unit_price(self):
        unit_price = self.cleaned_data.get('unit_price')
        if unit_price and unit_price <= 0:
            raise ValidationError('Unit price must be greater than 0.')
        return unit_price

    def clean_discount_percent(self):
        discount_percent = self.cleaned_data.get('discount_percent')
        if discount_percent and (discount_percent < 0 or discount_percent > 100):
            raise ValidationError('Discount percent must be between 0 and 100.')
        return discount_percent


class PaymentForm(forms.ModelForm):
    """Form for recording payments against invoices"""

    class Meta:
        model = Payment
        fields = [
            'invoice', 'amount', 'payment_date', 'payment_method',
            'reference_number', 'bank_details', 'notes'
        ]
        widgets = {
            'payment_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}
            ),
            'amount': forms.NumberInput(
                attrs={'class': 'form-control', 'step': '0.01', 'min': '0.01'}
            ),
            'payment_method': forms.Select(
                attrs={'class': 'form-select'}
            ),
            'reference_number': forms.TextInput(
                attrs={'class': 'form-control', 'placeholder': 'Transaction/Check number'}
            ),
            'bank_details': forms.TextInput(
                attrs={'class': 'form-control', 'placeholder': 'Bank name, account details'}
            ),
            'notes': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Payment notes'}
            ),
            'invoice': forms.Select(
                attrs={'class': 'form-select'}
            )
        }

    def __init__(self, *args, **kwargs):
        invoice = kwargs.pop('invoice', None)
        super().__init__(*args, **kwargs)

        # Set default values
        if not self.instance.pk:
            self.fields['payment_date'].initial = timezone.now().date()
            if invoice:
                self.fields['invoice'].initial = invoice
                self.fields['invoice'].widget.attrs['readonly'] = True

        # Make fields required
        self.fields['amount'].required = True
        self.fields['payment_date'].required = True
        self.fields['payment_method'].required = True

        # Filter invoices to show only unpaid or partially paid ones
        if not invoice:
            self.fields['invoice'].queryset = Invoice.objects.filter(
                status__in=['draft', 'sent', 'partial']
            ).order_by('-created_at')

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount and amount <= 0:
            raise ValidationError('Payment amount must be greater than 0.')
        return amount

    def clean(self):
        cleaned_data = super().clean()
        invoice = cleaned_data.get('invoice')
        amount = cleaned_data.get('amount')

        if invoice and amount:
            # Check if payment amount doesn't exceed outstanding balance
            outstanding_balance = invoice.get_outstanding_balance()
            if amount > outstanding_balance:
                raise ValidationError(
                    f'Payment amount (${amount}) cannot exceed outstanding balance (${outstanding_balance}).'
                )

        return cleaned_data


class InvoiceSearchForm(forms.Form):
    """Form for searching and filtering invoices"""

    STATUS_CHOICES = [
        ('', 'All Statuses'),
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('partial', 'Partially Paid'),
        ('paid', 'Paid'),
        ('overdue', 'Overdue'),
        ('cancelled', 'Cancelled'),
    ]

    CURRENCY_CHOICES = [
        ('', 'All Currencies'),
        ('USD', 'USD'),
        ('EUR', 'EUR'),
        ('GBP', 'GBP'),
        ('JPY', 'JPY'),
        ('INR', 'INR'),
    ]

    search = forms.CharField(
        required=False,
        widget=forms.TextInput(
            attrs={'class': 'form-control', 'placeholder': 'Search by invoice number, customer name...'}
        )
    )

    status = forms.ChoiceField(
        choices=STATUS_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    currency = forms.ChoiceField(
        choices=CURRENCY_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(
            attrs={'type': 'date', 'class': 'form-control'}
        )
    )

    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(
            attrs={'type': 'date', 'class': 'form-control'}
        )
    )

    amount_min = forms.DecimalField(
        required=False,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={'class': 'form-control', 'step': '0.01', 'placeholder': 'Min amount'}
        )
    )

    amount_max = forms.DecimalField(
        required=False,
        decimal_places=2,
        widget=forms.NumberInput(
            attrs={'class': 'form-control', 'step': '0.01', 'placeholder': 'Max amount'}
        )
    )

    def clean(self):
        cleaned_data = super().clean()
        date_from = cleaned_data.get('date_from')
        date_to = cleaned_data.get('date_to')
        amount_min = cleaned_data.get('amount_min')
        amount_max = cleaned_data.get('amount_max')

        if date_from and date_to and date_from > date_to:
            raise ValidationError('Start date cannot be later than end date.')

        if amount_min and amount_max and amount_min > amount_max:
            raise ValidationError('Minimum amount cannot be greater than maximum amount.')

        return cleaned_data


# Formset for handling multiple invoice items
InvoiceItemFormSet = forms.inlineformset_factory(
    Invoice,
    InvoiceItem,
    form=InvoiceItemForm,
    extra=1,
    min_num=1,
    validate_min=True,
    can_delete=True
)
