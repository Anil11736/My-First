# -*- coding: utf-8 -*-
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.db.models import Sum
from .models import (
    Invoice, Payment, ExpenseCategory, Expense,
    BankAccount, CurrencyExchangeRate, FinancialReport
)


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = [
        'invoice_number', 'customer_name', 'invoice_date',
        'due_date', 'total_amount', 'currency', 'status',
        'payment_status_display'
    ]
    list_filter = [
        'status', 'currency', 'invoice_date', 'due_date',
        'created_at'
    ]
    search_fields = [
        'invoice_number', 'customer_name', 'customer_email',
        'description'
    ]
    readonly_fields = [
        'invoice_number', 'created_at', 'updated_at',
        'total_amount_display'
    ]
    fieldsets = (
        ('Invoice Information', {
            'fields': (
                'invoice_number', 'customer_name', 'customer_email',
                'customer_address', 'invoice_date', 'due_date'
            )
        }),
        ('Financial Details', {
            'fields': (
                'subtotal', 'tax_amount', 'discount_amount',
                'total_amount_display', 'currency'
            )
        }),
        ('Status & Notes', {
            'fields': ('status', 'description', 'notes')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    date_hierarchy = 'invoice_date'
    ordering = ['-invoice_date', '-created_at']

    def payment_status_display(self, obj):
        if obj.status == 'paid':
            color = 'green'
            icon = '✓'
        elif obj.status == 'overdue':
            color = 'red'
            icon = '⚠'
        elif obj.status == 'pending':
            color = 'orange'
            icon = '⏳'
        else:
            color = 'gray'
            icon = '○'

        return format_html(
            '<span style="color: {};">{} {}</span>',
            color, icon, obj.get_status_display()
        )
    payment_status_display.short_description = 'Payment Status'

    def total_amount_display(self, obj):
        return format_html(
            '<strong>{} {}</strong>',
            obj.currency, obj.total_amount
        )
    total_amount_display.short_description = 'Total Amount'

    actions = ['mark_as_paid', 'mark_as_overdue', 'export_invoices']

    def mark_as_paid(self, request, queryset):
        updated = queryset.update(status='paid')
        self.message_user(
            request,
            f'{updated} invoice(s) marked as paid.'
        )
    mark_as_paid.short_description = 'Mark selected invoices as paid'

    def mark_as_overdue(self, request, queryset):
        updated = queryset.update(status='overdue')
        self.message_user(
            request,
            f'{updated} invoice(s) marked as overdue.'
        )
    mark_as_overdue.short_description = 'Mark selected invoices as overdue'


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = [
        'payment_reference', 'invoice_link', 'amount',
        'currency', 'payment_method', 'payment_date',
        'status', 'bank_account'
    ]
    list_filter = [
        'status', 'payment_method', 'currency',
        'payment_date', 'bank_account'
    ]
    search_fields = [
        'payment_reference', 'invoice__invoice_number',
        'transaction_id', 'notes'
    ]
    readonly_fields = [
        'payment_reference', 'created_at', 'updated_at'
    ]
    fieldsets = (
        ('Payment Information', {
            'fields': (
                'payment_reference', 'invoice', 'amount',
                'currency', 'payment_date'
            )
        }),
        ('Payment Details', {
            'fields': (
                'payment_method', 'bank_account', 'transaction_id',
                'exchange_rate'
            )
        }),
        ('Status & Notes', {
            'fields': ('status', 'notes')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    date_hierarchy = 'payment_date'
    ordering = ['-payment_date', '-created_at']

    def invoice_link(self, obj):
        if obj.invoice:
            url = reverse(
                'admin:financials_invoice_change',
                args=[obj.invoice.pk]
            )
            return format_html(
                '<a href="{}">{}</a>',
                url, obj.invoice.invoice_number
            )
        return '-'
    invoice_link.short_description = 'Invoice'

    actions = ['confirm_payments', 'cancel_payments']

    def confirm_payments(self, request, queryset):
        updated = queryset.update(status='completed')
        self.message_user(
            request,
            f'{updated} payment(s) confirmed.'
        )
    confirm_payments.short_description = 'Confirm selected payments'


@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = [
        'name', 'code', 'description', 'is_active',
        'expense_count', 'total_expenses'
    ]
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'code', 'description']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['name']

    def expense_count(self, obj):
        return obj.expenses.count()
    expense_count.short_description = 'Number of Expenses'

    def total_expenses(self, obj):
        total = obj.expenses.aggregate(
            total=Sum('amount')
        )['total'] or 0
        return format_html('<strong>${:,.2f}</strong>', total)
    total_expenses.short_description = 'Total Expenses'


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = [
        'expense_number', 'category', 'amount', 'currency',
        'expense_date', 'vendor', 'status', 'approval_status'
    ]
    list_filter = [
        'category', 'status', 'currency', 'expense_date',
        'approval_status', 'created_at'
    ]
    search_fields = [
        'expense_number', 'description', 'vendor',
        'reference_number'
    ]
    readonly_fields = [
        'expense_number', 'created_at', 'updated_at'
    ]
    fieldsets = (
        ('Expense Information', {
            'fields': (
                'expense_number', 'category', 'description',
                'expense_date', 'vendor'
            )
        }),
        ('Financial Details', {
            'fields': (
                'amount', 'currency', 'tax_amount',
                'reference_number'
            )
        }),
        ('Approval & Status', {
            'fields': (
                'status', 'approval_status', 'approved_by',
                'approved_date'
            )
        }),
        ('Additional Information', {
            'fields': ('receipt_file', 'notes'),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    date_hierarchy = 'expense_date'
    ordering = ['-expense_date', '-created_at']

    actions = ['approve_expenses', 'reject_expenses', 'mark_as_paid']

    def approve_expenses(self, request, queryset):
        updated = queryset.update(
            approval_status='approved',
            approved_by=request.user,
            approved_date=timezone.now()
        )
        self.message_user(
            request,
            f'{updated} expense(s) approved.'
        )
    approve_expenses.short_description = 'Approve selected expenses'


@admin.register(BankAccount)
class BankAccountAdmin(admin.ModelAdmin):
    list_display = [
        'account_name', 'bank_name', 'account_number_masked',
        'currency', 'account_type', 'current_balance',
        'is_active'
    ]
    list_filter = [
        'currency', 'account_type', 'is_active', 'bank_name'
    ]
    search_fields = [
        'account_name', 'bank_name', 'account_number',
        'swift_code', 'iban'
    ]
    readonly_fields = [
        'created_at', 'updated_at', 'current_balance_display'
    ]
    fieldsets = (
        ('Account Information', {
            'fields': (
                'account_name', 'bank_name', 'account_number',
                'account_type', 'currency'
            )
        }),
        ('Banking Details', {
            'fields': (
                'swift_code', 'iban', 'routing_number',
                'branch_address'
            )
        }),
        ('Balance & Status', {
            'fields': (
                'current_balance_display', 'is_active'
            )
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    ordering = ['account_name']

    def account_number_masked(self, obj):
        if obj.account_number:
            return f"****{obj.account_number[-4:]}"
        return '-'
    account_number_masked.short_description = 'Account Number'

    def current_balance_display(self, obj):
        return format_html(
            '<strong>{} {:,.2f}</strong>',
            obj.currency, obj.current_balance
        )
    current_balance_display.short_description = 'Current Balance'


@admin.register(CurrencyExchangeRate)
class CurrencyExchangeRateAdmin(admin.ModelAdmin):
    list_display = [
        'from_currency', 'to_currency', 'rate',
        'effective_date', 'is_active', 'rate_change'
    ]
    list_filter = [
        'from_currency', 'to_currency', 'is_active',
        'effective_date'
    ]
    search_fields = ['from_currency', 'to_currency']
    readonly_fields = ['created_at', 'updated_at']
    date_hierarchy = 'effective_date'
    ordering = ['-effective_date', 'from_currency', 'to_currency']

    def rate_change(self, obj):
        # Get previous rate for comparison
        previous = CurrencyExchangeRate.objects.filter(
            from_currency=obj.from_currency,
            to_currency=obj.to_currency,
            effective_date__lt=obj.effective_date
        ).order_by('-effective_date').first()

        if previous:
            change = obj.rate - previous.rate
            percentage = (change / previous.rate) * 100
            color = 'green' if change > 0 else 'red' if change < 0 else 'gray'
            arrow = '↑' if change > 0 else '↓' if change < 0 else '→'

            return format_html(
                '<span style="color: {};">{} {:.4f} ({:+.2f}%)</span>',
                color, arrow, change, percentage
            )
        return '-'
    rate_change.short_description = 'Rate Change'


@admin.register(FinancialReport)
class FinancialReportAdmin(admin.ModelAdmin):
    list_display = [
        'report_name', 'report_type', 'period_start',
        'period_end', 'status', 'generated_by', 'created_at'
    ]
    list_filter = [
        'report_type', 'status', 'period_start',
        'period_end', 'created_at'
    ]
    search_fields = ['report_name', 'description']
    readonly_fields = [
        'created_at', 'updated_at', 'file_size_display'
    ]
    fieldsets = (
        ('Report Information', {
            'fields': (
                'report_name', 'report_type', 'description'
            )
        }),
        ('Period & Parameters', {
            'fields': (
                'period_start', 'period_end', 'parameters'
            )
        }),
        ('Generation Details', {
            'fields': (
                'status', 'generated_by', 'file_path',
                'file_size_display'
            )
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    date_hierarchy = 'created_at'
    ordering = ['-created_at']

    def file_size_display(self, obj):
        if obj.file_size:
            if obj.file_size < 1024:
                return f"{obj.file_size} B"
            elif obj.file_size < 1024 * 1024:
                return f"{obj.file_size / 1024:.1f} KB"
            else:
                return f"{obj.file_size / (1024 * 1024):.1f} MB"
        return '-'
    file_size_display.short_description = 'File Size'

    actions = ['regenerate_reports']

    def regenerate_reports(self, request, queryset):
        for report in queryset:
            # Trigger report regeneration task
            pass
        self.message_user(
            request,
            f'{queryset.count()} report(s) queued for regeneration.'
        )
    regenerate_reports.short_description = 'Regenerate selected reports'


# Custom admin site configuration
admin.site.site_header = 'Export-Import Business Management'
admin.site.site_title = 'Financial Management'
admin.site.index_title = 'Financial Administration'
