from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView

urlpatterns = [
    # Admin interface
    path('admin/', admin.site.urls),

    # API endpoints
    path('api/v1/auth/', include('accounts.urls')),
    path('api/v1/customers/', include('customers.urls')),
    path('api/v1/shipments/', include('shipments.urls')),
    path('api/v1/financials/', include('financials.urls')),
    path('api/v1/documents/', include('documents.urls')),
    path('api/v1/inventory/', include('inventory.urls')),

    # Web application URLs
    path('', include('core.urls')),
    path('accounts/', include('accounts.web_urls')),
    path('customers/', include('customers.web_urls')),
    path('shipments/', include('shipments.web_urls')),
    path('financials/', include('financials.web_urls')),
    path('documents/', include('documents.web_urls')),
    path('inventory/', include('inventory.web_urls')),

    # Redirect root to dashboard
    path('', RedirectView.as_view(url='/dashboard/', permanent=False)),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# Custom error handlers
handler404 = 'core.views.handler404'
handler500 = 'core.views.handler500'
handler403 = 'core.views.handler403'
handler400 = 'core.views.handler400'

# Admin site customization
admin.site.site_header = 'Export Import Management'
admin.site.site_title = 'Export Import Admin'
admin.site.index_title = 'Welcome to Export Import Management System'
