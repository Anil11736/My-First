"""
Export Import Business Management System

A comprehensive Django-based application for managing international
export and import business operations including shipments, customers,
financials, documents, and inventory.
"""

__version__ = "1.0.0"
__author__ = "Export Import Management Team"
__email__ = "admin@exportimport.com"
__description__ = "International Export Import Business Management System"

# This will make Celery app available when Django starts
from .celery import app as celery_app

__all__ = ('celery_app',)
