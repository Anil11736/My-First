import os
from celery import Celery
from django.conf import settings

# Set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'exportimport.settings')

app = Celery('exportimport')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Load task modules from all registered Django apps.
app.autodiscover_tasks()

# Celery configuration
app.conf.update(
    # Task serialization
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,

    # Task routing
    task_routes={
        'shipments.tasks.*': {'queue': 'shipments'},
        'documents.tasks.*': {'queue': 'documents'},
        'financials.tasks.*': {'queue': 'financials'},
        'inventory.tasks.*': {'queue': 'inventory'},
    },

    # Task execution
    task_always_eager=False,
    task_eager_propagates=True,
    task_ignore_result=False,
    task_store_eager_result=True,

    # Worker configuration
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=1000,
    worker_disable_rate_limits=False,

    # Beat schedule for periodic tasks
    beat_schedule={
        'update-shipment-status': {
            'task': 'shipments.tasks.update_shipment_status',
            'schedule': 300.0,  # Every 5 minutes
        },
        'generate-financial-reports': {
            'task': 'financials.tasks.generate_daily_reports',
            'schedule': 86400.0,  # Every 24 hours
        },
        'check-document-expiry': {
            'task': 'documents.tasks.check_document_expiry',
            'schedule': 3600.0,  # Every hour
        },
        'update-inventory-levels': {
            'task': 'inventory.tasks.update_inventory_levels',
            'schedule': 1800.0,  # Every 30 minutes
        },
    },

    # Result backend configuration
    result_expires=3600,  # Results expire after 1 hour
    result_persistent=True,

    # Error handling
    task_reject_on_worker_lost=True,
    task_acks_late=True,

    # Monitoring
    worker_send_task_events=True,
    task_send_sent_event=True,
)

@app.task(bind=True)
def debug_task(self):
    """Debug task for testing Celery configuration"""
    print(f'Request: {self.request!r}')
    return 'Debug task completed successfully'

# Error handling for tasks
@app.task(bind=True, autoretry_for=(Exception,), retry_kwargs={'max_retries': 3, 'countdown': 60})
def reliable_task(self, *args, **kwargs):
    """Base task with automatic retry on failure"""
    try:
        # Task logic here
        pass
    except Exception as exc:
        # Log the error
        print(f'Task failed: {exc}')
        raise self.retry(exc=exc)

# Task for sending notifications
@app.task
def send_notification(user_id, message, notification_type='info'):
    """Send notification to user"""
    from django.contrib.auth.models import User
    from django.core.mail import send_mail

    try:
        user = User.objects.get(id=user_id)

        # Send email notification
        send_mail(
            subject=f'Export/Import System - {notification_type.title()}',
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=False,
        )

        return f'Notification sent to {user.email}'
    except User.DoesNotExist:
        return f'User with ID {user_id} not found'
    except Exception as exc:
        return f'Failed to send notification: {exc}'

# Task for data cleanup
@app.task
def cleanup_old_data():
    """Clean up old data from the system"""
    from django.utils import timezone
    from datetime import timedelta

    # Clean up old log entries, temporary files, etc.
    cutoff_date = timezone.now() - timedelta(days=90)

    # Add cleanup logic here
    return 'Data cleanup completed'

# Task for backup operations
@app.task
def backup_database():
    """Backup database"""
    import subprocess
    from django.conf import settings

    try:
        db_settings = settings.DATABASES['default']
        backup_command = [
            'mysqldump',
            f"--host={db_settings['HOST']}",
            f"--user={db_settings['USER']}",
            f"--password={db_settings['PASSWORD']}",
            db_settings['NAME']
        ]

        # Execute backup command
        result = subprocess.run(backup_command, capture_output=True, text=True)

        if result.returncode == 0:
            return 'Database backup completed successfully'
        else:
            return f'Database backup failed: {result.stderr}'
    except Exception as exc:
        return f'Database backup error: {exc}'
