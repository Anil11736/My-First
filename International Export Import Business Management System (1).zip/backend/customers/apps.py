from django.apps import AppConfig


class CustomersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'customers'
    verbose_name = 'Customer Management'

    def ready(self):
        """
        Import signal handlers when the app is ready.
        This ensures that signals are properly connected.
        """
        try:
            import customers.signals
        except ImportError:
            pass
