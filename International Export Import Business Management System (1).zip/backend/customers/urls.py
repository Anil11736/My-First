from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

app_name = 'customers'

# DRF Router for API endpoints
router = DefaultRouter()
router.register(r'api/customers', views.CustomerViewSet, basename='customer-api')

urlpatterns = [
    # Include API routes
    path('', include(router.urls)),

    # Web views
    path('customers/', views.CustomerListView.as_view(), name='customer_list'),
    path('customers/create/', views.CustomerCreateView.as_view(), name='customer_create'),
    path('customers/<int:pk>/', views.CustomerDetailView.as_view(), name='customer_detail'),
    path('customers/<int:pk>/edit/', views.CustomerUpdateView.as_view(), name='customer_update'),
    path('customers/<int:pk>/delete/', views.CustomerDeleteView.as_view(), name='customer_delete'),

    # Customer contacts
    path('customers/<int:customer_id>/contacts/', views.CustomerContactListView.as_view(), name='customer_contact_list'),
    path('customers/<int:customer_id>/contacts/create/', views.CustomerContactCreateView.as_view(), name='customer_contact_create'),
    path('contacts/<int:pk>/edit/', views.CustomerContactUpdateView.as_view(), name='customer_contact_update'),
    path('contacts/<int:pk>/delete/', views.CustomerContactDeleteView.as_view(), name='customer_contact_delete'),

    # Customer documents
    path('customers/<int:customer_id>/documents/', views.CustomerDocumentListView.as_view(), name='customer_document_list'),
    path('customers/<int:customer_id>/documents/upload/', views.CustomerDocumentCreateView.as_view(), name='customer_document_upload'),
    path('documents/<int:pk>/delete/', views.CustomerDocumentDeleteView.as_view(), name='customer_document_delete'),

    # Customer orders/transactions
    path('customers/<int:customer_id>/orders/', views.CustomerOrderListView.as_view(), name='customer_order_list'),
    path('customers/<int:customer_id>/transactions/', views.CustomerTransactionListView.as_view(), name='customer_transaction_list'),

    # Export/Import functionality
    path('customers/export/', views.CustomerExportView.as_view(), name='customer_export'),
    path('customers/import/', views.CustomerImportView.as_view(), name='customer_import'),

    # Search and filter
    path('customers/search/', views.CustomerSearchView.as_view(), name='customer_search'),
    path('api/customers/search/', views.CustomerSearchAPIView.as_view(), name='customer_search_api'),

    # Reports
    path('customers/reports/', views.CustomerReportView.as_view(), name='customer_reports'),
    path('api/customers/statistics/', views.CustomerStatisticsAPIView.as_view(), name='customer_statistics_api'),
]
