from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Count, Sum
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
import json
from datetime import datetime, timedelta
from django.utils import timezone

from .models import Customer
from .forms import CustomerForm
from orders.models import Order
from shipments.models import Shipment


@login_required
def customer_list(request):
    """Display paginated list of customers with search and filtering"""
    customers = Customer.objects.all().order_by('-created_at')

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        customers = customers.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(company__icontains=search_query) |
            Q(phone__icontains=search_query)
        )

    # Filter by customer type
    customer_type = request.GET.get('type', '')
    if customer_type:
        customers = customers.filter(customer_type=customer_type)

    # Filter by status
    status = request.GET.get('status', '')
    if status:
        customers = customers.filter(is_active=(status == 'active'))

    # Pagination
    paginator = Paginator(customers, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Get customer types for filter dropdown
    customer_types = Customer.CUSTOMER_TYPE_CHOICES

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'customer_type': customer_type,
        'status': status,
        'customer_types': customer_types,
        'total_customers': customers.count(),
    }

    return render(request, 'customers/customer_list.html', context)


@login_required
def customer_detail(request, pk):
    """Display detailed customer information with related data"""
    customer = get_object_or_404(Customer, pk=pk)

    # Get customer's orders
    orders = Order.objects.filter(customer=customer).order_by('-created_at')[:10]

    # Get customer's shipments
    shipments = Shipment.objects.filter(order__customer=customer).order_by('-created_at')[:10]

    # Calculate statistics
    total_orders = Order.objects.filter(customer=customer).count()
    total_value = Order.objects.filter(customer=customer).aggregate(
        total=Sum('total_amount')
    )['total'] or 0

    # Recent activity (last 30 days)
    thirty_days_ago = timezone.now() - timedelta(days=30)
    recent_orders = Order.objects.filter(
        customer=customer,
        created_at__gte=thirty_days_ago
    ).count()

    context = {
        'customer': customer,
        'orders': orders,
        'shipments': shipments,
        'total_orders': total_orders,
        'total_value': total_value,
        'recent_orders': recent_orders,
    }

    return render(request, 'customers/customer_detail.html', context)


@login_required
def customer_create(request):
    """Create a new customer"""
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save(commit=False)
            customer.created_by = request.user
            customer.save()
            messages.success(request, f'Customer "{customer.name}" created successfully.')
            return redirect('customers:detail', pk=customer.pk)
    else:
        form = CustomerForm()

    context = {
        'form': form,
        'title': 'Add New Customer',
        'submit_text': 'Create Customer'
    }

    return render(request, 'customers/customer_form.html', context)


@login_required
def customer_update(request, pk):
    """Update an existing customer"""
    customer = get_object_or_404(Customer, pk=pk)

    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            customer = form.save(commit=False)
            customer.updated_by = request.user
            customer.save()
            messages.success(request, f'Customer "{customer.name}" updated successfully.')
            return redirect('customers:detail', pk=customer.pk)
    else:
        form = CustomerForm(instance=customer)

    context = {
        'form': form,
        'customer': customer,
        'title': f'Edit Customer - {customer.name}',
        'submit_text': 'Update Customer'
    }

    return render(request, 'customers/customer_form.html', context)


@login_required
@require_http_methods(["POST"])
def customer_delete(request, pk):
    """Delete a customer (soft delete by setting is_active=False)"""
    customer = get_object_or_404(Customer, pk=pk)

    # Check if customer has active orders
    active_orders = Order.objects.filter(
        customer=customer,
        status__in=['pending', 'processing', 'shipped']
    ).count()

    if active_orders > 0:
        messages.error(
            request,
            f'Cannot delete customer "{customer.name}" - they have {active_orders} active orders.'
        )
        return redirect('customers:detail', pk=customer.pk)

    # Soft delete
    customer.is_active = False
    customer.updated_by = request.user
    customer.save()

    messages.success(request, f'Customer "{customer.name}" has been deactivated.')
    return redirect('customers:list')


@login_required
def customer_dashboard(request):
    """Customer management dashboard with statistics"""
    # Basic statistics
    total_customers = Customer.objects.filter(is_active=True).count()
    new_customers_this_month = Customer.objects.filter(
        created_at__month=timezone.now().month,
        created_at__year=timezone.now().year
    ).count()

    # Customer type distribution
    customer_type_stats = Customer.objects.filter(is_active=True).values(
        'customer_type'
    ).annotate(count=Count('id'))

    # Top customers by order value
    top_customers = Customer.objects.filter(is_active=True).annotate(
        total_orders=Count('order'),
        total_value=Sum('order__total_amount')
    ).filter(total_orders__gt=0).order_by('-total_value')[:10]

    # Recent customers
    recent_customers = Customer.objects.filter(is_active=True).order_by('-created_at')[:5]

    # Monthly customer growth (last 12 months)
    monthly_growth = []
    for i in range(12):
        date = timezone.now() - timedelta(days=30*i)
        count = Customer.objects.filter(
            created_at__month=date.month,
            created_at__year=date.year
        ).count()
        monthly_growth.append({
            'month': date.strftime('%b %Y'),
            'count': count
        })
    monthly_growth.reverse()

    context = {
        'total_customers': total_customers,
        'new_customers_this_month': new_customers_this_month,
        'customer_type_stats': customer_type_stats,
        'top_customers': top_customers,
        'recent_customers': recent_customers,
        'monthly_growth': monthly_growth,
    }

    return render(request, 'customers/dashboard.html', context)


@login_required
@csrf_exempt
def customer_search_api(request):
    """API endpoint for customer search (for autocomplete)"""
    if request.method == 'GET':
        query = request.GET.get('q', '')
        if len(query) >= 2:
            customers = Customer.objects.filter(
                Q(name__icontains=query) |
                Q(company__icontains=query) |
                Q(email__icontains=query),
                is_active=True
            )[:10]

            results = []
            for customer in customers:
                results.append({
                    'id': customer.id,
                    'name': customer.name,
                    'company': customer.company,
                    'email': customer.email,
                    'customer_type': customer.get_customer_type_display(),
                })

            return JsonResponse({'results': results})

    return JsonResponse({'results': []})


@login_required
def customer_export(request):
    """Export customer data to CSV"""
    import csv
    from django.http import HttpResponse

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="customers.csv"'

    writer = csv.writer(response)
    writer.writerow([
        'Name', 'Company', 'Email', 'Phone', 'Customer Type',
        'Country', 'City', 'Status', 'Created Date'
    ])

    customers = Customer.objects.filter(is_active=True).order_by('name')
    for customer in customers:
        writer.writerow([
            customer.name,
            customer.company,
            customer.email,
            customer.phone,
            customer.get_customer_type_display(),
            customer.country,
            customer.city,
            'Active' if customer.is_active else 'Inactive',
            customer.created_at.strftime('%Y-%m-%d')
        ])

    return response


class CustomerListView(LoginRequiredMixin, ListView):
    """Class-based view for customer listing"""
    model = Customer
    template_name = 'customers/customer_list_cbv.html'
    context_object_name = 'customers'
    paginate_by = 20

    def get_queryset(self):
        queryset = Customer.objects.filter(is_active=True).order_by('-created_at')

        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(email__icontains=search_query) |
                Q(company__icontains=search_query)
            )

        return queryset


class CustomerCreateView(LoginRequiredMixin, CreateView):
    """Class-based view for customer creation"""
    model = Customer
    form_class = CustomerForm
    template_name = 'customers/customer_form_cbv.html'
    success_url = reverse_lazy('customers:list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        messages.success(self.request, 'Customer created successfully.')
        return super().form_valid(form)


class CustomerUpdateView(LoginRequiredMixin, UpdateView):
    """Class-based view for customer updates"""
    model = Customer
    form_class = CustomerForm
    template_name = 'customers/customer_form_cbv.html'

    def get_success_url(self):
        return reverse_lazy('customers:detail', kwargs={'pk': self.object.pk})

    def form_valid(self, form):
        form.instance.updated_by = self.request.user
        messages.success(self.request, 'Customer updated successfully.')
        return super().form_valid(form)


class CustomerDeleteView(LoginRequiredMixin, DeleteView):
    """Class-based view for customer deletion"""
    model = Customer
    template_name = 'customers/customer_confirm_delete.html'
    success_url = reverse_lazy('customers:list')

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()

        # Check for active orders
        active_orders = Order.objects.filter(
            customer=self.object,
            status__in=['pending', 'processing', 'shipped']
        ).count()

        if active_orders > 0:
            messages.error(
                request,
                f'Cannot delete customer - they have {active_orders} active orders.'
            )
            return redirect('customers:detail', pk=self.object.pk)

        # Soft delete
        self.object.is_active = False
        self.object.updated_by = request.user
        self.object.save()

        messages.success(request, 'Customer has been deactivated.')
        return redirect(self.success_url)
