from django.db import models
from django.core.validators import RegexValidator, EmailValidator
from django.utils import timezone
from accounts.models import User


class Customer(models.Model):
    """Main customer model for companies we do business with"""
    CUSTOMER_TYPE_CHOICES = [
        ('EXPORTER', 'Exporter'),
        ('IMPORTER', 'Importer'),
        ('BOTH', 'Both Exporter & Importer'),
        ('AGENT', 'Agent/Broker'),
        ('FREIGHT_FORWARDER', 'Freight Forwarder'),
    ]

    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('INACTIVE', 'Inactive'),
        ('SUSPENDED', 'Suspended'),
        ('BLACKLISTED', 'Blacklisted'),
    ]

    CREDIT_RATING_CHOICES = [
        ('AAA', 'AAA - Excellent'),
        ('AA', 'AA - Very Good'),
        ('A', 'A - Good'),
        ('BBB', 'BBB - Fair'),
        ('BB', 'BB - Poor'),
        ('B', 'B - Very Poor'),
        ('CCC', 'CCC - Extremely Poor'),
        ('D', 'D - Default'),
    ]

    # Basic Information
    customer_code = models.CharField(max_length=20, unique=True, db_index=True)
    company_name = models.CharField(max_length=200)
    legal_name = models.CharField(max_length=200, blank=True)
    customer_type = models.CharField(max_length=20, choices=CUSTOMER_TYPE_CHOICES)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='ACTIVE')

    # Registration Details
    registration_number = models.CharField(max_length=50, blank=True)
    tax_id = models.CharField(max_length=50, blank=True)
    vat_number = models.CharField(max_length=50, blank=True)

    # Business Details
    industry = models.CharField(max_length=100, blank=True)
    business_description = models.TextField(blank=True)
    website = models.URLField(blank=True)
    established_date = models.DateField(null=True, blank=True)

    # Financial Information
    credit_rating = models.CharField(max_length=5, choices=CREDIT_RATING_CHOICES, blank=True)
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    payment_terms = models.CharField(max_length=100, default='Net 30')
    currency_preference = models.CharField(max_length=3, default='USD')

    # Relationship Management
    account_manager = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='managed_customers'
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_customers'
    )

    # Additional Fields
    notes = models.TextField(blank=True)
    is_verified = models.BooleanField(default=False)
    verification_date = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'customers'
        ordering = ['company_name']
        indexes = [
            models.Index(fields=['customer_code']),
            models.Index(fields=['company_name']),
            models.Index(fields=['customer_type']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.customer_code} - {self.company_name}"

    def save(self, *args, **kwargs):
        if not self.customer_code:
            self.customer_code = self.generate_customer_code()
        super().save(*args, **kwargs)

    def generate_customer_code(self):
        """Generate unique customer code"""
        prefix = self.customer_type[:3].upper()
        last_customer = Customer.objects.filter(
            customer_code__startswith=prefix
        ).order_by('-customer_code').first()

        if last_customer:
            try:
                last_number = int(last_customer.customer_code[-4:])
                new_number = last_number + 1
            except ValueError:
                new_number = 1
        else:
            new_number = 1

        return f"{prefix}{new_number:04d}"


class CustomerContact(models.Model):
    """Contact persons for customers"""
    CONTACT_TYPE_CHOICES = [
        ('PRIMARY', 'Primary Contact'),
        ('BILLING', 'Billing Contact'),
        ('SHIPPING', 'Shipping Contact'),
        ('TECHNICAL', 'Technical Contact'),
        ('SALES', 'Sales Contact'),
        ('FINANCE', 'Finance Contact'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='contacts')
    contact_type = models.CharField(max_length=15, choices=CONTACT_TYPE_CHOICES)

    # Personal Information
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    title = models.CharField(max_length=50, blank=True)
    department = models.CharField(max_length=100, blank=True)

    # Contact Information
    email = models.EmailField(validators=[EmailValidator()])
    phone = models.CharField(max_length=20, blank=True)
    mobile = models.CharField(max_length=20, blank=True)
    fax = models.CharField(max_length=20, blank=True)

    # Status
    is_primary = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'customer_contacts'
        unique_together = ['customer', 'email']
        indexes = [
            models.Index(fields=['customer', 'contact_type']),
            models.Index(fields=['email']),
        ]

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.customer.company_name}"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class CustomerAddress(models.Model):
    """Multiple addresses for customers"""
    ADDRESS_TYPE_CHOICES = [
        ('BILLING', 'Billing Address'),
        ('SHIPPING', 'Shipping Address'),
        ('OFFICE', 'Office Address'),
        ('WAREHOUSE', 'Warehouse Address'),
        ('FACTORY', 'Factory Address'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='addresses')
    address_type = models.CharField(max_length=15, choices=ADDRESS_TYPE_CHOICES)

    # Address Details
    address_line_1 = models.CharField(max_length=200)
    address_line_2 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=100)
    state_province = models.CharField(max_length=100, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=100)
    country_code = models.CharField(max_length=3, blank=True)

    # Additional Information
    port_code = models.CharField(max_length=10, blank=True, help_text="For shipping addresses")
    customs_office = models.CharField(max_length=100, blank=True)

    # Status
    is_default = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'customer_addresses'
        indexes = [
            models.Index(fields=['customer', 'address_type']),
            models.Index(fields=['country']),
            models.Index(fields=['city']),
        ]

    def __str__(self):
        return f"{self.address_type} - {self.customer.company_name}"

    @property
    def full_address(self):
        address_parts = [self.address_line_1]
        if self.address_line_2:
            address_parts.append(self.address_line_2)
        address_parts.extend([self.city, self.state_province, self.postal_code, self.country])
        return ', '.join(filter(None, address_parts))


class CustomerDocument(models.Model):
    """Documents related to customers"""
    DOCUMENT_TYPE_CHOICES = [
        ('REGISTRATION', 'Company Registration'),
        ('TAX_CERTIFICATE', 'Tax Certificate'),
        ('EXPORT_LICENSE', 'Export License'),
        ('IMPORT_LICENSE', 'Import License'),
        ('BANK_REFERENCE', 'Bank Reference'),
        ('TRADE_REFERENCE', 'Trade Reference'),
        ('INSURANCE', 'Insurance Certificate'),
        ('QUALITY_CERT', 'Quality Certificate'),
        ('OTHER', 'Other'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='documents')
    document_type = models.CharField(max_length=20, choices=DOCUMENT_TYPE_CHOICES)
    document_name = models.CharField(max_length=200)
    document_number = models.CharField(max_length=100, blank=True)

    # File Information
    file_path = models.FileField(upload_to='customer_documents/%Y/%m/')
    file_size = models.PositiveIntegerField(null=True, blank=True)
    mime_type = models.CharField(max_length=100, blank=True)

    # Validity
    issue_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    is_verified = models.BooleanField(default=False)

    # Timestamps
    uploaded_at = models.DateTimeField(auto_now_add=True)
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='uploaded_customer_documents'
    )

    class Meta:
        db_table = 'customer_documents'
        indexes = [
            models.Index(fields=['customer', 'document_type']),
            models.Index(fields=['expiry_date']),
        ]

    def __str__(self):
        return f"{self.document_name} - {self.customer.company_name}"

    @property
    def is_expired(self):
        if self.expiry_date:
            return self.expiry_date < timezone.now().date()
        return False


class CustomerCreditTerm(models.Model):
    """Credit terms and payment conditions for customers"""
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE, related_name='credit_terms')

    # Credit Information
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    available_credit = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    credit_used = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    # Payment Terms
    payment_terms_days = models.PositiveIntegerField(default=30)
    early_payment_discount = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    early_payment_days = models.PositiveIntegerField(default=10)
    late_payment_penalty = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    # Security
    security_deposit = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    guarantee_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    guarantee_expiry = models.DateField(null=True, blank=True)

    # Status
    credit_hold = models.BooleanField(default=False)
    credit_hold_reason = models.TextField(blank=True)

    # Review Information
    last_review_date = models.DateField(null=True, blank=True)
    next_review_date = models.DateField(null=True, blank=True)
    reviewed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='reviewed_credit_terms'
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'customer_credit_terms'

    def __str__(self):
        return f"Credit Terms - {self.customer.company_name}"

    def update_available_credit(self):
        """Update available credit based on current usage"""
        self.available_credit = self.credit_limit - self.credit_used
        self.save(update_fields=['available_credit'])

    @property
    def credit_utilization_percentage(self):
        if self.credit_limit > 0:
            return (self.credit_used / self.credit_limit) * 100
        return 0


class CustomerNote(models.Model):
    """Notes and comments about customers"""
    NOTE_TYPE_CHOICES = [
        ('GENERAL', 'General Note'),
        ('SALES', 'Sales Note'),
        ('CREDIT', 'Credit Note'),
        ('COMPLAINT', 'Complaint'),
        ('FOLLOW_UP', 'Follow Up'),
        ('MEETING', 'Meeting Notes'),
    ]

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='notes')
    note_type = models.CharField(max_length=15, choices=NOTE_TYPE_CHOICES, default='GENERAL')
    subject = models.CharField(max_length=200)
    content = models.TextField()

    # Visibility
    is_internal = models.BooleanField(default=True)
    is_important = models.BooleanField(default=False)

    # Follow-up
    follow_up_date = models.DateField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='customer_notes'
    )

    class Meta:
        db_table = 'customer_notes'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['customer', 'note_type']),
            models.Index(fields=['follow_up_date']),
            models.Index(fields=['is_important']),
        ]

    def __str__(self):
        return f"{self.subject} - {self.customer.company_name}"
