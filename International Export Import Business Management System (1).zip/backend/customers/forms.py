from django import forms
from django.core.validators import RegexValidator
from django.contrib.auth.models import User
from .models import Customer


class CustomerForm(forms.ModelForm):
    """Form for creating and editing customers"""

    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."
    )

    name = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter customer name',
            'required': True
        })
    )

    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter email address',
            'required': True
        })
    )

    phone = forms.CharField(
        validators=[phone_regex],
        max_length=17,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '+1234567890',
            'required': True
        })
    )

    company = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter company name (optional)'
        })
    )

    address = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'placeholder': 'Enter complete address',
            'rows': 3,
            'required': True
        })
    )

    city = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter city',
            'required': True
        })
    )

    state = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter state/province',
            'required': True
        })
    )

    country = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter country',
            'required': True
        })
    )

    postal_code = forms.CharField(
        max_length=20,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter postal/ZIP code',
            'required': True
        })
    )

    customer_type = forms.ChoiceField(
        choices=Customer.CUSTOMER_TYPE_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control',
            'required': True
        })
    )

    tax_id = forms.CharField(
        max_length=50,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter tax ID/VAT number (optional)'
        })
    )

    credit_limit = forms.DecimalField(
        max_digits=15,
        decimal_places=2,
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '0.00',
            'step': '0.01',
            'min': '0'
        })
    )

    payment_terms = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'e.g., Net 30 days'
        })
    )

    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'placeholder': 'Additional notes about the customer',
            'rows': 3
        })
    )

    is_active = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        })
    )

    class Meta:
        model = Customer
        fields = [
            'name', 'email', 'phone', 'company', 'address', 'city',
            'state', 'country', 'postal_code', 'customer_type',
            'tax_id', 'credit_limit', 'payment_terms', 'notes', 'is_active'
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add Bootstrap classes to all fields
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})
            else:
                field.widget.attrs.update({'class': 'form-control'})

    def clean_email(self):
        """Validate email uniqueness"""
        email = self.cleaned_data.get('email')
        if email:
            # Check if email already exists (excluding current instance if editing)
            existing_customer = Customer.objects.filter(email=email)
            if self.instance.pk:
                existing_customer = existing_customer.exclude(pk=self.instance.pk)

            if existing_customer.exists():
                raise forms.ValidationError("A customer with this email already exists.")
        return email

    def clean_credit_limit(self):
        """Validate credit limit is not negative"""
        credit_limit = self.cleaned_data.get('credit_limit')
        if credit_limit is not None and credit_limit < 0:
            raise forms.ValidationError("Credit limit cannot be negative.")
        return credit_limit

    def clean_phone(self):
        """Clean and validate phone number"""
        phone = self.cleaned_data.get('phone')
        if phone:
            # Remove any spaces or special characters except +
            phone = ''.join(char for char in phone if char.isdigit() or char == '+')
        return phone

    def save(self, commit=True):
        """Save the customer instance"""
        customer = super().save(commit=False)

        # Set default values if not provided
        if not customer.credit_limit:
            customer.credit_limit = 0.00

        if commit:
            customer.save()
        return customer


class CustomerSearchForm(forms.Form):
    """Form for searching customers"""

    search = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by name, email, or company...',
            'autocomplete': 'off'
        })
    )

    customer_type = forms.ChoiceField(
        choices=[('', 'All Types')] + Customer.CUSTOMER_TYPE_CHOICES,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    country = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Filter by country...'
        })
    )

    is_active = forms.ChoiceField(
        choices=[
            ('', 'All Customers'),
            ('true', 'Active Only'),
            ('false', 'Inactive Only')
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )


class CustomerImportForm(forms.Form):
    """Form for importing customers from CSV/Excel"""

    file = forms.FileField(
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.csv,.xlsx,.xls'
        }),
        help_text="Upload CSV or Excel file with customer data"
    )

    skip_duplicates = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        help_text="Skip customers with duplicate email addresses"
    )

    update_existing = forms.BooleanField(
        required=False,
        initial=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        help_text="Update existing customers if email matches"
    )

    def clean_file(self):
        """Validate uploaded file"""
        file = self.cleaned_data.get('file')
        if file:
            # Check file size (max 5MB)
            if file.size > 5 * 1024 * 1024:
                raise forms.ValidationError("File size cannot exceed 5MB.")

            # Check file extension
            allowed_extensions = ['.csv', '.xlsx', '.xls']
            file_extension = file.name.lower().split('.')[-1]
            if f'.{file_extension}' not in allowed_extensions:
                raise forms.ValidationError(
                    "Only CSV and Excel files are allowed."
                )
        return file
