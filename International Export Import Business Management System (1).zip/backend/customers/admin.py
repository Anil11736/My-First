from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import Customer, CustomerContact, CustomerDocument, CustomerAddress


class CustomerContactInline(admin.TabularInline):
    model = CustomerContact
    extra = 1
    fields = ('contact_type', 'name', 'email', 'phone', 'designation', 'is_primary')
    readonly_fields = ('created_at', 'updated_at')


class CustomerAddressInline(admin.TabularInline):
    model = CustomerAddress
    extra = 1
    fields = ('address_type', 'street_address', 'city', 'state', 'postal_code', 'country', 'is_default')
    readonly_fields = ('created_at', 'updated_at')


class CustomerDocumentInline(admin.TabularInline):
    model = CustomerDocument
    extra = 0
    fields = ('document_type', 'document_number', 'document_file', 'issue_date', 'expiry_date', 'is_verified')
    readonly_fields = ('created_at', 'updated_at', 'uploaded_by')


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = (
        'customer_code',
        'company_name',
        'customer_type',
        'status',
        'country',
        'credit_limit',
        'outstanding_balance',
        'is_active',
        'created_at'
    )

    list_filter = (
        'customer_type',
        'status',
        'country',
        'is_active',
        'created_at',
        'updated_at'
    )

    search_fields = (
        'customer_code',
        'company_name',
        'email',
        'phone',
        'tax_id',
        'registration_number'
    )

    readonly_fields = (
        'customer_code',
        'created_at',
        'updated_at',
        'created_by',
        'updated_by',
        'get_total_orders',
        'get_last_order_date'
    )

    fieldsets = (
        ('Basic Information', {
            'fields': (
                'customer_code',
                'company_name',
                'customer_type',
                'status',
                'is_active'
            )
        }),
        ('Contact Information', {
            'fields': (
                'email',
                'phone',
                'website',
                'country',
                'timezone'
            )
        }),
        ('Business Details', {
            'fields': (
                'business_type',
                'industry',
                'tax_id',
                'registration_number',
                'established_date'
            )
        }),
        ('Financial Information', {
            'fields': (
                'credit_limit',
                'payment_terms',
                'currency',
                'outstanding_balance'
            )
        }),
        ('Additional Information', {
            'fields': (
                'notes',
                'tags'
            ),
            'classes': ('collapse',)
        }),
        ('System Information', {
            'fields': (
                'created_at',
                'updated_at',
                'created_by',
                'updated_by',
                'get_total_orders',
                'get_last_order_date'
            ),
            'classes': ('collapse',)
        })
    )

    inlines = [CustomerContactInline, CustomerAddressInline, CustomerDocumentInline]

    actions = ['activate_customers', 'deactivate_customers', 'mark_as_verified']

    def get_total_orders(self, obj):
        """Get total number of orders for this customer"""
        # This would need to be implemented when order models are created
        return "N/A"
    get_total_orders.short_description = "Total Orders"

    def get_last_order_date(self, obj):
        """Get last order date for this customer"""
        # This would need to be implemented when order models are created
        return "N/A"
    get_last_order_date.short_description = "Last Order Date"

    def activate_customers(self, request, queryset):
        """Bulk activate customers"""
        updated = queryset.update(is_active=True, status='active')
        self.message_user(request, f'{updated} customers were successfully activated.')
    activate_customers.short_description = "Activate selected customers"

    def deactivate_customers(self, request, queryset):
        """Bulk deactivate customers"""
        updated = queryset.update(is_active=False, status='inactive')
        self.message_user(request, f'{updated} customers were successfully deactivated.')
    deactivate_customers.short_description = "Deactivate selected customers"

    def mark_as_verified(self, request, queryset):
        """Mark customers as verified"""
        updated = queryset.update(status='verified')
        self.message_user(request, f'{updated} customers were marked as verified.')
    mark_as_verified.short_description = "Mark as verified"

    def save_model(self, request, obj, form, change):
        """Override save to set created_by and updated_by"""
        if not change:
            obj.created_by = request.user
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(CustomerContact)
class CustomerContactAdmin(admin.ModelAdmin):
    list_display = (
        'customer',
        'name',
        'contact_type',
        'email',
        'phone',
        'designation',
        'is_primary',
        'created_at'
    )

    list_filter = (
        'contact_type',
        'is_primary',
        'created_at'
    )

    search_fields = (
        'customer__company_name',
        'customer__customer_code',
        'name',
        'email',
        'phone'
    )

    readonly_fields = ('created_at', 'updated_at')

    fieldsets = (
        ('Contact Information', {
            'fields': (
                'customer',
                'contact_type',
                'name',
                'designation',
                'is_primary'
            )
        }),
        ('Contact Details', {
            'fields': (
                'email',
                'phone',
                'mobile',
                'notes'
            )
        }),
        ('System Information', {
            'fields': (
                'created_at',
                'updated_at'
            ),
            'classes': ('collapse',)
        })
    )


@admin.register(CustomerAddress)
class CustomerAddressAdmin(admin.ModelAdmin):
    list_display = (
        'customer',
        'address_type',
        'city',
        'state',
        'country',
        'postal_code',
        'is_default',
        'created_at'
    )

    list_filter = (
        'address_type',
        'country',
        'is_default',
        'created_at'
    )

    search_fields = (
        'customer__company_name',
        'customer__customer_code',
        'street_address',
        'city',
        'state',
        'country'
    )

    readonly_fields = ('created_at', 'updated_at')

    fieldsets = (
        ('Address Information', {
            'fields': (
                'customer',
                'address_type',
                'is_default'
            )
        }),
        ('Address Details', {
            'fields': (
                'street_address',
                'street_address_2',
                'city',
                'state',
                'postal_code',
                'country'
            )
        }),
        ('Additional Information', {
            'fields': (
                'notes',
            ),
            'classes': ('collapse',)
        }),
        ('System Information', {
            'fields': (
                'created_at',
                'updated_at'
            ),
            'classes': ('collapse',)
        })
    )


@admin.register(CustomerDocument)
class CustomerDocumentAdmin(admin.ModelAdmin):
    list_display = (
        'customer',
        'document_type',
        'document_number',
        'issue_date',
        'expiry_date',
        'is_verified',
        'uploaded_by',
        'created_at'
    )

    list_filter = (
        'document_type',
        'is_verified',
        'issue_date',
        'expiry_date',
        'created_at'
    )

    search_fields = (
        'customer__company_name',
        'customer__customer_code',
        'document_number',
        'document_type'
    )

    readonly_fields = ('created_at', 'updated_at', 'uploaded_by')

    fieldsets = (
        ('Document Information', {
            'fields': (
                'customer',
                'document_type',
                'document_number',
                'is_verified'
            )
        }),
        ('Document Details', {
            'fields': (
                'document_file',
                'issue_date',
                'expiry_date',
                'issuing_authority'
            )
        }),
        ('Additional Information', {
            'fields': (
                'notes',
            ),
            'classes': ('collapse',)
        }),
        ('System Information', {
            'fields': (
                'uploaded_by',
                'created_at',
                'updated_at'
            ),
            'classes': ('collapse',)
        })
    )

    def save_model(self, request, obj, form, change):
        """Override save to set uploaded_by"""
        if not change:
            obj.uploaded_by = request.user
        super().save_model(request, obj, form, change)


# Custom admin site configuration
admin.site.site_header = "Export Import Business Management"
admin.site.site_title = "Export Import Admin"
admin.site.index_title = "Welcome to Export Import Business Management System"
