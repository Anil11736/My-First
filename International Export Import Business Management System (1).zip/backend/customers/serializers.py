from rest_framework import serializers
from .models import Customer, CustomerContact, CustomerAddress


class CustomerAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAddress
        fields = [
            'id', 'address_type', 'street_address', 'city', 'state',
            'postal_code', 'country', 'is_primary'
        ]
        read_only_fields = ['id']


class CustomerContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerContact
        fields = [
            'id', 'name', 'title', 'email', 'phone', 'mobile',
            'is_primary', 'notes'
        ]
        read_only_fields = ['id']


class CustomerSerializer(serializers.ModelSerializer):
    contacts = CustomerContactSerializer(many=True, read_only=True)
    addresses = CustomerAddressSerializer(many=True, read_only=True)
    total_orders = serializers.SerializerMethodField()
    outstanding_balance = serializers.SerializerMethodField()

    class Meta:
        model = Customer
        fields = [
            'id', 'company_name', 'customer_type', 'tax_id', 'website',
            'industry', 'credit_limit', 'payment_terms', 'currency',
            'is_active', 'notes', 'created_at', 'updated_at',
            'contacts', 'addresses', 'total_orders', 'outstanding_balance'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def get_total_orders(self, obj):
        return obj.shipments.count()

    def get_outstanding_balance(self, obj):
        from financials.models import Invoice
        invoices = Invoice.objects.filter(customer=obj, status='pending')
        return sum(invoice.total_amount for invoice in invoices)


class CustomerCreateSerializer(serializers.ModelSerializer):
    contacts = CustomerContactSerializer(many=True, required=False)
    addresses = CustomerAddressSerializer(many=True, required=False)

    class Meta:
        model = Customer
        fields = [
            'company_name', 'customer_type', 'tax_id', 'website',
            'industry', 'credit_limit', 'payment_terms', 'currency',
            'notes', 'contacts', 'addresses'
        ]

    def create(self, validated_data):
        contacts_data = validated_data.pop('contacts', [])
        addresses_data = validated_data.pop('addresses', [])

        customer = Customer.objects.create(**validated_data)

        for contact_data in contacts_data:
            CustomerContact.objects.create(customer=customer, **contact_data)

        for address_data in addresses_data:
            CustomerAddress.objects.create(customer=customer, **address_data)

        return customer


class CustomerListSerializer(serializers.ModelSerializer):
    primary_contact = serializers.SerializerMethodField()
    primary_address = serializers.SerializerMethodField()

    class Meta:
        model = Customer
        fields = [
            'id', 'company_name', 'customer_type', 'industry',
            'is_active', 'primary_contact', 'primary_address'
        ]

    def get_primary_contact(self, obj):
        contact = obj.contacts.filter(is_primary=True).first()
        return contact.email if contact else None

    def get_primary_address(self, obj):
        address = obj.addresses.filter(is_primary=True).first()
        return f"{address.city}, {address.country}" if address else None
