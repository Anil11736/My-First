from django import forms
from django.core.validators import MinValueValidator, MaxValueValidator
from django.forms import ModelForm, ValidationError
from .models import Product, Category, Supplier, InventoryTransaction, StockAlert


class ProductForm(ModelForm):
    """Form for creating and updating products"""

    class Meta:
        model = Product
        fields = [
            'name', 'description', 'category', 'supplier', 'sku',
            'barcode', 'unit_price', 'cost_price', 'weight',
            'dimensions', 'hs_code', 'origin_country', 'minimum_stock',
            'maximum_stock', 'reorder_point', 'is_active'
        ]
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter product name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Enter product description'
            }),
            'category': forms.Select(attrs={
                'class': 'form-select'
            }),
            'supplier': forms.Select(attrs={
                'class': 'form-select'
            }),
            'sku': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter SKU'
            }),
            'barcode': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter barcode'
            }),
            'unit_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'cost_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'dimensions': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'L x W x H (cm)'
            }),
            'hs_code': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter HS code'
            }),
            'origin_country': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter country of origin'
            }),
            'minimum_stock': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'maximum_stock': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'reorder_point': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            })
        }

    def clean_sku(self):
        sku = self.cleaned_data.get('sku')
        if sku:
            # Check if SKU already exists (excluding current instance if updating)
            existing = Product.objects.filter(sku=sku)
            if self.instance.pk:
                existing = existing.exclude(pk=self.instance.pk)
            if existing.exists():
                raise ValidationError('A product with this SKU already exists.')
        return sku

    def clean_barcode(self):
        barcode = self.cleaned_data.get('barcode')
        if barcode:
            # Check if barcode already exists (excluding current instance if updating)
            existing = Product.objects.filter(barcode=barcode)
            if self.instance.pk:
                existing = existing.exclude(pk=self.instance.pk)
            if existing.exists():
                raise ValidationError('A product with this barcode already exists.')
        return barcode

    def clean(self):
        cleaned_data = super().clean()
        minimum_stock = cleaned_data.get('minimum_stock')
        maximum_stock = cleaned_data.get('maximum_stock')
        reorder_point = cleaned_data.get('reorder_point')

        if minimum_stock and maximum_stock:
            if minimum_stock >= maximum_stock:
                raise ValidationError('Maximum stock must be greater than minimum stock.')

        if reorder_point and minimum_stock:
            if reorder_point < minimum_stock:
                raise ValidationError('Reorder point should not be less than minimum stock.')

        return cleaned_data


class CategoryForm(ModelForm):
    """Form for creating and updating categories"""

    class Meta:
        model = Category
        fields = ['name', 'description', 'parent', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter category name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter category description'
            }),
            'parent': forms.Select(attrs={
                'class': 'form-select'
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Exclude self from parent choices to prevent circular reference
        if self.instance.pk:
            self.fields['parent'].queryset = Category.objects.exclude(pk=self.instance.pk)


class SupplierForm(ModelForm):
    """Form for creating and updating suppliers"""

    class Meta:
        model = Supplier
        fields = [
            'name', 'contact_person', 'email', 'phone', 'address',
            'city', 'country', 'postal_code', 'tax_id', 'payment_terms',
            'credit_limit', 'is_active'
        ]
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter supplier name'
            }),
            'contact_person': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter contact person name'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter email address'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter phone number'
            }),
            'address': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter address'
            }),
            'city': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter city'
            }),
            'country': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter country'
            }),
            'postal_code': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter postal code'
            }),
            'tax_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter tax ID'
            }),
            'payment_terms': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Net 30 days'
            }),
            'credit_limit': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            })
        }


class InventoryTransactionForm(ModelForm):
    """Form for recording inventory transactions"""

    class Meta:
        model = InventoryTransaction
        fields = ['product', 'transaction_type', 'quantity', 'reference', 'notes']
        widgets = {
            'product': forms.Select(attrs={
                'class': 'form-select'
            }),
            'transaction_type': forms.Select(attrs={
                'class': 'form-select'
            }),
            'quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'reference': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter reference number'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter additional notes'
            })
        }

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        transaction_type = self.cleaned_data.get('transaction_type')
        product = self.cleaned_data.get('product')

        if quantity and quantity <= 0:
            raise ValidationError('Quantity must be greater than zero.')

        # Check if there's enough stock for outbound transactions
        if transaction_type in ['OUT', 'SALE', 'RETURN'] and product:
            if quantity > product.current_stock:
                raise ValidationError(
                    f'Insufficient stock. Available: {product.current_stock}, '
                    f'Requested: {quantity}'
                )

        return quantity


class StockAlertForm(ModelForm):
    """Form for creating and updating stock alerts"""

    class Meta:
        model = StockAlert
        fields = ['product', 'alert_type', 'threshold', 'is_active']
        widgets = {
            'product': forms.Select(attrs={
                'class': 'form-select'
            }),
            'alert_type': forms.Select(attrs={
                'class': 'form-select'
            }),
            'threshold': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'is_active': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            })
        }


class BulkInventoryUpdateForm(forms.Form):
    """Form for bulk inventory updates via CSV upload"""

    csv_file = forms.FileField(
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.csv'
        }),
        help_text='Upload a CSV file with columns: SKU, Quantity, Transaction Type'
    )

    def clean_csv_file(self):
        csv_file = self.cleaned_data.get('csv_file')
        if csv_file:
            if not csv_file.name.endswith('.csv'):
                raise ValidationError('Please upload a CSV file.')
            if csv_file.size > 5 * 1024 * 1024:  # 5MB limit
                raise ValidationError('File size must be less than 5MB.')
        return csv_file


class InventorySearchForm(forms.Form):
    """Form for searching and filtering inventory"""

    search = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by name, SKU, or barcode'
        })
    )

    category = forms.ModelChoiceField(
        queryset=Category.objects.filter(is_active=True),
        required=False,
        empty_label="All Categories",
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    supplier = forms.ModelChoiceField(
        queryset=Supplier.objects.filter(is_active=True),
        required=False,
        empty_label="All Suppliers",
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    stock_status = forms.ChoiceField(
        choices=[
            ('', 'All Stock Levels'),
            ('low', 'Low Stock'),
            ('out', 'Out of Stock'),
            ('normal', 'Normal Stock')
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    is_active = forms.ChoiceField(
        choices=[
            ('', 'All Products'),
            ('true', 'Active Only'),
            ('false', 'Inactive Only')
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )


class StockAdjustmentForm(forms.Form):
    """Form for manual stock adjustments"""

    product = forms.ModelChoiceField(
        queryset=Product.objects.filter(is_active=True),
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    adjustment_type = forms.ChoiceField(
        choices=[
            ('SET', 'Set Stock Level'),
            ('ADD', 'Add to Stock'),
            ('SUBTRACT', 'Subtract from Stock')
        ],
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )

    quantity = forms.IntegerField(
        min_value=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'min': '0'
        })
    )

    reason = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Enter reason for adjustment'
        })
    )

    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get('product')
        adjustment_type = cleaned_data.get('adjustment_type')
        quantity = cleaned_data.get('quantity')

        if product and adjustment_type == 'SUBTRACT' and quantity:
            if quantity > product.current_stock:
                raise ValidationError(
                    f'Cannot subtract {quantity} items. '
                    f'Current stock: {product.current_stock}'
                )

        return cleaned_data
