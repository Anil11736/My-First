from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from decimal import Decimal
import uuid


class Category(models.Model):
    """Product category model for organizing inventory items"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='subcategories')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

    def __str__(self):
        return self.name

    @property
    def full_path(self):
        """Returns the full category path (e.g., 'Electronics > Computers > Laptops')"""
        if self.parent:
            return f"{self.parent.full_path} > {self.name}"
        return self.name


class Supplier(models.Model):
    """Supplier model for tracking product sources"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    contact_person = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    country = models.CharField(max_length=100)
    tax_id = models.CharField(max_length=50, blank=True, null=True)
    payment_terms = models.CharField(max_length=100, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Product(models.Model):
    """Main product model for inventory management"""
    UNIT_CHOICES = [
        ('PCS', 'Pieces'),
        ('KG', 'Kilograms'),
        ('LB', 'Pounds'),
        ('TON', 'Tons'),
        ('L', 'Liters'),
        ('GAL', 'Gallons'),
        ('M', 'Meters'),
        ('FT', 'Feet'),
        ('M2', 'Square Meters'),
        ('M3', 'Cubic Meters'),
        ('BOX', 'Boxes'),
        ('PACK', 'Packs'),
        ('SET', 'Sets'),
    ]

    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('INACTIVE', 'Inactive'),
        ('DISCONTINUED', 'Discontinued'),
        ('PENDING', 'Pending Approval'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sku = models.CharField(max_length=100, unique=True, help_text="Stock Keeping Unit")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='products')
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name='products')

    # Pricing
    cost_price = models.DecimalField(max_digits=15, decimal_places=2, validators=[MinValueValidator(Decimal('0.00'))])
    selling_price = models.DecimalField(max_digits=15, decimal_places=2, validators=[MinValueValidator(Decimal('0.00'))])
    currency = models.CharField(max_length=3, default='USD')

    # Physical attributes
    weight = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True, help_text="Weight in kg")
    dimensions_length = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Length in cm")
    dimensions_width = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Width in cm")
    dimensions_height = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Height in cm")
    unit_of_measure = models.CharField(max_length=10, choices=UNIT_CHOICES, default='PCS')

    # Trade information
    hs_code = models.CharField(max_length=20, blank=True, null=True, help_text="Harmonized System Code")
    origin_country = models.CharField(max_length=100, blank=True, null=True)
    brand = models.CharField(max_length=100, blank=True, null=True)
    model_number = models.CharField(max_length=100, blank=True, null=True)

    # Inventory settings
    minimum_stock_level = models.IntegerField(default=0, validators=[MinValueValidator(0)])
    maximum_stock_level = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(0)])
    reorder_point = models.IntegerField(default=0, validators=[MinValueValidator(0)])

    # Status and metadata
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ACTIVE')
    is_serialized = models.BooleanField(default=False, help_text="Track individual serial numbers")
    is_perishable = models.BooleanField(default=False)
    shelf_life_days = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(1)])

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        indexes = [
            models.Index(fields=['sku']),
            models.Index(fields=['category']),
            models.Index(fields=['supplier']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.sku} - {self.name}"

    @property
    def profit_margin(self):
        """Calculate profit margin percentage"""
        if self.cost_price > 0:
            return ((self.selling_price - self.cost_price) / self.cost_price) * 100
        return 0

    @property
    def current_stock(self):
        """Get current stock level from inventory"""
        inventory = self.inventory.first()
        return inventory.quantity_available if inventory else 0

    @property
    def is_low_stock(self):
        """Check if product is below minimum stock level"""
        return self.current_stock <= self.minimum_stock_level

    @property
    def volume(self):
        """Calculate volume in cubic centimeters"""
        if all([self.dimensions_length, self.dimensions_width, self.dimensions_height]):
            return self.dimensions_length * self.dimensions_width * self.dimensions_height
        return None


class Inventory(models.Model):
    """Inventory tracking model for stock levels and locations"""
    TRANSACTION_TYPES = [
        ('IN', 'Stock In'),
        ('OUT', 'Stock Out'),
        ('ADJUSTMENT', 'Adjustment'),
        ('TRANSFER', 'Transfer'),
        ('RETURN', 'Return'),
        ('DAMAGE', 'Damage'),
        ('EXPIRED', 'Expired'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='inventory')
    warehouse_location = models.CharField(max_length=100, default='MAIN')

    # Stock quantities
    quantity_available = models.IntegerField(default=0, validators=[MinValueValidator(0)])
    quantity_reserved = models.IntegerField(default=0, validators=[MinValueValidator(0)])
    quantity_damaged = models.IntegerField(default=0, validators=[MinValueValidator(0)])

    # Batch/Lot tracking
    batch_number = models.CharField(max_length=100, blank=True, null=True)
    lot_number = models.CharField(max_length=100, blank=True, null=True)
    manufacturing_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)

    # Cost tracking
    average_cost = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))
    last_cost = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['product', 'warehouse_location', 'batch_number']
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.product.sku} - {self.warehouse_location} ({self.quantity_available})"

    @property
    def total_quantity(self):
        """Total quantity including available, reserved, and damaged"""
        return self.quantity_available + self.quantity_reserved + self.quantity_damaged

    @property
    def is_expired(self):
        """Check if inventory item is expired"""
        if self.expiry_date:
            return timezone.now().date() > self.expiry_date
        return False

    @property
    def days_to_expiry(self):
        """Calculate days until expiry"""
        if self.expiry_date:
            delta = self.expiry_date - timezone.now().date()
            return delta.days
        return None


class InventoryTransaction(models.Model):
    """Track all inventory movements and changes"""
    TRANSACTION_TYPES = [
        ('PURCHASE', 'Purchase'),
        ('SALE', 'Sale'),
        ('ADJUSTMENT', 'Adjustment'),
        ('TRANSFER_IN', 'Transfer In'),
        ('TRANSFER_OUT', 'Transfer Out'),
        ('RETURN_IN', 'Return In'),
        ('RETURN_OUT', 'Return Out'),
        ('DAMAGE', 'Damage'),
        ('EXPIRED', 'Expired'),
        ('INITIAL', 'Initial Stock'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    inventory = models.ForeignKey(Inventory, on_delete=models.CASCADE, related_name='transactions')
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)

    # Quantity changes
    quantity_before = models.IntegerField()
    quantity_change = models.IntegerField()  # Can be negative
    quantity_after = models.IntegerField()

    # Reference information
    reference_number = models.CharField(max_length=100, blank=True, null=True)
    reference_type = models.CharField(max_length=50, blank=True, null=True)  # 'PURCHASE_ORDER', 'SALES_ORDER', etc.

    # Cost information
    unit_cost = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    total_cost = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)

    # Additional details
    notes = models.TextField(blank=True, null=True)
    performed_by = models.CharField(max_length=100, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['inventory', 'transaction_type']),
            models.Index(fields=['reference_number']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.inventory.product.sku} - {self.transaction_type} ({self.quantity_change:+d})"


class StockAlert(models.Model):
    """Stock alert notifications for low stock, expiry, etc."""
    ALERT_TYPES = [
        ('LOW_STOCK', 'Low Stock'),
        ('OUT_OF_STOCK', 'Out of Stock'),
        ('EXPIRY_WARNING', 'Expiry Warning'),
        ('EXPIRED', 'Expired'),
        ('OVERSTOCK', 'Overstock'),
    ]

    PRIORITY_LEVELS = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('CRITICAL', 'Critical'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='alerts')
    inventory = models.ForeignKey(Inventory, on_delete=models.CASCADE, related_name='alerts', null=True, blank=True)

    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    priority = models.CharField(max_length=10, choices=PRIORITY_LEVELS, default='MEDIUM')
    message = models.TextField()

    is_resolved = models.BooleanField(default=False)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.CharField(max_length=100, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-priority', '-created_at']
        indexes = [
            models.Index(fields=['alert_type', 'is_resolved']),
            models.Index(fields=['priority']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.product.sku} - {self.alert_type} ({self.priority})"

    def resolve(self, resolved_by=None):
        """Mark alert as resolved"""
        self.is_resolved = True
        self.resolved_at = timezone.now()
        self.resolved_by = resolved_by
        self.save()
