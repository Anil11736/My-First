from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Sum, Count
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.utils import timezone
from datetime import datetime, timedelta
import json
import csv
from .models import Product, Category, Supplier, StockMovement, Warehouse, InventoryAlert
from .forms import ProductForm, CategoryForm, SupplierForm, StockMovementForm, WarehouseForm


@login_required
def inventory_dashboard(request):
    """Main inventory dashboard with key metrics and alerts"""
    # Key metrics
    total_products = Product.objects.count()
    total_categories = Category.objects.count()
    total_suppliers = Supplier.objects.filter(is_active=True).count()
    total_warehouses = Warehouse.objects.filter(is_active=True).count()

    # Stock alerts
    low_stock_products = Product.objects.filter(
        current_stock__lte=models.F('minimum_stock_level'),
        is_active=True
    ).count()

    out_of_stock_products = Product.objects.filter(
        current_stock=0,
        is_active=True
    ).count()

    # Recent stock movements
    recent_movements = StockMovement.objects.select_related(
        'product', 'warehouse', 'created_by'
    ).order_by('-created_at')[:10]

    # Inventory value
    total_inventory_value = Product.objects.aggregate(
        total_value=Sum(models.F('current_stock') * models.F('unit_price'))
    )['total_value'] or 0

    # Top products by stock value
    top_products = Product.objects.annotate(
        stock_value=models.F('current_stock') * models.F('unit_price')
    ).order_by('-stock_value')[:5]

    # Active alerts
    active_alerts = InventoryAlert.objects.filter(
        is_resolved=False
    ).order_by('-created_at')[:5]

    context = {
        'total_products': total_products,
        'total_categories': total_categories,
        'total_suppliers': total_suppliers,
        'total_warehouses': total_warehouses,
        'low_stock_products': low_stock_products,
        'out_of_stock_products': out_of_stock_products,
        'recent_movements': recent_movements,
        'total_inventory_value': total_inventory_value,
        'top_products': top_products,
        'active_alerts': active_alerts,
    }

    return render(request, 'inventory/dashboard.html', context)


class ProductListView(LoginRequiredMixin, ListView):
    """List all products with search and filtering"""
    model = Product
    template_name = 'inventory/product_list.html'
    context_object_name = 'products'
    paginate_by = 20

    def get_queryset(self):
        queryset = Product.objects.select_related('category', 'supplier').all()

        # Search functionality
        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(sku__icontains=search_query) |
                Q(description__icontains=search_query)
            )

        # Category filter
        category_id = self.request.GET.get('category')
        if category_id:
            queryset = queryset.filter(category_id=category_id)

        # Supplier filter
        supplier_id = self.request.GET.get('supplier')
        if supplier_id:
            queryset = queryset.filter(supplier_id=supplier_id)

        # Stock status filter
        stock_status = self.request.GET.get('stock_status')
        if stock_status == 'low':
            queryset = queryset.filter(current_stock__lte=models.F('minimum_stock_level'))
        elif stock_status == 'out':
            queryset = queryset.filter(current_stock=0)
        elif stock_status == 'available':
            queryset = queryset.filter(current_stock__gt=0)

        # Sorting
        sort_by = self.request.GET.get('sort', 'name')
        if sort_by in ['name', 'sku', 'current_stock', 'unit_price', 'created_at']:
            if self.request.GET.get('order') == 'desc':
                sort_by = f'-{sort_by}'
            queryset = queryset.order_by(sort_by)

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['categories'] = Category.objects.filter(is_active=True)
        context['suppliers'] = Supplier.objects.filter(is_active=True)
        context['search_query'] = self.request.GET.get('search', '')
        context['selected_category'] = self.request.GET.get('category', '')
        context['selected_supplier'] = self.request.GET.get('supplier', '')
        context['selected_stock_status'] = self.request.GET.get('stock_status', '')
        return context


@login_required
def product_detail(request, pk):
    """Product detail view with stock history"""
    product = get_object_or_404(Product, pk=pk)

    # Stock movements for this product
    stock_movements = StockMovement.objects.filter(
        product=product
    ).select_related('warehouse', 'created_by').order_by('-created_at')

    # Paginate stock movements
    paginator = Paginator(stock_movements, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Stock statistics
    total_inbound = StockMovement.objects.filter(
        product=product,
        movement_type='IN'
    ).aggregate(total=Sum('quantity'))['total'] or 0

    total_outbound = StockMovement.objects.filter(
        product=product,
        movement_type='OUT'
    ).aggregate(total=Sum('quantity'))['total'] or 0

    context = {
        'product': product,
        'stock_movements': page_obj,
        'total_inbound': total_inbound,
        'total_outbound': total_outbound,
    }

    return render(request, 'inventory/product_detail.html', context)


class ProductCreateView(LoginRequiredMixin, CreateView):
    """Create new product"""
    model = Product
    form_class = ProductForm
    template_name = 'inventory/product_form.html'
    success_url = reverse_lazy('inventory:product_list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        messages.success(self.request, 'Product created successfully!')
        return super().form_valid(form)


class ProductUpdateView(LoginRequiredMixin, UpdateView):
    """Update existing product"""
    model = Product
    form_class = ProductForm
    template_name = 'inventory/product_form.html'
    success_url = reverse_lazy('inventory:product_list')

    def form_valid(self, form):
        form.instance.updated_by = self.request.user
        messages.success(self.request, 'Product updated successfully!')
        return super().form_valid(form)


@login_required
@require_http_methods(["POST"])
def adjust_stock(request, pk):
    """Adjust product stock levels"""
    product = get_object_or_404(Product, pk=pk)

    try:
        data = json.loads(request.body)
        adjustment_type = data.get('type')  # 'add' or 'subtract'
        quantity = int(data.get('quantity', 0))
        reason = data.get('reason', '')
        warehouse_id = data.get('warehouse_id')

        if quantity <= 0:
            return JsonResponse({'success': False, 'error': 'Quantity must be positive'})

        warehouse = get_object_or_404(Warehouse, pk=warehouse_id) if warehouse_id else None

        with transaction.atomic():
            if adjustment_type == 'add':
                product.current_stock += quantity
                movement_type = 'IN'
                movement_reason = reason or 'Stock adjustment - increase'
            elif adjustment_type == 'subtract':
                if product.current_stock < quantity:
                    return JsonResponse({
                        'success': False,
                        'error': 'Insufficient stock available'
                    })
                product.current_stock -= quantity
                movement_type = 'OUT'
                movement_reason = reason or 'Stock adjustment - decrease'
            else:
                return JsonResponse({'success': False, 'error': 'Invalid adjustment type'})

            product.save()

            # Create stock movement record
            StockMovement.objects.create(
                product=product,
                warehouse=warehouse,
                movement_type=movement_type,
                quantity=quantity,
                reason=movement_reason,
                created_by=request.user
            )

            # Check for low stock alerts
            if product.current_stock <= product.minimum_stock_level:
                InventoryAlert.objects.get_or_create(
                    product=product,
                    alert_type='LOW_STOCK',
                    defaults={
                        'message': f'Low stock alert for {product.name}. Current: {product.current_stock}, Minimum: {product.minimum_stock_level}',
                        'created_by': request.user
                    }
                )

        return JsonResponse({
            'success': True,
            'new_stock': product.current_stock,
            'message': f'Stock adjusted successfully. New stock level: {product.current_stock}'
        })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


class CategoryListView(LoginRequiredMixin, ListView):
    """List all categories"""
    model = Category
    template_name = 'inventory/category_list.html'
    context_object_name = 'categories'
    paginate_by = 20

    def get_queryset(self):
        queryset = Category.objects.annotate(
            product_count=Count('products')
        ).all()

        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(description__icontains=search_query)
            )

        return queryset.order_by('name')


class CategoryCreateView(LoginRequiredMixin, CreateView):
    """Create new category"""
    model = Category
    form_class = CategoryForm
    template_name = 'inventory/category_form.html'
    success_url = reverse_lazy('inventory:category_list')

    def form_valid(self, form):
        messages.success(self.request, 'Category created successfully!')
        return super().form_valid(form)


class SupplierListView(LoginRequiredMixin, ListView):
    """List all suppliers"""
    model = Supplier
    template_name = 'inventory/supplier_list.html'
    context_object_name = 'suppliers'
    paginate_by = 20

    def get_queryset(self):
        queryset = Supplier.objects.annotate(
            product_count=Count('products')
        ).all()

        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(contact_person__icontains=search_query) |
                Q(email__icontains=search_query)
            )

        return queryset.order_by('name')


class SupplierCreateView(LoginRequiredMixin, CreateView):
    """Create new supplier"""
    model = Supplier
    form_class = SupplierForm
    template_name = 'inventory/supplier_form.html'
    success_url = reverse_lazy('inventory:supplier_list')

    def form_valid(self, form):
        messages.success(self.request, 'Supplier created successfully!')
        return super().form_valid(form)


@login_required
def stock_movements(request):
    """Stock movements history with filtering"""
    movements = StockMovement.objects.select_related(
        'product', 'warehouse', 'created_by'
    ).all()

    # Filtering
    product_id = request.GET.get('product')
    if product_id:
        movements = movements.filter(product_id=product_id)

    warehouse_id = request.GET.get('warehouse')
    if warehouse_id:
        movements = movements.filter(warehouse_id=warehouse_id)

    movement_type = request.GET.get('movement_type')
    if movement_type:
        movements = movements.filter(movement_type=movement_type)

    date_from = request.GET.get('date_from')
    if date_from:
        movements = movements.filter(created_at__date__gte=date_from)

    date_to = request.GET.get('date_to')
    if date_to:
        movements = movements.filter(created_at__date__lte=date_to)

    movements = movements.order_by('-created_at')

    # Pagination
    paginator = Paginator(movements, 25)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'movements': page_obj,
        'products': Product.objects.filter(is_active=True),
        'warehouses': Warehouse.objects.filter(is_active=True),
        'filters': {
            'product': request.GET.get('product', ''),
            'warehouse': request.GET.get('warehouse', ''),
            'movement_type': request.GET.get('movement_type', ''),
            'date_from': request.GET.get('date_from', ''),
            'date_to': request.GET.get('date_to', ''),
        }
    }

    return render(request, 'inventory/stock_movements.html', context)


@login_required
def inventory_reports(request):
    """Inventory reports and analytics"""
    # Stock valuation report
    products_with_value = Product.objects.annotate(
        stock_value=models.F('current_stock') * models.F('unit_price')
    ).filter(is_active=True).order_by('-stock_value')

    # Category-wise stock distribution
    category_stats = Category.objects.annotate(
        total_products=Count('products'),
        total_stock=Sum('products__current_stock'),
        total_value=Sum(models.F('products__current_stock') * models.F('products__unit_price'))
    ).filter(is_active=True)

    # Low stock alerts
    low_stock_products = Product.objects.filter(
        current_stock__lte=models.F('minimum_stock_level'),
        is_active=True
    ).order_by('current_stock')

    # Stock movement trends (last 30 days)
    thirty_days_ago = timezone.now() - timedelta(days=30)
    movement_trends = StockMovement.objects.filter(
        created_at__gte=thirty_days_ago
    ).extra(
        select={'day': 'date(created_at)'}
    ).values('day', 'movement_type').annotate(
        total_quantity=Sum('quantity')
    ).order_by('day')

    context = {
        'products_with_value': products_with_value[:20],
        'category_stats': category_stats,
        'low_stock_products': low_stock_products,
        'movement_trends': movement_trends,
        'total_inventory_value': products_with_value.aggregate(
            total=Sum('stock_value')
        )['total'] or 0,
    }

    return render(request, 'inventory/reports.html', context)


@login_required
def export_inventory_csv(request):
    """Export inventory data to CSV"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="inventory_export.csv"'

    writer = csv.writer(response)
    writer.writerow([
        'SKU', 'Product Name', 'Category', 'Supplier', 'Current Stock',
        'Minimum Stock', 'Unit Price', 'Stock Value', 'Status'
    ])

    products = Product.objects.select_related('category', 'supplier').all()

    for product in products:
        stock_value = product.current_stock * product.unit_price
        status = 'Active' if product.is_active else 'Inactive'

        if product.current_stock == 0:
            status += ' - Out of Stock'
        elif product.current_stock <= product.minimum_stock_level:
            status += ' - Low Stock'

        writer.writerow([
            product.sku,
            product.name,
            product.category.name if product.category else '',
            product.supplier.name if product.supplier else '',
            product.current_stock,
            product.minimum_stock_level,
            product.unit_price,
            stock_value,
            status
        ])

    return response


@login_required
def inventory_alerts(request):
    """View and manage inventory alerts"""
    alerts = InventoryAlert.objects.select_related(
        'product', 'created_by'
    ).order_by('-created_at')

    # Filter by status
    status = request.GET.get('status')
    if status == 'active':
        alerts = alerts.filter(is_resolved=False)
    elif status == 'resolved':
        alerts = alerts.filter(is_resolved=True)

    # Filter by alert type
    alert_type = request.GET.get('alert_type')
    if alert_type:
        alerts = alerts.filter(alert_type=alert_type)

    # Pagination
    paginator = Paginator(alerts, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'alerts': page_obj,
        'alert_types': InventoryAlert.ALERT_TYPES,
        'filters': {
            'status': request.GET.get('status', ''),
            'alert_type': request.GET.get('alert_type', ''),
        }
    }

    return render(request, 'inventory/alerts.html', context)


@login_required
@require_http_methods(["POST"])
def resolve_alert(request, alert_id):
    """Mark an alert as resolved"""
    alert = get_object_or_404(InventoryAlert, pk=alert_id)
    alert.is_resolved = True
    alert.resolved_at = timezone.now()
    alert.resolved_by = request.user
    alert.save()

    messages.success(request, 'Alert marked as resolved.')
    return redirect('inventory:alerts')
