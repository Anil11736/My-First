from rest_framework import serializers
from .models import Product, ProductCategory, StockMovement


class ProductCategorySerializer(serializers.ModelSerializer):
    products_count = serializers.SerializerMethodField()

    class Meta:
        model = ProductCategory
        fields = ['id', 'name', 'description', 'products_count']
        read_only_fields = ['id']

    def get_products_count(self, obj):
        return obj.products.count()


class ProductSerializer(serializers.ModelSerializer):
    category = ProductCategorySerializer(read_only=True)
    category_id = serializers.IntegerField(write_only=True)
    stock_value = serializers.SerializerMethodField()
    low_stock_alert = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'sku', 'description', 'category', 'category_id',
            'hs_code', 'unit_of_measure', 'weight', 'dimensions',
            'unit_price', 'cost_price', 'stock_quantity', 'minimum_stock',
            'maximum_stock', 'reorder_point', 'supplier_info',
            'country_of_origin', 'is_active', 'created_at', 'updated_at',
            'stock_value', 'low_stock_alert'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def get_stock_value(self, obj):
        return obj.stock_quantity * obj.cost_price

    def get_low_stock_alert(self, obj):
        return obj.stock_quantity <= obj.reorder_point


class ProductListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'sku', 'category_name', 'unit_price',
            'stock_quantity', 'minimum_stock', 'is_active'
        ]


class StockMovementSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    product_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = StockMovement
        fields = [
            'id', 'product', 'product_id', 'movement_type', 'quantity',
            'reference_number', 'notes', 'created_at', 'created_by'
        ]
        read_only_fields = ['id', 'created_at']


class StockAdjustmentSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    adjustment_type = serializers.ChoiceField(choices=[
        ('increase', 'Increase'),
        ('decrease', 'Decrease'),
        ('set', 'Set to specific amount')
    ])
    quantity = serializers.IntegerField(min_value=0)
    reason = serializers.CharField(max_length=200)

    def validate_product_id(self, value):
        try:
            Product.objects.get(id=value)
        except Product.DoesNotExist:
            raise serializers.ValidationError("Product not found")
        return value


class LowStockReportSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    stock_shortage = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'sku', 'category_name', 'stock_quantity',
            'minimum_stock', 'reorder_point', 'stock_shortage'
        ]

    def get_stock_shortage(self, obj):
        return max(0, obj.minimum_stock - obj.stock_quantity)
