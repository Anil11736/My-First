from django.urls import path
from . import views

app_name = 'inventory'

urlpatterns = [
    # Product URLs
    path('products/', views.ProductListView.as_view(), name='product_list'),
    path('products/create/', views.ProductCreateView.as_view(), name='product_create'),
    path('products/<int:pk>/', views.ProductDetailView.as_view(), name='product_detail'),
    path('products/<int:pk>/edit/', views.ProductUpdateView.as_view(), name='product_update'),
    path('products/<int:pk>/delete/', views.ProductDeleteView.as_view(), name='product_delete'),

    # Category URLs
    path('categories/', views.CategoryListView.as_view(), name='category_list'),
    path('categories/create/', views.CategoryCreateView.as_view(), name='category_create'),
    path('categories/<int:pk>/', views.CategoryDetailView.as_view(), name='category_detail'),
    path('categories/<int:pk>/edit/', views.CategoryUpdateView.as_view(), name='category_update'),
    path('categories/<int:pk>/delete/', views.CategoryDeleteView.as_view(), name='category_delete'),

    # Supplier URLs
    path('suppliers/', views.SupplierListView.as_view(), name='supplier_list'),
    path('suppliers/create/', views.SupplierCreateView.as_view(), name='supplier_create'),
    path('suppliers/<int:pk>/', views.SupplierDetailView.as_view(), name='supplier_detail'),
    path('suppliers/<int:pk>/edit/', views.SupplierUpdateView.as_view(), name='supplier_update'),
    path('suppliers/<int:pk>/delete/', views.SupplierDeleteView.as_view(), name='supplier_delete'),

    # Warehouse URLs
    path('warehouses/', views.WarehouseListView.as_view(), name='warehouse_list'),
    path('warehouses/create/', views.WarehouseCreateView.as_view(), name='warehouse_create'),
    path('warehouses/<int:pk>/', views.WarehouseDetailView.as_view(), name='warehouse_detail'),
    path('warehouses/<int:pk>/edit/', views.WarehouseUpdateView.as_view(), name='warehouse_update'),
    path('warehouses/<int:pk>/delete/', views.WarehouseDeleteView.as_view(), name='warehouse_delete'),

    # Stock Movement URLs
    path('stock-movements/', views.StockMovementListView.as_view(), name='stock_movement_list'),
    path('stock-movements/create/', views.StockMovementCreateView.as_view(), name='stock_movement_create'),
    path('stock-movements/<int:pk>/', views.StockMovementDetailView.as_view(), name='stock_movement_detail'),

    # Inventory Report URLs
    path('reports/', views.InventoryReportView.as_view(), name='inventory_report'),
    path('reports/low-stock/', views.LowStockReportView.as_view(), name='low_stock_report'),
    path('reports/stock-valuation/', views.StockValuationReportView.as_view(), name='stock_valuation_report'),

    # AJAX URLs for dynamic functionality
    path('ajax/get-product-details/<int:product_id>/', views.get_product_details, name='get_product_details'),
    path('ajax/check-stock-availability/', views.check_stock_availability, name='check_stock_availability'),
    path('ajax/update-stock-quantity/', views.update_stock_quantity, name='update_stock_quantity'),

    # Dashboard
    path('dashboard/', views.InventoryDashboardView.as_view(), name='inventory_dashboard'),

    # Bulk operations
    path('products/bulk-import/', views.ProductBulkImportView.as_view(), name='product_bulk_import'),
    path('products/bulk-export/', views.ProductBulkExportView.as_view(), name='product_bulk_export'),

    # API endpoints for mobile/external access
    path('api/products/', views.ProductAPIView.as_view(), name='product_api'),
    path('api/stock-levels/', views.StockLevelAPIView.as_view(), name='stock_level_api'),
]
