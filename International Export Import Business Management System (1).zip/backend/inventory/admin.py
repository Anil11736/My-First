from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import Category, Product, Warehouse, Stock, StockMovement, Supplier

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'description')
    ordering = ('name',)
    list_editable = ('is_active',)

    fieldsets = (
        (None, {
            'fields': ('name', 'description', 'is_active')
        }),
    )

@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('name', 'contact_person', 'email', 'phone', 'country', 'is_active', 'created_at')
    list_filter = ('country', 'is_active', 'created_at')
    search_fields = ('name', 'contact_person', 'email', 'phone')
    ordering = ('name',)
    list_editable = ('is_active',)

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'contact_person', 'email', 'phone')
        }),
        ('Address', {
            'fields': ('address', 'city', 'state', 'country', 'postal_code')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
    )

@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'manager', 'capacity', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'location', 'manager')
    ordering = ('name',)
    list_editable = ('is_active',)

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'location', 'manager')
        }),
        ('Details', {
            'fields': ('capacity', 'description', 'is_active')
        }),
    )

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'sku', 'category', 'supplier', 'unit_price', 'weight', 'is_active', 'created_at')
    list_filter = ('category', 'supplier', 'is_active', 'created_at')
    search_fields = ('name', 'sku', 'description')
    ordering = ('name',)
    list_editable = ('is_active',)
    autocomplete_fields = ('category', 'supplier')

    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'sku', 'description', 'category', 'supplier')
        }),
        ('Pricing & Specifications', {
            'fields': ('unit_price', 'weight', 'dimensions', 'hs_code')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('category', 'supplier')

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ('product', 'warehouse', 'quantity', 'reserved_quantity', 'available_quantity', 'reorder_level', 'last_updated')
    list_filter = ('warehouse', 'product__category', 'last_updated')
    search_fields = ('product__name', 'product__sku', 'warehouse__name')
    ordering = ('product__name',)
    autocomplete_fields = ('product', 'warehouse')
    readonly_fields = ('last_updated',)

    fieldsets = (
        ('Product & Location', {
            'fields': ('product', 'warehouse')
        }),
        ('Stock Levels', {
            'fields': ('quantity', 'reserved_quantity', 'reorder_level')
        }),
        ('Timestamps', {
            'fields': ('last_updated',),
            'classes': ('collapse',)
        }),
    )

    def available_quantity(self, obj):
        return obj.quantity - obj.reserved_quantity
    available_quantity.short_description = 'Available'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('product', 'warehouse')

    # Add color coding for low stock
    def quantity(self, obj):
        if obj.quantity <= obj.reorder_level:
            return format_html(
                '<span style="color: red; font-weight: bold;">{}</span>',
                obj.quantity
            )
        return obj.quantity
    quantity.short_description = 'Quantity'

@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ('product', 'warehouse', 'movement_type', 'quantity', 'reference_number', 'created_by', 'created_at')
    list_filter = ('movement_type', 'warehouse', 'created_at', 'product__category')
    search_fields = ('product__name', 'product__sku', 'reference_number', 'notes')
    ordering = ('-created_at',)
    autocomplete_fields = ('product', 'warehouse')
    readonly_fields = ('created_at', 'created_by')
    date_hierarchy = 'created_at'

    fieldsets = (
        ('Movement Details', {
            'fields': ('product', 'warehouse', 'movement_type', 'quantity')
        }),
        ('Reference Information', {
            'fields': ('reference_number', 'notes')
        }),
        ('Audit Trail', {
            'fields': ('created_by', 'created_at'),
            'classes': ('collapse',)
        }),
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('product', 'warehouse', 'created_by')

    def save_model(self, request, obj, form, change):
        if not change:  # Only set created_by for new objects
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    # Add color coding for movement types
    def movement_type(self, obj):
        colors = {
            'IN': 'green',
            'OUT': 'red',
            'TRANSFER': 'blue',
            'ADJUSTMENT': 'orange'
        }
        color = colors.get(obj.movement_type, 'black')
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            obj.get_movement_type_display()
        )
    movement_type.short_description = 'Movement Type'

# Custom admin site configuration
admin.site.site_header = "Export-Import Business Management"
admin.site.site_title = "Inventory Admin"
admin.site.index_title = "Inventory Management Dashboard"
