from rest_framework import serializers
from .models import Shipment, ShipmentItem, TrackingUpdate
from customers.serializers import CustomerSerializer
from inventory.serializers import ProductSerializer


class TrackingUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrackingUpdate
        fields = [
            'id', 'status', 'location', 'description', 'timestamp',
            'updated_by'
        ]
        read_only_fields = ['id', 'timestamp']


class ShipmentItemSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    product_id = serializers.IntegerField(write_only=True)
    total_value = serializers.SerializerMethodField()

    class Meta:
        model = ShipmentItem
        fields = [
            'id', 'product', 'product_id', 'quantity', 'unit_price',
            'total_value', 'hs_code', 'description'
        ]
        read_only_fields = ['id']

    def get_total_value(self, obj):
        return obj.quantity * obj.unit_price


class ShipmentSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer(read_only=True)
    customer_id = serializers.IntegerField(write_only=True)
    items = ShipmentItemSerializer(many=True, read_only=True)
    tracking_updates = TrackingUpdateSerializer(many=True, read_only=True)
    total_value = serializers.SerializerMethodField()
    total_weight = serializers.SerializerMethodField()
    days_in_transit = serializers.SerializerMethodField()

    class Meta:
        model = Shipment
        fields = [
            'id', 'shipment_number', 'customer', 'customer_id', 'shipment_type',
            'status', 'origin_port', 'destination_port', 'departure_date',
            'estimated_arrival', 'actual_arrival', 'shipping_method',
            'carrier', 'tracking_number', 'container_number', 'seal_number',
            'total_weight', 'total_volume', 'currency', 'insurance_value',
            'special_instructions', 'created_at', 'updated_at', 'items',
            'tracking_updates', 'total_value', 'days_in_transit'
        ]
        read_only_fields = ['id', 'shipment_number', 'created_at', 'updated_at']

    def get_total_value(self, obj):
        return sum(item.quantity * item.unit_price for item in obj.items.all())

    def get_total_weight(self, obj):
        return sum(item.quantity * (item.product.weight or 0) for item in obj.items.all())

    def get_days_in_transit(self, obj):
        if obj.departure_date and obj.actual_arrival:
            return (obj.actual_arrival - obj.departure_date).days
        elif obj.departure_date:
            from django.utils import timezone
            return (timezone.now().date() - obj.departure_date).days
        return None


class ShipmentCreateSerializer(serializers.ModelSerializer):
    items = ShipmentItemSerializer(many=True)

    class Meta:
        model = Shipment
        fields = [
            'customer_id', 'shipment_type', 'origin_port', 'destination_port',
            'departure_date', 'estimated_arrival', 'shipping_method',
            'carrier', 'tracking_number', 'container_number', 'seal_number',
            'total_weight', 'total_volume', 'currency', 'insurance_value',
            'special_instructions', 'items'
        ]

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        shipment = Shipment.objects.create(**validated_data)

        for item_data in items_data:
            ShipmentItem.objects.create(shipment=shipment, **item_data)

        return shipment


class ShipmentListSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(source='customer.company_name', read_only=True)
    items_count = serializers.SerializerMethodField()

    class Meta:
        model = Shipment
        fields = [
            'id', 'shipment_number', 'customer_name', 'shipment_type',
            'status', 'origin_port', 'destination_port', 'departure_date',
            'estimated_arrival', 'items_count'
        ]

    def get_items_count(self, obj):
        return obj.items.count()


class TrackingSerializer(serializers.ModelSerializer):
    tracking_updates = TrackingUpdateSerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source='customer.company_name', read_only=True)

    class Meta:
        model = Shipment
        fields = [
            'id', 'shipment_number', 'customer_name', 'status',
            'origin_port', 'destination_port', 'departure_date',
            'estimated_arrival', 'actual_arrival', 'tracking_number',
            'tracking_updates'
        ]
