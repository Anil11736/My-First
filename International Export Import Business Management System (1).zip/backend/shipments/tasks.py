from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.template.loader import render_to_string
from django.contrib.auth import get_user_model
import requests
import logging
from datetime import datetime, timedelta
from .models import Shipment, ShipmentTracking, ShipmentDocument
from customers.models import Customer

logger = logging.getLogger(__name__)
User = get_user_model()

@shared_task(bind=True, max_retries=3)
def update_shipment_tracking(self, shipment_id):
    """
    Update shipment tracking information from carrier APIs
    """
    try:
        shipment = Shipment.objects.get(id=shipment_id)

        # Mock tracking API call (replace with actual carrier API)
        tracking_data = fetch_tracking_data(shipment.tracking_number, shipment.carrier)

        if tracking_data:
            # Create or update tracking record
            tracking, created = ShipmentTracking.objects.get_or_create(
                shipment=shipment,
                defaults={
                    'status': tracking_data.get('status', 'IN_TRANSIT'),
                    'location': tracking_data.get('location', ''),
                    'estimated_delivery': tracking_data.get('estimated_delivery'),
                    'last_updated': timezone.now()
                }
            )

            if not created:
                # Update existing tracking
                tracking.status = tracking_data.get('status', tracking.status)
                tracking.location = tracking_data.get('location', tracking.location)
                tracking.estimated_delivery = tracking_data.get('estimated_delivery', tracking.estimated_delivery)
                tracking.last_updated = timezone.now()
                tracking.save()

            # Update shipment status if changed
            new_status = map_carrier_status_to_shipment_status(tracking_data.get('status'))
            if shipment.status != new_status:
                old_status = shipment.status
                shipment.status = new_status
                shipment.save()

                # Send notification for status change
                send_shipment_status_notification.delay(shipment_id, old_status, new_status)

            logger.info(f"Updated tracking for shipment {shipment_id}")
            return f"Successfully updated tracking for shipment {shipment_id}"

    except Shipment.DoesNotExist:
        logger.error(f"Shipment {shipment_id} not found")
        return f"Shipment {shipment_id} not found"
    except Exception as exc:
        logger.error(f"Error updating tracking for shipment {shipment_id}: {str(exc)}")
        # Retry the task
        raise self.retry(exc=exc, countdown=60 * (self.request.retries + 1))

@shared_task
def bulk_update_shipment_tracking():
    """
    Update tracking for all active shipments
    """
    active_shipments = Shipment.objects.filter(
        status__in=['PENDING', 'IN_TRANSIT', 'CUSTOMS_CLEARANCE']
    )

    updated_count = 0
    for shipment in active_shipments:
        try:
            update_shipment_tracking.delay(shipment.id)
            updated_count += 1
        except Exception as e:
            logger.error(f"Failed to queue tracking update for shipment {shipment.id}: {str(e)}")

    logger.info(f"Queued tracking updates for {updated_count} shipments")
    return f"Queued tracking updates for {updated_count} shipments"

@shared_task
def send_shipment_status_notification(shipment_id, old_status, new_status):
    """
    Send email notification when shipment status changes
    """
    try:
        shipment = Shipment.objects.get(id=shipment_id)
        customer = shipment.customer

        # Prepare email context
        context = {
            'shipment': shipment,
            'customer': customer,
            'old_status': old_status,
            'new_status': new_status,
            'status_display': shipment.get_status_display(),
        }

        # Render email templates
        subject = f"Shipment Status Update - {shipment.shipment_number}"
        html_message = render_to_string('emails/shipment_status_update.html', context)
        plain_message = render_to_string('emails/shipment_status_update.txt', context)

        # Send email to customer
        send_mail(
            subject=subject,
            message=plain_message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[customer.email],
            html_message=html_message,
            fail_silently=False,
        )

        # Send email to assigned user if exists
        if shipment.assigned_to:
            send_mail(
                subject=f"[Internal] {subject}",
                message=plain_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[shipment.assigned_to.email],
                html_message=html_message,
                fail_silently=False,
            )

        logger.info(f"Sent status notification for shipment {shipment_id}")
        return f"Notification sent for shipment {shipment_id}"

    except Shipment.DoesNotExist:
        logger.error(f"Shipment {shipment_id} not found for notification")
        return f"Shipment {shipment_id} not found"
    except Exception as e:
        logger.error(f"Failed to send notification for shipment {shipment_id}: {str(e)}")
        raise

@shared_task
def send_delivery_reminder():
    """
    Send delivery reminders for shipments arriving soon
    """
    tomorrow = timezone.now().date() + timedelta(days=1)

    # Find shipments with estimated delivery tomorrow
    upcoming_deliveries = Shipment.objects.filter(
        estimated_delivery_date=tomorrow,
        status__in=['IN_TRANSIT', 'OUT_FOR_DELIVERY']
    )

    sent_count = 0
    for shipment in upcoming_deliveries:
        try:
            context = {
                'shipment': shipment,
                'customer': shipment.customer,
                'delivery_date': shipment.estimated_delivery_date,
            }

            subject = f"Delivery Reminder - {shipment.shipment_number}"
            html_message = render_to_string('emails/delivery_reminder.html', context)
            plain_message = render_to_string('emails/delivery_reminder.txt', context)

            send_mail(
                subject=subject,
                message=plain_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[shipment.customer.email],
                html_message=html_message,
                fail_silently=False,
            )

            sent_count += 1
            logger.info(f"Sent delivery reminder for shipment {shipment.id}")

        except Exception as e:
            logger.error(f"Failed to send delivery reminder for shipment {shipment.id}: {str(e)}")

    return f"Sent delivery reminders for {sent_count} shipments"

@shared_task
def check_overdue_shipments():
    """
    Check for overdue shipments and send alerts
    """
    today = timezone.now().date()

    # Find shipments that are overdue
    overdue_shipments = Shipment.objects.filter(
        estimated_delivery_date__lt=today,
        status__in=['PENDING', 'IN_TRANSIT', 'CUSTOMS_CLEARANCE']
    )

    alert_count = 0
    for shipment in overdue_shipments:
        try:
            days_overdue = (today - shipment.estimated_delivery_date).days

            context = {
                'shipment': shipment,
                'customer': shipment.customer,
                'days_overdue': days_overdue,
                'original_delivery_date': shipment.estimated_delivery_date,
            }

            # Send alert to customer
            subject = f"Shipment Delay Alert - {shipment.shipment_number}"
            html_message = render_to_string('emails/shipment_overdue.html', context)
            plain_message = render_to_string('emails/shipment_overdue.txt', context)

            send_mail(
                subject=subject,
                message=plain_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[shipment.customer.email],
                html_message=html_message,
                fail_silently=False,
            )

            # Send internal alert
            if shipment.assigned_to:
                send_mail(
                    subject=f"[URGENT] Overdue Shipment - {shipment.shipment_number}",
                    message=f"Shipment {shipment.shipment_number} is {days_overdue} days overdue.",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[shipment.assigned_to.email],
                    fail_silently=False,
                )

            alert_count += 1
            logger.warning(f"Sent overdue alert for shipment {shipment.id} - {days_overdue} days overdue")

        except Exception as e:
            logger.error(f"Failed to send overdue alert for shipment {shipment.id}: {str(e)}")

    return f"Sent overdue alerts for {alert_count} shipments"

@shared_task
def generate_shipment_reports():
    """
    Generate daily shipment reports
    """
    try:
        today = timezone.now().date()

        # Get shipment statistics
        stats = {
            'total_shipments': Shipment.objects.count(),
            'pending_shipments': Shipment.objects.filter(status='PENDING').count(),
            'in_transit_shipments': Shipment.objects.filter(status='IN_TRANSIT').count(),
            'delivered_shipments': Shipment.objects.filter(status='DELIVERED').count(),
            'delayed_shipments': Shipment.objects.filter(
                estimated_delivery_date__lt=today,
                status__in=['PENDING', 'IN_TRANSIT', 'CUSTOMS_CLEARANCE']
            ).count(),
            'today_deliveries': Shipment.objects.filter(
                estimated_delivery_date=today
            ).count(),
        }

        # Send report to administrators
        admin_users = User.objects.filter(is_staff=True, is_active=True)
        admin_emails = [user.email for user in admin_users if user.email]

        if admin_emails:
            context = {
                'date': today,
                'stats': stats,
            }

            subject = f"Daily Shipment Report - {today}"
            html_message = render_to_string('emails/daily_shipment_report.html', context)
            plain_message = render_to_string('emails/daily_shipment_report.txt', context)

            send_mail(
                subject=subject,
                message=plain_message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=admin_emails,
                html_message=html_message,
                fail_silently=False,
            )

        logger.info(f"Generated daily shipment report for {today}")
        return f"Daily report generated and sent to {len(admin_emails)} administrators"

    except Exception as e:
        logger.error(f"Failed to generate daily report: {str(e)}")
        raise

def fetch_tracking_data(tracking_number, carrier):
    """
    Mock function to fetch tracking data from carrier API
    Replace with actual API integration
    """
    # Mock tracking data - replace with real API calls
    mock_statuses = ['PICKED_UP', 'IN_TRANSIT', 'CUSTOMS_CLEARANCE', 'OUT_FOR_DELIVERY', 'DELIVERED']

    return {
        'status': 'IN_TRANSIT',
        'location': 'Distribution Center - Mumbai',
        'estimated_delivery': timezone.now().date() + timedelta(days=2),
        'last_update': timezone.now(),
    }

def map_carrier_status_to_shipment_status(carrier_status):
    """
    Map carrier-specific status to our shipment status
    """
    status_mapping = {
        'PICKED_UP': 'IN_TRANSIT',
        'IN_TRANSIT': 'IN_TRANSIT',
        'CUSTOMS_CLEARANCE': 'CUSTOMS_CLEARANCE',
        'OUT_FOR_DELIVERY': 'IN_TRANSIT',
        'DELIVERED': 'DELIVERED',
        'EXCEPTION': 'DELAYED',
        'RETURNED': 'RETURNED',
    }

    return status_mapping.get(carrier_status, 'PENDING')
