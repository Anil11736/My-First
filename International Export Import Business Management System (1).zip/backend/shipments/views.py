from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.core.paginator import Paginator
from django.db.models import Q
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
from django.urls import reverse
from django.template.loader import render_to_string
import json
from datetime import datetime, date
from decimal import Decimal

from .models import Shipment, ShipmentItem, ShipmentDocument, ShipmentTracking
from .forms import ShipmentForm, ShipmentItemForm, ShipmentDocumentForm
from customers.models import Customer


@login_required
def shipment_list(request):
    """Display list of shipments with search and filtering"""
    shipments = Shipment.objects.select_related('customer').order_by('-created_at')

    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        shipments = shipments.filter(
            Q(shipment_number__icontains=search_query) |
            Q(customer__company_name__icontains=search_query) |
            Q(origin_port__icontains=search_query) |
            Q(destination_port__icontains=search_query)
        )

    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        shipments = shipments.filter(status=status_filter)

    # Filter by shipment type
    type_filter = request.GET.get('type', '')
    if type_filter:
        shipments = shipments.filter(shipment_type=type_filter)

    # Pagination
    paginator = Paginator(shipments, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'status_filter': status_filter,
        'type_filter': type_filter,
        'status_choices': Shipment.STATUS_CHOICES,
        'type_choices': Shipment.TYPE_CHOICES,
    }

    return render(request, 'shipments/shipment_list.html', context)


@login_required
def shipment_detail(request, pk):
    """Display detailed view of a shipment"""
    shipment = get_object_or_404(Shipment, pk=pk)
    shipment_items = ShipmentItem.objects.filter(shipment=shipment)
    documents = ShipmentDocument.objects.filter(shipment=shipment)
    tracking_history = ShipmentTracking.objects.filter(shipment=shipment).order_by('-timestamp')

    context = {
        'shipment': shipment,
        'shipment_items': shipment_items,
        'documents': documents,
        'tracking_history': tracking_history,
    }

    return render(request, 'shipments/shipment_detail.html', context)


@login_required
def shipment_create(request):
    """Create a new shipment"""
    if request.method == 'POST':
        form = ShipmentForm(request.POST)
        if form.is_valid():
            shipment = form.save(commit=False)
            shipment.created_by = request.user
            shipment.save()

            # Create initial tracking entry
            ShipmentTracking.objects.create(
                shipment=shipment,
                status='PENDING',
                location=shipment.origin_port,
                notes='Shipment created',
                updated_by=request.user
            )

            messages.success(request, f'Shipment {shipment.shipment_number} created successfully.')
            return redirect('shipments:detail', pk=shipment.pk)
    else:
        form = ShipmentForm()

    customers = Customer.objects.filter(is_active=True).order_by('company_name')

    context = {
        'form': form,
        'customers': customers,
        'title': 'Create New Shipment'
    }

    return render(request, 'shipments/shipment_form.html', context)


@login_required
def shipment_edit(request, pk):
    """Edit an existing shipment"""
    shipment = get_object_or_404(Shipment, pk=pk)

    if request.method == 'POST':
        form = ShipmentForm(request.POST, instance=shipment)
        if form.is_valid():
            updated_shipment = form.save(commit=False)
            updated_shipment.updated_by = request.user
            updated_shipment.save()

            messages.success(request, f'Shipment {shipment.shipment_number} updated successfully.')
            return redirect('shipments:detail', pk=shipment.pk)
    else:
        form = ShipmentForm(instance=shipment)

    customers = Customer.objects.filter(is_active=True).order_by('company_name')

    context = {
        'form': form,
        'shipment': shipment,
        'customers': customers,
        'title': 'Edit Shipment'
    }

    return render(request, 'shipments/shipment_form.html', context)


@login_required
def shipment_delete(request, pk):
    """Delete a shipment"""
    shipment = get_object_or_404(Shipment, pk=pk)

    if request.method == 'POST':
        shipment_number = shipment.shipment_number
        shipment.delete()
        messages.success(request, f'Shipment {shipment_number} deleted successfully.')
        return redirect('shipments:list')

    context = {
        'shipment': shipment,
        'title': 'Delete Shipment'
    }

    return render(request, 'shipments/shipment_confirm_delete.html', context)


@login_required
def add_shipment_item(request, shipment_pk):
    """Add item to shipment"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)

    if request.method == 'POST':
        form = ShipmentItemForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.shipment = shipment
            item.save()

            # Update shipment total value
            shipment.calculate_total_value()

            messages.success(request, 'Item added to shipment successfully.')
            return redirect('shipments:detail', pk=shipment.pk)
    else:
        form = ShipmentItemForm()

    context = {
        'form': form,
        'shipment': shipment,
        'title': 'Add Item to Shipment'
    }

    return render(request, 'shipments/shipment_item_form.html', context)


@login_required
def edit_shipment_item(request, shipment_pk, item_pk):
    """Edit shipment item"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)
    item = get_object_or_404(ShipmentItem, pk=item_pk, shipment=shipment)

    if request.method == 'POST':
        form = ShipmentItemForm(request.POST, instance=item)
        if form.is_valid():
            form.save()

            # Update shipment total value
            shipment.calculate_total_value()

            messages.success(request, 'Item updated successfully.')
            return redirect('shipments:detail', pk=shipment.pk)
    else:
        form = ShipmentItemForm(instance=item)

    context = {
        'form': form,
        'shipment': shipment,
        'item': item,
        'title': 'Edit Shipment Item'
    }

    return render(request, 'shipments/shipment_item_form.html', context)


@login_required
def delete_shipment_item(request, shipment_pk, item_pk):
    """Delete shipment item"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)
    item = get_object_or_404(ShipmentItem, pk=item_pk, shipment=shipment)

    if request.method == 'POST':
        item.delete()

        # Update shipment total value
        shipment.calculate_total_value()

        messages.success(request, 'Item removed from shipment.')
        return redirect('shipments:detail', pk=shipment.pk)

    context = {
        'shipment': shipment,
        'item': item,
        'title': 'Delete Shipment Item'
    }

    return render(request, 'shipments/shipment_item_confirm_delete.html', context)


@login_required
def upload_document(request, shipment_pk):
    """Upload document for shipment"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)

    if request.method == 'POST':
        form = ShipmentDocumentForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.save(commit=False)
            document.shipment = shipment
            document.uploaded_by = request.user
            document.save()

            messages.success(request, 'Document uploaded successfully.')
            return redirect('shipments:detail', pk=shipment.pk)
    else:
        form = ShipmentDocumentForm()

    context = {
        'form': form,
        'shipment': shipment,
        'title': 'Upload Document'
    }

    return render(request, 'shipments/document_upload_form.html', context)


@login_required
def delete_document(request, shipment_pk, document_pk):
    """Delete shipment document"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)
    document = get_object_or_404(ShipmentDocument, pk=document_pk, shipment=shipment)

    if request.method == 'POST':
        document.delete()
        messages.success(request, 'Document deleted successfully.')
        return redirect('shipments:detail', pk=shipment.pk)

    context = {
        'shipment': shipment,
        'document': document,
        'title': 'Delete Document'
    }

    return render(request, 'shipments/document_confirm_delete.html', context)


@login_required
def update_tracking(request, shipment_pk):
    """Update shipment tracking status"""
    shipment = get_object_or_404(Shipment, pk=shipment_pk)

    if request.method == 'POST':
        status = request.POST.get('status')
        location = request.POST.get('location')
        notes = request.POST.get('notes', '')

        if status and location:
            # Update shipment status
            shipment.status = status
            shipment.save()

            # Create tracking entry
            ShipmentTracking.objects.create(
                shipment=shipment,
                status=status,
                location=location,
                notes=notes,
                updated_by=request.user
            )

            messages.success(request, 'Tracking information updated successfully.')
        else:
            messages.error(request, 'Status and location are required.')

    return redirect('shipments:detail', pk=shipment.pk)


@login_required
def shipment_tracking(request, shipment_number):
    """Public tracking page for customers"""
    try:
        shipment = Shipment.objects.get(shipment_number=shipment_number)
        tracking_history = ShipmentTracking.objects.filter(
            shipment=shipment
        ).order_by('timestamp')

        context = {
            'shipment': shipment,
            'tracking_history': tracking_history,
        }

        return render(request, 'shipments/tracking.html', context)
    except Shipment.DoesNotExist:
        messages.error(request, 'Shipment not found.')
        return render(request, 'shipments/tracking_not_found.html')


@login_required
def shipment_dashboard(request):
    """Shipment dashboard with statistics"""
    from django.db.models import Count, Sum

    # Get statistics
    total_shipments = Shipment.objects.count()
    pending_shipments = Shipment.objects.filter(status='PENDING').count()
    in_transit_shipments = Shipment.objects.filter(status='IN_TRANSIT').count()
    delivered_shipments = Shipment.objects.filter(status='DELIVERED').count()

    # Recent shipments
    recent_shipments = Shipment.objects.select_related('customer').order_by('-created_at')[:10]

    # Shipments by status
    status_stats = Shipment.objects.values('status').annotate(
        count=Count('id')
    ).order_by('status')

    # Monthly shipment trends (last 6 months)
    from django.utils import timezone
    from dateutil.relativedelta import relativedelta

    six_months_ago = timezone.now().date() - relativedelta(months=6)
    monthly_stats = []

    for i in range(6):
        month_start = six_months_ago + relativedelta(months=i)
        month_end = month_start + relativedelta(months=1) - relativedelta(days=1)

        count = Shipment.objects.filter(
            created_at__date__gte=month_start,
            created_at__date__lte=month_end
        ).count()

        monthly_stats.append({
            'month': month_start.strftime('%b %Y'),
            'count': count
        })

    context = {
        'total_shipments': total_shipments,
        'pending_shipments': pending_shipments,
        'in_transit_shipments': in_transit_shipments,
        'delivered_shipments': delivered_shipments,
        'recent_shipments': recent_shipments,
        'status_stats': status_stats,
        'monthly_stats': monthly_stats,
    }

    return render(request, 'shipments/dashboard.html', context)


@login_required
@require_http_methods(["GET"])
def get_shipment_data(request, pk):
    """API endpoint to get shipment data as JSON"""
    shipment = get_object_or_404(Shipment, pk=pk)

    data = {
        'id': shipment.id,
        'shipment_number': shipment.shipment_number,
        'customer': shipment.customer.company_name,
        'status': shipment.get_status_display(),
        'shipment_type': shipment.get_shipment_type_display(),
        'origin_port': shipment.origin_port,
        'destination_port': shipment.destination_port,
        'estimated_departure': shipment.estimated_departure.isoformat() if shipment.estimated_departure else None,
        'estimated_arrival': shipment.estimated_arrival.isoformat() if shipment.estimated_arrival else None,
        'total_value': float(shipment.total_value) if shipment.total_value else 0,
        'currency': shipment.currency,
        'created_at': shipment.created_at.isoformat(),
    }

    return JsonResponse(data)


@login_required
def export_shipments(request):
    """Export shipments to CSV"""
    import csv
    from django.http import HttpResponse

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="shipments.csv"'

    writer = csv.writer(response)
    writer.writerow([
        'Shipment Number', 'Customer', 'Type', 'Status',
        'Origin Port', 'Destination Port', 'Est. Departure',
        'Est. Arrival', 'Total Value', 'Currency', 'Created At'
    ])

    shipments = Shipment.objects.select_related('customer').all()

    for shipment in shipments:
        writer.writerow([
            shipment.shipment_number,
            shipment.customer.company_name,
            shipment.get_shipment_type_display(),
            shipment.get_status_display(),
            shipment.origin_port,
            shipment.destination_port,
            shipment.estimated_departure.strftime('%Y-%m-%d') if shipment.estimated_departure else '',
            shipment.estimated_arrival.strftime('%Y-%m-%d') if shipment.estimated_arrival else '',
            shipment.total_value or 0,
            shipment.currency,
            shipment.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        ])

    return response
