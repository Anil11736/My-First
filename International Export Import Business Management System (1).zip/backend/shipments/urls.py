from django.urls import path
from . import views

app_name = 'shipments'

urlpatterns = [
    # Shipment list and create
    path('', views.ShipmentListView.as_view(), name='shipment_list'),
    path('create/', views.ShipmentCreateView.as_view(), name='shipment_create'),

    # Shipment detail, update, delete
    path('<int:pk>/', views.ShipmentDetailView.as_view(), name='shipment_detail'),
    path('<int:pk>/edit/', views.ShipmentUpdateView.as_view(), name='shipment_update'),
    path('<int:pk>/delete/', views.ShipmentDeleteView.as_view(), name='shipment_delete'),

    # Shipment tracking
    path('<int:pk>/track/', views.ShipmentTrackingView.as_view(), name='shipment_track'),
    path('<int:pk>/tracking/add/', views.TrackingUpdateCreateView.as_view(), name='tracking_add'),
    path('tracking/<int:pk>/edit/', views.TrackingUpdateUpdateView.as_view(), name='tracking_edit'),
    path('tracking/<int:pk>/delete/', views.TrackingUpdateDeleteView.as_view(), name='tracking_delete'),

    # Shipment documents
    path('<int:pk>/documents/', views.ShipmentDocumentListView.as_view(), name='shipment_documents'),
    path('<int:pk>/documents/upload/', views.DocumentUploadView.as_view(), name='document_upload'),
    path('documents/<int:pk>/download/', views.DocumentDownloadView.as_view(), name='document_download'),
    path('documents/<int:pk>/delete/', views.DocumentDeleteView.as_view(), name='document_delete'),

    # Shipment status updates
    path('<int:pk>/status/update/', views.ShipmentStatusUpdateView.as_view(), name='status_update'),
    path('<int:pk>/complete/', views.ShipmentCompleteView.as_view(), name='shipment_complete'),
    path('<int:pk>/cancel/', views.ShipmentCancelView.as_view(), name='shipment_cancel'),

    # Bulk operations
    path('bulk/status/', views.BulkStatusUpdateView.as_view(), name='bulk_status_update'),
    path('bulk/export/', views.BulkExportView.as_view(), name='bulk_export'),

    # Reports and analytics
    path('reports/', views.ShipmentReportsView.as_view(), name='shipment_reports'),
    path('analytics/', views.ShipmentAnalyticsView.as_view(), name='shipment_analytics'),

    # Search and filter
    path('search/', views.ShipmentSearchView.as_view(), name='shipment_search'),
    path('filter/', views.ShipmentFilterView.as_view(), name='shipment_filter'),

    # API endpoints for AJAX calls
    path('api/status/<int:pk>/', views.ShipmentStatusAPIView.as_view(), name='api_shipment_status'),
    path('api/tracking/<int:pk>/', views.TrackingAPIView.as_view(), name='api_tracking'),
    path('api/documents/<int:pk>/', views.DocumentsAPIView.as_view(), name='api_documents'),

    # Public tracking (for customers)
    path('track/<str:tracking_number>/', views.PublicTrackingView.as_view(), name='public_tracking'),

    # Export/Import specific routes
    path('export/', views.ExportShipmentListView.as_view(), name='export_list'),
    path('import/', views.ImportShipmentListView.as_view(), name='import_list'),
    path('export/create/', views.ExportShipmentCreateView.as_view(), name='export_create'),
    path('import/create/', views.ImportShipmentCreateView.as_view(), name='import_create'),

    # Customs and compliance
    path('<int:pk>/customs/', views.CustomsDeclarationView.as_view(), name='customs_declaration'),
    path('<int:pk>/compliance/', views.ComplianceCheckView.as_view(), name='compliance_check'),

    # Notifications
    path('<int:pk>/notifications/', views.ShipmentNotificationsView.as_view(), name='shipment_notifications'),
    path('<int:pk>/notify/', views.SendNotificationView.as_view(), name='send_notification'),
]
