from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from decimal import Decimal
import uuid


class Order(models.Model):
    ORDER_STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('processing', 'Processing'),
        ('shipped', 'Shipped'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    ]

    ORDER_TYPE_CHOICES = [
        ('export', 'Export'),
        ('import', 'Import'),
    ]

    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_number = models.CharField(max_length=50, unique=True)
    customer = models.ForeignKey('customers.Customer', on_delete=models.CASCADE, related_name='orders')
    order_type = models.CharField(max_length=10, choices=ORDER_TYPE_CHOICES)
    status = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='draft')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')

    # Dates
    order_date = models.DateTimeField(default=timezone.now)
    expected_ship_date = models.DateField(null=True, blank=True)
    expected_delivery_date = models.DateField(null=True, blank=True)

    # Locations
    origin_country = models.CharField(max_length=100)
    origin_city = models.CharField(max_length=100)
    origin_address = models.TextField()
    destination_country = models.CharField(max_length=100)
    destination_city = models.CharField(max_length=100)
    destination_address = models.TextField()

    # Financial
    total_value = models.DecimalField(max_digits=15, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    currency = models.CharField(max_length=3, default='USD')

    # Additional Info
    special_instructions = models.TextField(blank=True)
    notes = models.TextField(blank=True)

    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_orders')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'orders'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['order_number']),
            models.Index(fields=['customer', 'status']),
            models.Index(fields=['order_type', 'status']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.order_number} - {self.customer.company_name}"

    def save(self, *args, **kwargs):
        if not self.order_number:
            self.order_number = self.generate_order_number()
        super().save(*args, **kwargs)

    def generate_order_number(self):
        prefix = 'EXP' if self.order_type == 'export' else 'IMP'
        year = timezone.now().year
        count = Order.objects.filter(
            order_type=self.order_type,
            created_at__year=year
        ).count() + 1
        return f"{prefix}{year}{count:06d}"


class OrderItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')

    # Product Details
    product_name = models.CharField(max_length=200)
    product_code = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    hs_code = models.CharField(max_length=20, blank=True, help_text="Harmonized System Code")

    # Quantity and Measurements
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_of_measure = models.CharField(max_length=20, default='PCS')
    weight_per_unit = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    total_weight = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)

    # Dimensions (in cm)
    length = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    width = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    volume = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)

    # Financial
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    total_price = models.DecimalField(max_digits=15, decimal_places=2)

    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'order_items'
        ordering = ['id']

    def __str__(self):
        return f"{self.product_name} - {self.quantity} {self.unit_of_measure}"

    def save(self, *args, **kwargs):
        self.total_price = self.quantity * self.unit_price
        if self.weight_per_unit and self.quantity:
            self.total_weight = self.weight_per_unit * self.quantity
        if self.length and self.width and self.height:
            self.volume = (self.length * self.width * self.height) / 1000000  # Convert to cubic meters
        super().save(*args, **kwargs)


class Shipment(models.Model):
    SHIPMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('booked', 'Booked'),
        ('in_transit', 'In Transit'),
        ('customs_clearance', 'Customs Clearance'),
        ('delivered', 'Delivered'),
        ('returned', 'Returned'),
        ('cancelled', 'Cancelled'),
    ]

    TRANSPORT_MODE_CHOICES = [
        ('sea', 'Sea Freight'),
        ('air', 'Air Freight'),
        ('land', 'Land Transport'),
        ('multimodal', 'Multimodal'),
    ]

    SERVICE_TYPE_CHOICES = [
        ('fcl', 'Full Container Load'),
        ('lcl', 'Less than Container Load'),
        ('air_express', 'Air Express'),
        ('air_economy', 'Air Economy'),
        ('road_express', 'Road Express'),
        ('road_standard', 'Road Standard'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shipment_number = models.CharField(max_length=50, unique=True)
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name='shipment')

    # Shipment Details
    status = models.CharField(max_length=20, choices=SHIPMENT_STATUS_CHOICES, default='pending')
    transport_mode = models.CharField(max_length=15, choices=TRANSPORT_MODE_CHOICES)
    service_type = models.CharField(max_length=20, choices=SERVICE_TYPE_CHOICES)

    # Carrier Information
    carrier_name = models.CharField(max_length=200)
    carrier_contact = models.CharField(max_length=100, blank=True)
    vessel_flight_number = models.CharField(max_length=100, blank=True)

    # Container/Package Information
    container_number = models.CharField(max_length=50, blank=True)
    container_type = models.CharField(max_length=50, blank=True)
    seal_number = models.CharField(max_length=50, blank=True)
    total_packages = models.PositiveIntegerField(default=1)

    # Weight and Volume
    gross_weight = models.DecimalField(max_digits=12, decimal_places=3)
    net_weight = models.DecimalField(max_digits=12, decimal_places=3)
    total_volume = models.DecimalField(max_digits=12, decimal_places=3)

    # Dates
    booking_date = models.DateTimeField(null=True, blank=True)
    estimated_departure = models.DateTimeField(null=True, blank=True)
    actual_departure = models.DateTimeField(null=True, blank=True)
    estimated_arrival = models.DateTimeField(null=True, blank=True)
    actual_arrival = models.DateTimeField(null=True, blank=True)

    # Ports/Terminals
    port_of_loading = models.CharField(max_length=200)
    port_of_discharge = models.CharField(max_length=200)
    final_destination = models.CharField(max_length=200, blank=True)

    # Documentation
    bill_of_lading = models.CharField(max_length=100, blank=True)
    master_bill_of_lading = models.CharField(max_length=100, blank=True)
    house_bill_of_lading = models.CharField(max_length=100, blank=True)

    # Insurance
    is_insured = models.BooleanField(default=False)
    insurance_value = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    insurance_policy = models.CharField(max_length=100, blank=True)

    # Additional Info
    special_handling = models.TextField(blank=True)
    remarks = models.TextField(blank=True)

    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_shipments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'shipments'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['shipment_number']),
            models.Index(fields=['status']),
            models.Index(fields=['transport_mode']),
            models.Index(fields=['carrier_name']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return f"{self.shipment_number} - {self.order.order_number}"

    def save(self, *args, **kwargs):
        if not self.shipment_number:
            self.shipment_number = self.generate_shipment_number()
        super().save(*args, **kwargs)

    def generate_shipment_number(self):
        prefix = 'SHP'
        year = timezone.now().year
        count = Shipment.objects.filter(created_at__year=year).count() + 1
        return f"{prefix}{year}{count:08d}"


class TrackingEvent(models.Model):
    EVENT_TYPE_CHOICES = [
        ('booked', 'Shipment Booked'),
        ('picked_up', 'Picked Up'),
        ('departed', 'Departed'),
        ('in_transit', 'In Transit'),
        ('arrived', 'Arrived'),
        ('customs_submitted', 'Customs Documents Submitted'),
        ('customs_cleared', 'Customs Cleared'),
        ('out_for_delivery', 'Out for Delivery'),
        ('delivered', 'Delivered'),
        ('exception', 'Exception'),
        ('returned', 'Returned'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shipment = models.ForeignKey(Shipment, on_delete=models.CASCADE, related_name='tracking_events')

    # Event Details
    event_type = models.CharField(max_length=20, choices=EVENT_TYPE_CHOICES)
    event_date = models.DateTimeField()
    location = models.CharField(max_length=200)
    description = models.TextField()

    # Additional Info
    milestone = models.BooleanField(default=False, help_text="Mark as major milestone")
    is_estimated = models.BooleanField(default=False)
    next_update = models.DateTimeField(null=True, blank=True)

    # External References
    carrier_reference = models.CharField(max_length=100, blank=True)
    external_tracking_id = models.CharField(max_length=100, blank=True)

    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_tracking_events')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'tracking_events'
        ordering = ['-event_date']
        indexes = [
            models.Index(fields=['shipment', 'event_date']),
            models.Index(fields=['event_type']),
            models.Index(fields=['milestone']),
        ]

    def __str__(self):
        return f"{self.shipment.shipment_number} - {self.get_event_type_display()}"


class ShipmentDocument(models.Model):
    DOCUMENT_TYPE_CHOICES = [
        ('commercial_invoice', 'Commercial Invoice'),
        ('packing_list', 'Packing List'),
        ('bill_of_lading', 'Bill of Lading'),
        ('certificate_of_origin', 'Certificate of Origin'),
        ('export_license', 'Export License'),
        ('import_license', 'Import License'),
        ('customs_declaration', 'Customs Declaration'),
        ('insurance_certificate', 'Insurance Certificate'),
        ('phytosanitary_certificate', 'Phytosanitary Certificate'),
        ('health_certificate', 'Health Certificate'),
        ('inspection_certificate', 'Inspection Certificate'),
        ('other', 'Other'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shipment = models.ForeignKey(Shipment, on_delete=models.CASCADE, related_name='documents')

    # Document Details
    document_type = models.CharField(max_length=30, choices=DOCUMENT_TYPE_CHOICES)
    document_number = models.CharField(max_length=100, blank=True)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)

    # File Information
    file_path = models.FileField(upload_to='shipment_documents/%Y/%m/')
    file_size = models.PositiveIntegerField(help_text="File size in bytes")
    file_type = models.CharField(max_length=10)

    # Status and Dates
    is_required = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    issue_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)

    # External References
    issuing_authority = models.CharField(max_length=200, blank=True)
    reference_number = models.CharField(max_length=100, blank=True)

    # Metadata
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='uploaded_documents')
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_documents')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'shipment_documents'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['shipment', 'document_type']),
            models.Index(fields=['is_required', 'is_verified']),
            models.Index(fields=['expiry_date']),
        ]

    def __str__(self):
        return f"{self.title} - {self.shipment.shipment_number}"


class ShipmentCost(models.Model):
    COST_TYPE_CHOICES = [
        ('freight', 'Freight Charges'),
        ('fuel_surcharge', 'Fuel Surcharge'),
        ('security_fee', 'Security Fee'),
        ('documentation', 'Documentation Fee'),
        ('handling', 'Handling Charges'),
        ('storage', 'Storage Charges'),
        ('customs_duty', 'Customs Duty'),
        ('customs_clearance', 'Customs Clearance'),
        ('inspection', 'Inspection Fee'),
        ('insurance', 'Insurance Premium'),
        ('terminal_handling', 'Terminal Handling'),
        ('delivery', 'Delivery Charges'),
        ('other', 'Other Charges'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shipment = models.ForeignKey(Shipment, on_delete=models.CASCADE, related_name='costs')

    # Cost Details
    cost_type = models.CharField(max_length=20, choices=COST_TYPE_CHOICES)
    description = models.CharField(max_length=200)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')

    # Billing Information
    vendor = models.CharField(max_length=200, blank=True)
    invoice_number = models.CharField(max_length=100, blank=True)
    invoice_date = models.DateField(null=True, blank=True)

    # Status
    is_estimated = models.BooleanField(default=True)
    is_paid = models.BooleanField(default=False)
    payment_date = models.DateField(null=True, blank=True)

    # Additional Info
    notes = models.TextField(blank=True)

    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_costs')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'shipment_costs'
        ordering = ['cost_type', '-created_at']
        indexes = [
            models.Index(fields=['shipment', 'cost_type']),
            models.Index(fields=['is_paid']),
            models.Index(fields=['invoice_date']),
        ]

    def __str__(self):
        return f"{self.get_cost_type_display()} - {self.amount} {self.currency}"
