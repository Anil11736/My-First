from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import Shipment, ShipmentItem, ShipmentDocument, ShipmentTracking


class ShipmentItemInline(admin.TabularInline):
    model = ShipmentItem
    extra = 1
    fields = ('product_name', 'hs_code', 'quantity', 'unit_price', 'total_value', 'weight', 'dimensions')
    readonly_fields = ('total_value',)


class ShipmentDocumentInline(admin.TabularInline):
    model = ShipmentDocument
    extra = 1
    fields = ('document_type', 'document_number', 'file', 'uploaded_at')
    readonly_fields = ('uploaded_at',)


class ShipmentTrackingInline(admin.TabularInline):
    model = ShipmentTracking
    extra = 0
    fields = ('status', 'location', 'timestamp', 'notes', 'created_by')
    readonly_fields = ('timestamp', 'created_by')


@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = (
        'shipment_number',
        'customer_link',
        'shipment_type',
        'status_badge',
        'origin_country',
        'destination_country',
        'total_value',
        'created_at'
    )
    list_filter = (
        'shipment_type',
        'status',
        'origin_country',
        'destination_country',
        'created_at',
        'estimated_delivery'
    )
    search_fields = (
        'shipment_number',
        'customer__company_name',
        'customer__contact_person',
        'origin_port',
        'destination_port'
    )
    readonly_fields = (
        'shipment_number',
        'created_at',
        'updated_at',
        'total_value_display',
        'total_weight_display'
    )
    fieldsets = (
        ('Basic Information', {
            'fields': (
                'shipment_number',
                'customer',
                'shipment_type',
                'status'
            )
        }),
        ('Origin & Destination', {
            'fields': (
                ('origin_country', 'origin_port'),
                ('destination_country', 'destination_port'),
                'shipping_address'
            )
        }),
        ('Shipping Details', {
            'fields': (
                ('shipping_method', 'carrier'),
                ('estimated_departure', 'estimated_delivery'),
                ('actual_departure', 'actual_delivery')
            )
        }),
        ('Financial Information', {
            'fields': (
                'currency',
                'total_value_display',
                'total_weight_display',
                'insurance_value'
            )
        }),
        ('Additional Information', {
            'fields': (
                'special_instructions',
                'notes'
            ),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': (
                'created_at',
                'updated_at'
            ),
            'classes': ('collapse',)
        })
    )
    inlines = [ShipmentItemInline, ShipmentDocumentInline, ShipmentTrackingInline]
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)

    def customer_link(self, obj):
        if obj.customer:
            url = reverse('admin:customers_customer_change', args=[obj.customer.pk])
            return format_html('<a href="{}">{}</a>', url, obj.customer.company_name)
        return '-'
    customer_link.short_description = 'Customer'

    def status_badge(self, obj):
        colors = {
            'DRAFT': '#6c757d',
            'CONFIRMED': '#007bff',
            'IN_TRANSIT': '#ffc107',
            'DELIVERED': '#28a745',
            'CANCELLED': '#dc3545'
        }
        color = colors.get(obj.status, '#6c757d')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px;">{}</span>',
            color,
            obj.get_status_display()
        )
    status_badge.short_description = 'Status'

    def total_value_display(self, obj):
        return f"{obj.currency} {obj.total_value:,.2f}" if obj.total_value else '-'
    total_value_display.short_description = 'Total Value'

    def total_weight_display(self, obj):
        return f"{obj.total_weight:.2f} kg" if obj.total_weight else '-'
    total_weight_display.short_description = 'Total Weight'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('customer')


@admin.register(ShipmentItem)
class ShipmentItemAdmin(admin.ModelAdmin):
    list_display = (
        'shipment_link',
        'product_name',
        'hs_code',
        'quantity',
        'unit_price',
        'total_value',
        'weight'
    )
    list_filter = ('shipment__shipment_type', 'shipment__status')
    search_fields = (
        'product_name',
        'hs_code',
        'shipment__shipment_number',
        'description'
    )
    readonly_fields = ('total_value',)
    fieldsets = (
        ('Product Information', {
            'fields': (
                'shipment',
                'product_name',
                'hs_code',
                'description'
            )
        }),
        ('Quantity & Pricing', {
            'fields': (
                ('quantity', 'unit'),
                ('unit_price', 'total_value')
            )
        }),
        ('Physical Properties', {
            'fields': (
                'weight',
                'dimensions'
            )
        })
    )

    def shipment_link(self, obj):
        url = reverse('admin:shipments_shipment_change', args=[obj.shipment.pk])
        return format_html('<a href="{}">{}</a>', url, obj.shipment.shipment_number)
    shipment_link.short_description = 'Shipment'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('shipment')


@admin.register(ShipmentDocument)
class ShipmentDocumentAdmin(admin.ModelAdmin):
    list_display = (
        'shipment_link',
        'document_type',
        'document_number',
        'file_link',
        'uploaded_at'
    )
    list_filter = ('document_type', 'uploaded_at')
    search_fields = (
        'document_number',
        'shipment__shipment_number',
        'document_type'
    )
    readonly_fields = ('uploaded_at',)
    fieldsets = (
        ('Document Information', {
            'fields': (
                'shipment',
                'document_type',
                'document_number',
                'file'
            )
        }),
        ('Metadata', {
            'fields': (
                'uploaded_at',
                'notes'
            )
        })
    )

    def shipment_link(self, obj):
        url = reverse('admin:shipments_shipment_change', args=[obj.shipment.pk])
        return format_html('<a href="{}">{}</a>', url, obj.shipment.shipment_number)
    shipment_link.short_description = 'Shipment'

    def file_link(self, obj):
        if obj.file:
            return format_html('<a href="{}" target="_blank">View File</a>', obj.file.url)
        return '-'
    file_link.short_description = 'File'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('shipment')


@admin.register(ShipmentTracking)
class ShipmentTrackingAdmin(admin.ModelAdmin):
    list_display = (
        'shipment_link',
        'status_badge',
        'location',
        'timestamp',
        'created_by'
    )
    list_filter = ('status', 'timestamp')
    search_fields = (
        'shipment__shipment_number',
        'location',
        'notes'
    )
    readonly_fields = ('timestamp', 'created_by')
    fieldsets = (
        ('Tracking Information', {
            'fields': (
                'shipment',
                'status',
                'location',
                'timestamp'
            )
        }),
        ('Additional Details', {
            'fields': (
                'notes',
                'created_by'
            )
        })
    )

    def shipment_link(self, obj):
        url = reverse('admin:shipments_shipment_change', args=[obj.shipment.pk])
        return format_html('<a href="{}">{}</a>', url, obj.shipment.shipment_number)
    shipment_link.short_description = 'Shipment'

    def status_badge(self, obj):
        colors = {
            'DRAFT': '#6c757d',
            'CONFIRMED': '#007bff',
            'IN_TRANSIT': '#ffc107',
            'DELIVERED': '#28a745',
            'CANCELLED': '#dc3545'
        }
        color = colors.get(obj.status, '#6c757d')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px;">{}</span>',
            color,
            obj.get_status_display()
        )
    status_badge.short_description = 'Status'

    def save_model(self, request, obj, form, change):
        if not change:  # Only set created_by for new objects
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('shipment', 'created_by')


# Custom admin site configuration
admin.site.site_header = "Export/Import Business Management"
admin.site.site_title = "Export/Import Admin"
admin.site.index_title = "Welcome to Export/Import Business Management"
