# -*- coding: utf-8 -*-
from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import date
from .models import Shipment, ShipmentItem, ShipmentDocument
from customers.models import Customer


class ShipmentForm(forms.ModelForm):
    """Form for creating and updating shipments"""

    customer = forms.ModelChoiceField(
        queryset=Customer.objects.all(),
        widget=forms.Select(attrs={
            'class': 'form-control',
            'placeholder': 'Select Customer'
        }),
        empty_label="Select Customer"
    )

    shipment_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )

    expected_delivery_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        }),
        required=False
    )

    origin_port = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Origin Port'
        })
    )

    destination_port = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Destination Port'
        })
    )

    shipping_method = forms.ChoiceField(
        choices=Shipment.SHIPPING_METHOD_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    incoterms = forms.ChoiceField(
        choices=Shipment.INCOTERMS_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    total_weight = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Total Weight (kg)',
            'step': '0.01'
        })
    )

    total_volume = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Total Volume (m³)',
            'step': '0.01'
        }),
        required=False
    )

    total_value = forms.DecimalField(
        max_digits=15,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Total Value',
            'step': '0.01'
        })
    )

    currency = forms.ChoiceField(
        choices=Shipment.CURRENCY_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    insurance_required = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        })
    )

    special_instructions = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Special handling instructions'
        })
    )

    class Meta:
        model = Shipment
        fields = [
            'customer', 'shipment_date', 'expected_delivery_date',
            'origin_port', 'destination_port', 'shipping_method',
            'incoterms', 'total_weight', 'total_volume', 'total_value',
            'currency', 'insurance_required', 'special_instructions'
        ]

    def clean_shipment_date(self):
        shipment_date = self.cleaned_data.get('shipment_date')
        if shipment_date and shipment_date > date.today():
            raise ValidationError("Shipment date cannot be in the future.")
        return shipment_date

    def clean_expected_delivery_date(self):
        expected_delivery_date = self.cleaned_data.get('expected_delivery_date')
        shipment_date = self.cleaned_data.get('shipment_date')

        if expected_delivery_date and shipment_date:
            if expected_delivery_date <= shipment_date:
                raise ValidationError("Expected delivery date must be after shipment date.")

        return expected_delivery_date

    def clean_total_weight(self):
        total_weight = self.cleaned_data.get('total_weight')
        if total_weight and total_weight <= 0:
            raise ValidationError("Total weight must be greater than 0.")
        return total_weight

    def clean_total_value(self):
        total_value = self.cleaned_data.get('total_value')
        if total_value and total_value <= 0:
            raise ValidationError("Total value must be greater than 0.")
        return total_value


class ShipmentStatusUpdateForm(forms.ModelForm):
    """Form for updating shipment status"""

    status = forms.ChoiceField(
        choices=Shipment.STATUS_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    tracking_number = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Tracking Number'
        })
    )

    carrier = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Carrier/Shipping Line'
        })
    )

    actual_delivery_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )

    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Status update notes'
        })
    )

    class Meta:
        model = Shipment
        fields = ['status', 'tracking_number', 'carrier', 'actual_delivery_date', 'notes']

    def clean_actual_delivery_date(self):
        actual_delivery_date = self.cleaned_data.get('actual_delivery_date')
        status = self.cleaned_data.get('status')

        if status == 'delivered' and not actual_delivery_date:
            raise ValidationError("Actual delivery date is required when status is 'Delivered'.")

        if actual_delivery_date and actual_delivery_date > date.today():
            raise ValidationError("Actual delivery date cannot be in the future.")

        return actual_delivery_date


class ShipmentItemForm(forms.ModelForm):
    """Form for adding items to shipments"""

    product_name = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Product Name'
        })
    )

    description = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 2,
            'placeholder': 'Product Description'
        })
    )

    hs_code = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'HS Code'
        })
    )

    quantity = forms.IntegerField(
        min_value=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Quantity'
        })
    )

    unit_price = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Unit Price',
            'step': '0.01'
        })
    )

    weight_per_unit = forms.DecimalField(
        max_digits=8,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Weight per Unit (kg)',
            'step': '0.01'
        })
    )

    country_of_origin = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Country of Origin'
        })
    )

    class Meta:
        model = ShipmentItem
        fields = [
            'product_name', 'description', 'hs_code', 'quantity',
            'unit_price', 'weight_per_unit', 'country_of_origin'
        ]

    def clean_quantity(self):
        quantity = self.cleaned_data.get('quantity')
        if quantity and quantity <= 0:
            raise ValidationError("Quantity must be greater than 0.")
        return quantity

    def clean_unit_price(self):
        unit_price = self.cleaned_data.get('unit_price')
        if unit_price and unit_price <= 0:
            raise ValidationError("Unit price must be greater than 0.")
        return unit_price

    def clean_weight_per_unit(self):
        weight_per_unit = self.cleaned_data.get('weight_per_unit')
        if weight_per_unit and weight_per_unit <= 0:
            raise ValidationError("Weight per unit must be greater than 0.")
        return weight_per_unit


class ShipmentDocumentForm(forms.ModelForm):
    """Form for uploading shipment documents"""

    document_type = forms.ChoiceField(
        choices=ShipmentDocument.DOCUMENT_TYPE_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    document_file = forms.FileField(
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.pdf,.doc,.docx,.jpg,.jpeg,.png'
        })
    )

    description = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Document Description'
        })
    )

    class Meta:
        model = ShipmentDocument
        fields = ['document_type', 'document_file', 'description']

    def clean_document_file(self):
        document_file = self.cleaned_data.get('document_file')

        if document_file:
            # Check file size (max 10MB)
            if document_file.size > 10 * 1024 * 1024:
                raise ValidationError("File size cannot exceed 10MB.")

            # Check file extension
            allowed_extensions = ['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png']
            file_extension = document_file.name.lower().split('.')[-1]
            if f'.{file_extension}' not in allowed_extensions:
                raise ValidationError("Only PDF, DOC, DOCX, JPG, JPEG, and PNG files are allowed.")

        return document_file


class ShipmentSearchForm(forms.Form):
    """Form for searching and filtering shipments"""

    search_query = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by shipment number, customer, or tracking number'
        })
    )

    status = forms.ChoiceField(
        required=False,
        choices=[('', 'All Statuses')] + Shipment.STATUS_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    shipping_method = forms.ChoiceField(
        required=False,
        choices=[('', 'All Methods')] + Shipment.SHIPPING_METHOD_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    customer = forms.ModelChoiceField(
        queryset=Customer.objects.all(),
        required=False,
        empty_label="All Customers",
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date',
            'placeholder': 'From Date'
        })
    )

    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date',
            'placeholder': 'To Date'
        })
    )

    def clean(self):
        cleaned_data = super().clean()
        date_from = cleaned_data.get('date_from')
        date_to = cleaned_data.get('date_to')

        if date_from and date_to and date_from > date_to:
            raise ValidationError("From date cannot be later than to date.")

        return cleaned_data
