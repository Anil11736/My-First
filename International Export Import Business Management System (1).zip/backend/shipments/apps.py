from django.apps import AppConfig


class ShipmentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shipments'
    verbose_name = 'Shipments Management'

    def ready(self):
        """
        Import signal handlers when the app is ready.
        This ensures that signals are properly connected.
        """
        try:
            import shipments.signals
        except ImportError:
            pass
