default_app_config = 'shipments.apps.ShipmentsConfig'
