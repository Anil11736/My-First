from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.cache import never_cache
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils.decorators import method_decorator
from django.views import View
from django.contrib.auth.password_validation import validate_password
from django.core.validators import validate_email
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
import json
import re
from .models import UserProfile


@csrf_protect
@never_cache
def login_view(request):
    """Handle user login"""
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        if not username or not password:
            messages.error(request, 'Please provide both username and password.')
            return render(request, 'accounts/login.html')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)
                next_url = request.GET.get('next', 'dashboard')
                messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
                return redirect(next_url)
            else:
                messages.error(request, 'Your account has been deactivated. Please contact support.')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'accounts/login.html')


@csrf_protect
def register_view(request):
    """Handle user registration"""
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        password1 = request.POST.get('password1', '')
        password2 = request.POST.get('password2', '')
        company_name = request.POST.get('company_name', '').strip()
        phone_number = request.POST.get('phone_number', '').strip()

        # Validation
        errors = []

        if not username:
            errors.append('Username is required.')
        elif len(username) < 3:
            errors.append('Username must be at least 3 characters long.')
        elif User.objects.filter(username=username).exists():
            errors.append('Username already exists.')

        if not email:
            errors.append('Email is required.')
        else:
            try:
                validate_email(email)
                if User.objects.filter(email=email).exists():
                    errors.append('Email already registered.')
            except ValidationError:
                errors.append('Please enter a valid email address.')

        if not first_name:
            errors.append('First name is required.')

        if not last_name:
            errors.append('Last name is required.')

        if not password1:
            errors.append('Password is required.')
        elif password1 != password2:
            errors.append('Passwords do not match.')
        else:
            try:
                validate_password(password1)
            except ValidationError as e:
                errors.extend(e.messages)

        if phone_number and not re.match(r'^\+?[\d\s\-\(\)]{10,}$', phone_number):
            errors.append('Please enter a valid phone number.')

        if errors:
            for error in errors:
                messages.error(request, error)
            return render(request, 'accounts/register.html', {
                'form_data': request.POST
            })

        try:
            with transaction.atomic():
                # Create user
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password1,
                    first_name=first_name,
                    last_name=last_name
                )

                # Create user profile
                UserProfile.objects.create(
                    user=user,
                    company_name=company_name,
                    phone_number=phone_number
                )

                messages.success(request, 'Registration successful! Please log in.')
                return redirect('login')

        except Exception as e:
            messages.error(request, 'Registration failed. Please try again.')
            return render(request, 'accounts/register.html', {
                'form_data': request.POST
            })

    return render(request, 'accounts/register.html')


@login_required
def logout_view(request):
    """Handle user logout"""
    username = request.user.username
    logout(request)
    messages.success(request, f'Goodbye {username}! You have been logged out successfully.')
    return redirect('login')


@login_required
def profile_view(request):
    """Display and update user profile"""
    try:
        profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)

    if request.method == 'POST':
        # Update user information
        request.user.first_name = request.POST.get('first_name', '').strip()
        request.user.last_name = request.POST.get('last_name', '').strip()
        request.user.email = request.POST.get('email', '').strip()

        # Update profile information
        profile.company_name = request.POST.get('company_name', '').strip()
        profile.phone_number = request.POST.get('phone_number', '').strip()
        profile.address = request.POST.get('address', '').strip()
        profile.city = request.POST.get('city', '').strip()
        profile.country = request.POST.get('country', '').strip()
        profile.postal_code = request.POST.get('postal_code', '').strip()

        # Validation
        errors = []

        if not request.user.first_name:
            errors.append('First name is required.')

        if not request.user.last_name:
            errors.append('Last name is required.')

        if not request.user.email:
            errors.append('Email is required.')
        else:
            try:
                validate_email(request.user.email)
                # Check if email is taken by another user
                existing_user = User.objects.filter(email=request.user.email).exclude(id=request.user.id)
                if existing_user.exists():
                    errors.append('Email already registered by another user.')
            except ValidationError:
                errors.append('Please enter a valid email address.')

        if profile.phone_number and not re.match(r'^\+?[\d\s\-\(\)]{10,}$', profile.phone_number):
            errors.append('Please enter a valid phone number.')

        if errors:
            for error in errors:
                messages.error(request, error)
        else:
            try:
                with transaction.atomic():
                    request.user.save()
                    profile.save()
                    messages.success(request, 'Profile updated successfully!')
                    return redirect('profile')
            except Exception as e:
                messages.error(request, 'Failed to update profile. Please try again.')

    context = {
        'user': request.user,
        'profile': profile,
    }
    return render(request, 'accounts/profile.html', context)


@login_required
@csrf_protect
def change_password_view(request):
    """Handle password change"""
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Password changed successfully!')
            return redirect('profile')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, error)
    else:
        form = PasswordChangeForm(request.user)

    return render(request, 'accounts/change_password.html', {'form': form})


@login_required
@require_http_methods(["GET"])
def dashboard_view(request):
    """Main dashboard view"""
    try:
        profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)

    # Get recent activity data
    from shipments.models import Shipment
    from customers.models import Customer
    from financials.models import Invoice

    recent_shipments = Shipment.objects.filter(
        created_by=request.user
    ).order_by('-created_at')[:5]

    recent_customers = Customer.objects.filter(
        created_by=request.user
    ).order_by('-created_at')[:5]

    recent_invoices = Invoice.objects.filter(
        created_by=request.user
    ).order_by('-created_at')[:5]

    # Statistics
    total_shipments = Shipment.objects.filter(created_by=request.user).count()
    total_customers = Customer.objects.filter(created_by=request.user).count()
    pending_shipments = Shipment.objects.filter(
        created_by=request.user,
        status__in=['pending', 'in_transit']
    ).count()

    context = {
        'profile': profile,
        'recent_shipments': recent_shipments,
        'recent_customers': recent_customers,
        'recent_invoices': recent_invoices,
        'total_shipments': total_shipments,
        'total_customers': total_customers,
        'pending_shipments': pending_shipments,
    }

    return render(request, 'accounts/dashboard.html', context)


@login_required
@require_http_methods(["POST"])
def upload_avatar_view(request):
    """Handle avatar upload via AJAX"""
    if 'avatar' not in request.FILES:
        return JsonResponse({'success': False, 'error': 'No file uploaded'})

    avatar_file = request.FILES['avatar']

    # Validate file type
    allowed_types = ['image/jpeg', 'image/png', 'image/gif']
    if avatar_file.content_type not in allowed_types:
        return JsonResponse({
            'success': False,
            'error': 'Invalid file type. Please upload a JPEG, PNG, or GIF image.'
        })

    # Validate file size (max 5MB)
    if avatar_file.size > 5 * 1024 * 1024:
        return JsonResponse({
            'success': False,
            'error': 'File too large. Maximum size is 5MB.'
        })

    try:
        profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)

    try:
        # Delete old avatar if exists
        if profile.avatar:
            profile.avatar.delete(save=False)

        profile.avatar = avatar_file
        profile.save()

        return JsonResponse({
            'success': True,
            'avatar_url': profile.avatar.url if profile.avatar else None
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': 'Failed to upload avatar. Please try again.'
        })


@login_required
@require_http_methods(["DELETE"])
def delete_avatar_view(request):
    """Delete user avatar via AJAX"""
    try:
        profile = request.user.userprofile
        if profile.avatar:
            profile.avatar.delete(save=True)
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'error': 'No avatar to delete'})
    except UserProfile.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Profile not found'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': 'Failed to delete avatar'})


@login_required
def account_settings_view(request):
    """Account settings and preferences"""
    try:
        profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)

    if request.method == 'POST':
        # Update notification preferences
        profile.email_notifications = request.POST.get('email_notifications') == 'on'
        profile.sms_notifications = request.POST.get('sms_notifications') == 'on'

        # Update timezone
        timezone = request.POST.get('timezone', '').strip()
        if timezone:
            profile.timezone = timezone

        try:
            profile.save()
            messages.success(request, 'Settings updated successfully!')
            return redirect('account_settings')
        except Exception as e:
            messages.error(request, 'Failed to update settings. Please try again.')

    # Available timezones (subset)
    timezones = [
        ('UTC', 'UTC'),
        ('US/Eastern', 'Eastern Time'),
        ('US/Central', 'Central Time'),
        ('US/Mountain', 'Mountain Time'),
        ('US/Pacific', 'Pacific Time'),
        ('Europe/London', 'London'),
        ('Europe/Paris', 'Paris'),
        ('Asia/Tokyo', 'Tokyo'),
        ('Asia/Shanghai', 'Shanghai'),
        ('Asia/Kolkata', 'India'),
    ]

    context = {
        'profile': profile,
        'timezones': timezones,
    }

    return render(request, 'accounts/settings.html', context)
