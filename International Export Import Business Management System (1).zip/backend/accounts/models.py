from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone


class User(AbstractUser):
    """Extended User model with company and role information"""

    ROLE_CHOICES = [
        ('admin', 'Administrator'),
        ('manager', 'Manager'),
        ('operator', 'Operator'),
        ('viewer', 'Viewer'),
    ]

    # Company Information
    company_name = models.CharField(max_length=255, blank=True, null=True)
    company_registration = models.CharField(max_length=100, blank=True, null=True)
    tax_id = models.CharField(max_length=50, blank=True, null=True)

    # Contact Information
    phone_regex = RegexValidator(
        regex=r'^\+?1?\d{9,15}$',
        message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."
    )
    phone_number = models.CharField(validators=[phone_regex], max_length=17, blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)

    # Role and Permissions
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='viewer')
    department = models.CharField(max_length=100, blank=True)

    # Business Information
    business_type = models.CharField(max_length=100, blank=True)
    license_number = models.CharField(max_length=100, blank=True)
    license_expiry = models.DateField(blank=True, null=True)

    # Profile Information
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    bio = models.TextField(max_length=500, blank=True)
    website = models.URLField(blank=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_login_ip = models.GenericIPAddressField(blank=True, null=True)

    # Status
    is_verified = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)

    class Meta:
        db_table = 'accounts_user'
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.username} - {self.get_full_name()}"

    def get_full_name(self):
        """Return the first_name plus the last_name, with a space in between."""
        full_name = f"{self.first_name} {self.last_name}".strip()
        return full_name or self.username

    def get_short_name(self):
        """Return the short name for the user."""
        return self.first_name or self.username

    @property
    def is_admin(self):
        """Check if user is an administrator"""
        return self.role == 'admin' or self.is_superuser

    @property
    def is_manager(self):
        """Check if user is a manager"""
        return self.role in ['admin', 'manager'] or self.is_superuser

    @property
    def can_manage_shipments(self):
        """Check if user can manage shipments"""
        return self.role in ['admin', 'manager', 'operator'] or self.is_superuser

    @property
    def can_view_financials(self):
        """Check if user can view financial data"""
        return self.role in ['admin', 'manager'] or self.is_superuser

    @property
    def license_is_expired(self):
        """Check if business license is expired"""
        if self.license_expiry:
            return self.license_expiry < timezone.now().date()
        return False


class UserProfile(models.Model):
    """Additional profile information for users"""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')

    # Emergency Contact
    emergency_contact_name = models.CharField(max_length=255, blank=True)
    emergency_contact_phone = models.CharField(max_length=17, blank=True)
    emergency_contact_relationship = models.CharField(max_length=100, blank=True)

    # Preferences
    timezone = models.CharField(max_length=50, default='UTC')
    language = models.CharField(max_length=10, default='en')
    currency_preference = models.CharField(max_length=3, default='USD')

    # Notifications
    email_notifications = models.BooleanField(default=True)
    sms_notifications = models.BooleanField(default=False)
    shipment_alerts = models.BooleanField(default=True)
    financial_alerts = models.BooleanField(default=True)

    # Two-Factor Authentication
    two_factor_enabled = models.BooleanField(default=False)
    backup_codes = models.JSONField(default=list, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'accounts_userprofile'
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

    def __str__(self):
        return f"Profile for {self.user.username}"


class Permission(models.Model):
    """Custom permissions for the application"""

    PERMISSION_TYPES = [
        ('view', 'View'),
        ('add', 'Add'),
        ('change', 'Change'),
        ('delete', 'Delete'),
        ('export', 'Export'),
        ('import', 'Import'),
        ('approve', 'Approve'),
    ]

    MODULE_CHOICES = [
        ('customers', 'Customers'),
        ('shipments', 'Shipments'),
        ('financials', 'Financials'),
        ('reports', 'Reports'),
        ('settings', 'Settings'),
        ('users', 'Users'),
    ]

    name = models.CharField(max_length=100)
    codename = models.CharField(max_length=100, unique=True)
    permission_type = models.CharField(max_length=20, choices=PERMISSION_TYPES)
    module = models.CharField(max_length=50, choices=MODULE_CHOICES)
    description = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'accounts_permission'
        verbose_name = 'Permission'
        verbose_name_plural = 'Permissions'
        unique_together = ['permission_type', 'module']
        ordering = ['module', 'permission_type']

    def __str__(self):
        return f"{self.name} ({self.codename})"


class Role(models.Model):
    """Role model with associated permissions"""

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    permissions = models.ManyToManyField(Permission, blank=True)
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'accounts_role'
        verbose_name = 'Role'
        verbose_name_plural = 'Roles'
        ordering = ['name']

    def __str__(self):
        return self.name

    def has_permission(self, permission_codename):
        """Check if role has a specific permission"""
        return self.permissions.filter(codename=permission_codename).exists()


class UserRole(models.Model):
    """Many-to-many relationship between users and roles"""

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='assigned_roles')
    assigned_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'accounts_userrole'
        verbose_name = 'User Role'
        verbose_name_plural = 'User Roles'
        unique_together = ['user', 'role']

    def __str__(self):
        return f"{self.user.username} - {self.role.name}"


class LoginHistory(models.Model):
    """Track user login history"""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='login_history')
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField()
    login_time = models.DateTimeField(auto_now_add=True)
    logout_time = models.DateTimeField(null=True, blank=True)
    session_duration = models.DurationField(null=True, blank=True)
    is_successful = models.BooleanField(default=True)
    failure_reason = models.CharField(max_length=255, blank=True)

    class Meta:
        db_table = 'accounts_loginhistory'
        verbose_name = 'Login History'
        verbose_name_plural = 'Login Histories'
        ordering = ['-login_time']

    def __str__(self):
        return f"{self.user.username} - {self.login_time}"

    def calculate_session_duration(self):
        """Calculate session duration if logout time is available"""
        if self.logout_time:
            self.session_duration = self.logout_time - self.login_time
            self.save()
