from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)
from . import views

app_name = 'accounts'

# Create a router for ViewSets
router = DefaultRouter()
router.register(r'users', views.UserViewSet, basename='user')
router.register(r'profiles', views.UserProfileViewSet, basename='profile')

urlpatterns = [
    # Authentication endpoints
    path('auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/verify/', TokenVerifyView.as_view(), name='token_verify'),
    path('auth/logout/', views.LogoutView.as_view(), name='logout'),

    # Registration and password management
    path('auth/register/', views.RegisterView.as_view(), name='register'),
    path('auth/password/change/', views.ChangePasswordView.as_view(), name='change_password'),
    path('auth/password/reset/', views.PasswordResetRequestView.as_view(), name='password_reset'),
    path('auth/password/reset/confirm/<uidb64>/<token>/', views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),

    # Email verification
    path('auth/email/verify/', views.EmailVerificationView.as_view(), name='email_verify'),
    path('auth/email/verify/confirm/<uidb64>/<token>/', views.EmailVerificationConfirmView.as_view(), name='email_verify_confirm'),
    path('auth/email/resend/', views.ResendEmailVerificationView.as_view(), name='resend_email_verification'),

    # User management
    path('me/', views.CurrentUserView.as_view(), name='current_user'),
    path('me/profile/', views.CurrentUserProfileView.as_view(), name='current_user_profile'),
    path('me/avatar/', views.AvatarUploadView.as_view(), name='avatar_upload'),
    path('me/preferences/', views.UserPreferencesView.as_view(), name='user_preferences'),

    # Account management
    path('deactivate/', views.DeactivateAccountView.as_view(), name='deactivate_account'),
    path('delete/', views.DeleteAccountView.as_view(), name='delete_account'),

    # Two-factor authentication
    path('2fa/enable/', views.EnableTwoFactorView.as_view(), name='enable_2fa'),
    path('2fa/disable/', views.DisableTwoFactorView.as_view(), name='disable_2fa'),
    path('2fa/verify/', views.VerifyTwoFactorView.as_view(), name='verify_2fa'),
    path('2fa/backup-codes/', views.BackupCodesView.as_view(), name='backup_codes'),

    # Activity and security
    path('activity/', views.UserActivityView.as_view(), name='user_activity'),
    path('sessions/', views.ActiveSessionsView.as_view(), name='active_sessions'),
    path('sessions/<int:session_id>/revoke/', views.RevokeSessionView.as_view(), name='revoke_session'),

    # Admin endpoints (for staff users)
    path('admin/users/', views.AdminUserListView.as_view(), name='admin_user_list'),
    path('admin/users/<int:user_id>/', views.AdminUserDetailView.as_view(), name='admin_user_detail'),
    path('admin/users/<int:user_id>/activate/', views.AdminActivateUserView.as_view(), name='admin_activate_user'),
    path('admin/users/<int:user_id>/deactivate/', views.AdminDeactivateUserView.as_view(), name='admin_deactivate_user'),
    path('admin/users/<int:user_id>/reset-password/', views.AdminResetPasswordView.as_view(), name='admin_reset_password'),

    # Include router URLs
    path('', include(router.urls)),
]
