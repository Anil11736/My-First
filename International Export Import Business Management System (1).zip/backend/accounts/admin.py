from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe

# Unregister the default User admin
admin.site.unregister(User)

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Enhanced User admin with export/import business context"""

    list_display = (
        'username',
        'email',
        'first_name',
        'last_name',
        'is_staff',
        'is_active',
        'date_joined',
        'last_login',
        'user_role_display'
    )

    list_filter = (
        'is_staff',
        'is_superuser',
        'is_active',
        'date_joined',
        'last_login',
        'groups'
    )

    search_fields = (
        'username',
        'first_name',
        'last_name',
        'email'
    )

    ordering = ('-date_joined',)

    readonly_fields = (
        'date_joined',
        'last_login',
        'user_statistics'
    )

    fieldsets = (
        (None, {
            'fields': ('username', 'password')
        }),
        ('Personal info', {
            'fields': ('first_name', 'last_name', 'email')
        }),
        ('Permissions', {
            'fields': (
                'is_active',
                'is_staff',
                'is_superuser',
                'groups',
                'user_permissions'
            ),
        }),
        ('Important dates', {
            'fields': ('last_login', 'date_joined')
        }),
        ('Statistics', {
            'fields': ('user_statistics',),
            'classes': ('collapse',)
        }),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'username',
                'email',
                'first_name',
                'last_name',
                'password1',
                'password2',
                'is_staff',
                'is_active',
                'groups'
            ),
        }),
    )

    def user_role_display(self, obj):
        """Display user roles based on groups"""
        if obj.is_superuser:
            return format_html(
                '<span style="color: red; font-weight: bold;">Super Admin</span>'
            )
        elif obj.is_staff:
            return format_html(
                '<span style="color: blue; font-weight: bold;">Staff</span>'
            )

        groups = obj.groups.all()
        if groups:
            group_names = [group.name for group in groups]
            return format_html(
                '<span style="color: green;">{}</span>',
                ', '.join(group_names)
            )

        return format_html(
            '<span style="color: gray;">Regular User</span>'
        )

    user_role_display.short_description = 'Role'

    def user_statistics(self, obj):
        """Display user activity statistics"""
        try:
            # Import models here to avoid circular imports
            from customers.models import Customer
            from shipments.models import Shipment
            from financials.models import Invoice
            from documents.models import Document

            # Count related objects
            customers_count = Customer.objects.filter(created_by=obj).count()
            shipments_count = Shipment.objects.filter(created_by=obj).count()
            invoices_count = Invoice.objects.filter(created_by=obj).count()
            documents_count = Document.objects.filter(uploaded_by=obj).count()

            stats_html = f"""
            <div style="background: #f8f9fa; padding: 10px; border-radius: 5px;">
                <h4 style="margin-top: 0;">User Activity Summary</h4>
                <ul style="margin: 0; padding-left: 20px;">
                    <li><strong>Customers Created:</strong> {customers_count}</li>
                    <li><strong>Shipments Managed:</strong> {shipments_count}</li>
                    <li><strong>Invoices Generated:</strong> {invoices_count}</li>
                    <li><strong>Documents Uploaded:</strong> {documents_count}</li>
                </ul>
            </div>
            """

            return mark_safe(stats_html)

        except Exception as e:
            return f"Statistics unavailable: {str(e)}"

    user_statistics.short_description = 'Activity Statistics'

    def get_queryset(self, request):
        """Optimize queryset with related data"""
        return super().get_queryset(request).select_related().prefetch_related('groups')

    actions = ['activate_users', 'deactivate_users', 'reset_passwords']

    def activate_users(self, request, queryset):
        """Bulk activate users"""
        updated = queryset.update(is_active=True)
        self.message_user(
            request,
            f'{updated} user(s) were successfully activated.'
        )
    activate_users.short_description = "Activate selected users"

    def deactivate_users(self, request, queryset):
        """Bulk deactivate users"""
        updated = queryset.update(is_active=False)
        self.message_user(
            request,
            f'{updated} user(s) were successfully deactivated.'
        )
    deactivate_users.short_description = "Deactivate selected users"

    def reset_passwords(self, request, queryset):
        """Send password reset emails to selected users"""
        from django.contrib.auth.forms import PasswordResetForm
        from django.contrib.auth.tokens import default_token_generator
        from django.contrib.sites.shortcuts import get_current_site
        from django.core.mail import send_mail
        from django.template.loader import render_to_string
        from django.utils.encoding import force_bytes
        from django.utils.http import urlsafe_base64_encode

        count = 0
        for user in queryset:
            if user.email:
                # Generate password reset token
                token = default_token_generator.make_token(user)
                uid = urlsafe_base64_encode(force_bytes(user.pk))

                # You would typically send an email here
                # For now, just count the users
                count += 1

        self.message_user(
            request,
            f'Password reset initiated for {count} user(s).'
        )
    reset_passwords.short_description = "Send password reset to selected users"

# Customize admin site headers
admin.site.site_header = "Export/Import Business Management"
admin.site.site_title = "Export/Import Admin"
admin.site.index_title = "Welcome to Export/Import Business Administration"
