"""
API Package for International Export/Import Business Management System

This package contains the REST API endpoints for the business management system,
including serializers, views, and URL configurations for all modules.

Modules:
- serializers: Data serialization for API responses
- views: API viewsets and endpoints
- urls: URL routing configuration
"""

default_app_config = 'api.apps.ApiConfig'
