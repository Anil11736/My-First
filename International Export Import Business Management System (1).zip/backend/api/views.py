from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q, Sum, Count
from django.utils import timezone
from datetime import datetime, timedelta

from customers.models import Customer
from shipments.models import Shipment, ShipmentItem
from inventory.models import Product, InventoryTransaction
from financials.models import Invoice, Payment, ExpenseRecord
from .serializers import (
    CustomerSerializer, ShipmentSerializer, ShipmentItemSerializer,
    ProductSerializer, InventoryTransactionSerializer,
    InvoiceSerializer, PaymentSerializer, ExpenseRecordSerializer
)


class StandardResultsSetPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100


class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['customer_type', 'country', 'status']
    search_fields = ['name', 'email', 'contact_person', 'phone']
    ordering_fields = ['name', 'created_at', 'last_order_date']
    ordering = ['-created_at']

    @action(detail=True, methods=['get'])
    def shipments(self, request, pk=None):
        customer = self.get_object()
        shipments = Shipment.objects.filter(customer=customer).order_by('-created_at')
        serializer = ShipmentSerializer(shipments, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def invoices(self, request, pk=None):
        customer = self.get_object()
        invoices = Invoice.objects.filter(customer=customer).order_by('-created_at')
        serializer = InvoiceSerializer(invoices, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def statistics(self, request, pk=None):
        customer = self.get_object()

        # Calculate customer statistics
        total_shipments = Shipment.objects.filter(customer=customer).count()
        total_invoices = Invoice.objects.filter(customer=customer).count()
        total_revenue = Invoice.objects.filter(
            customer=customer,
            status='paid'
        ).aggregate(total=Sum('total_amount'))['total'] or 0

        pending_payments = Invoice.objects.filter(
            customer=customer,
            status__in=['pending', 'overdue']
        ).aggregate(total=Sum('total_amount'))['total'] or 0

        last_order = Shipment.objects.filter(
            customer=customer
        ).order_by('-created_at').first()

        stats = {
            'total_shipments': total_shipments,
            'total_invoices': total_invoices,
            'total_revenue': float(total_revenue),
            'pending_payments': float(pending_payments),
            'last_order_date': last_order.created_at if last_order else None,
            'customer_since': customer.created_at
        }

        return Response(stats)


class ShipmentViewSet(viewsets.ModelViewSet):
    queryset = Shipment.objects.all()
    serializer_class = ShipmentSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'shipment_type', 'origin_country', 'destination_country']
    search_fields = ['tracking_number', 'customer__name', 'origin_port', 'destination_port']
    ordering_fields = ['created_at', 'departure_date', 'arrival_date', 'total_value']
    ordering = ['-created_at']

    def get_queryset(self):
        queryset = Shipment.objects.select_related('customer').prefetch_related('items')

        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        return queryset

    @action(detail=True, methods=['get'])
    def items(self, request, pk=None):
        shipment = self.get_object()
        items = ShipmentItem.objects.filter(shipment=shipment)
        serializer = ShipmentItemSerializer(items, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        shipment = self.get_object()
        new_status = request.data.get('status')

        if new_status not in dict(Shipment.STATUS_CHOICES):
            return Response(
                {'error': 'Invalid status'},
                status=status.HTTP_400_BAD_REQUEST
            )

        shipment.status = new_status
        shipment.save()

        # Update timestamps based on status
        if new_status == 'in_transit':
            shipment.departure_date = timezone.now()
        elif new_status == 'delivered':
            shipment.arrival_date = timezone.now()

        shipment.save()

        serializer = self.get_serializer(shipment)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def dashboard_stats(self, request):
        # Get shipment statistics for dashboard
        total_shipments = Shipment.objects.count()

        # Shipments by status
        status_counts = {}
        for status_code, status_name in Shipment.STATUS_CHOICES:
            count = Shipment.objects.filter(status=status_code).count()
            status_counts[status_code] = {
                'name': status_name,
                'count': count
            }

        # Recent shipments (last 30 days)
        thirty_days_ago = timezone.now() - timedelta(days=30)
        recent_shipments = Shipment.objects.filter(
            created_at__gte=thirty_days_ago
        ).count()

        # Total value of active shipments
        active_value = Shipment.objects.filter(
            status__in=['pending', 'in_transit']
        ).aggregate(total=Sum('total_value'))['total'] or 0

        stats = {
            'total_shipments': total_shipments,
            'status_breakdown': status_counts,
            'recent_shipments': recent_shipments,
            'active_shipments_value': float(active_value)
        }

        return Response(stats)


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'status', 'supplier']
    search_fields = ['name', 'sku', 'description', 'supplier__name']
    ordering_fields = ['name', 'unit_price', 'quantity_in_stock', 'created_at']
    ordering = ['name']

    @action(detail=True, methods=['get'])
    def transactions(self, request, pk=None):
        product = self.get_object()
        transactions = InventoryTransaction.objects.filter(
            product=product
        ).order_by('-created_at')
        serializer = InventoryTransactionSerializer(transactions, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def adjust_stock(self, request, pk=None):
        product = self.get_object()
        quantity = request.data.get('quantity')
        transaction_type = request.data.get('transaction_type', 'adjustment')
        notes = request.data.get('notes', '')

        if not quantity:
            return Response(
                {'error': 'Quantity is required'},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            quantity = int(quantity)
        except ValueError:
            return Response(
                {'error': 'Invalid quantity'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create inventory transaction
        transaction = InventoryTransaction.objects.create(
            product=product,
            transaction_type=transaction_type,
            quantity=quantity,
            unit_price=product.unit_price,
            total_value=quantity * product.unit_price,
            notes=notes,
            created_by=request.user
        )

        # Update product stock
        if transaction_type in ['purchase', 'adjustment'] and quantity > 0:
            product.quantity_in_stock += quantity
        elif transaction_type in ['sale', 'adjustment'] and quantity < 0:
            product.quantity_in_stock += quantity  # quantity is negative

        product.save()

        serializer = InventoryTransactionSerializer(transaction)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'])
    def low_stock(self, request):
        # Get products with low stock
        low_stock_products = Product.objects.filter(
            quantity_in_stock__lte=models.F('minimum_stock_level')
        )
        serializer = self.get_serializer(low_stock_products, many=True)
        return Response(serializer.data)


class InventoryTransactionViewSet(viewsets.ModelViewSet):
    queryset = InventoryTransaction.objects.all()
    serializer_class = InventoryTransactionSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['transaction_type', 'product', 'created_by']
    search_fields = ['product__name', 'product__sku', 'notes']
    ordering_fields = ['created_at', 'quantity', 'total_value']
    ordering = ['-created_at']

    def get_queryset(self):
        queryset = InventoryTransaction.objects.select_related(
            'product', 'created_by'
        )

        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        return queryset


class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all()
    serializer_class = InvoiceSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'customer', 'currency']
    search_fields = ['invoice_number', 'customer__name', 'description']
    ordering_fields = ['created_at', 'due_date', 'total_amount']
    ordering = ['-created_at']

    @action(detail=True, methods=['post'])
    def mark_paid(self, request, pk=None):
        invoice = self.get_object()

        if invoice.status == 'paid':
            return Response(
                {'error': 'Invoice is already paid'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create payment record
        Payment.objects.create(
            invoice=invoice,
            amount=invoice.total_amount,
            payment_date=timezone.now(),
            payment_method=request.data.get('payment_method', 'bank_transfer'),
            reference_number=request.data.get('reference_number', ''),
            notes=request.data.get('notes', ''),
            created_by=request.user
        )

        invoice.status = 'paid'
        invoice.save()

        serializer = self.get_serializer(invoice)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def overdue(self, request):
        # Get overdue invoices
        today = timezone.now().date()
        overdue_invoices = Invoice.objects.filter(
            due_date__lt=today,
            status__in=['pending', 'sent']
        )
        serializer = self.get_serializer(overdue_invoices, many=True)
        return Response(serializer.data)


class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['payment_method', 'invoice__customer']
    search_fields = ['reference_number', 'invoice__invoice_number', 'notes']
    ordering_fields = ['payment_date', 'amount']
    ordering = ['-payment_date']

    def get_queryset(self):
        queryset = Payment.objects.select_related('invoice', 'invoice__customer')

        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if start_date:
            queryset = queryset.filter(payment_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(payment_date__lte=end_date)

        return queryset


class ExpenseRecordViewSet(viewsets.ModelViewSet):
    queryset = ExpenseRecord.objects.all()
    serializer_class = ExpenseRecordSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'currency', 'created_by']
    search_fields = ['description', 'vendor', 'reference_number']
    ordering_fields = ['expense_date', 'amount', 'created_at']
    ordering = ['-expense_date']

    def get_queryset(self):
        queryset = ExpenseRecord.objects.select_related('created_by')

        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if start_date:
            queryset = queryset.filter(expense_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(expense_date__lte=end_date)

        return queryset

    @action(detail=False, methods=['get'])
    def summary(self, request):
        # Get expense summary by category
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = ExpenseRecord.objects.all()

        if start_date:
            queryset = queryset.filter(expense_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(expense_date__lte=end_date)

        # Group by category
        category_summary = queryset.values('category').annotate(
            total_amount=Sum('amount'),
            count=Count('id')
        ).order_by('-total_amount')

        # Total expenses
        total_expenses = queryset.aggregate(
            total=Sum('amount')
        )['total'] or 0

        summary = {
            'total_expenses': float(total_expenses),
            'category_breakdown': list(category_summary),
            'period': {
                'start_date': start_date,
                'end_date': end_date
            }
        }

        return Response(summary)
