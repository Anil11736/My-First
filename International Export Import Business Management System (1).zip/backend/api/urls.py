from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)

# Import API viewsets
from shipments.api.views import ShipmentViewSet, ShipmentItemViewSet
from inventory.api.views import ProductViewSet, WarehouseViewSet, StockMovementViewSet
from documents.api.views import DocumentViewSet, DocumentTemplateViewSet
from financials.api.views import InvoiceViewSet, PaymentViewSet, ExchangeRateViewSet
from customers.api.views import CustomerViewSet, SupplierViewSet
from compliance.api.views import ComplianceCheckViewSet, RegulationViewSet

# Create router and register viewsets
router = DefaultRouter()

# Shipments endpoints
router.register(r'shipments', ShipmentViewSet, basename='shipment')
router.register(r'shipment-items', ShipmentItemViewSet, basename='shipmentitem')

# Inventory endpoints
router.register(r'products', ProductViewSet, basename='product')
router.register(r'warehouses', WarehouseViewSet, basename='warehouse')
router.register(r'stock-movements', StockMovementViewSet, basename='stockmovement')

# Documents endpoints
router.register(r'documents', DocumentViewSet, basename='document')
router.register(r'document-templates', DocumentTemplateViewSet, basename='documenttemplate')

# Financials endpoints
router.register(r'invoices', InvoiceViewSet, basename='invoice')
router.register(r'payments', PaymentViewSet, basename='payment')
router.register(r'exchange-rates', ExchangeRateViewSet, basename='exchangerate')

# Customers endpoints
router.register(r'customers', CustomerViewSet, basename='customer')
router.register(r'suppliers', SupplierViewSet, basename='supplier')

# Compliance endpoints
router.register(r'compliance-checks', ComplianceCheckViewSet, basename='compliancecheck')
router.register(r'regulations', RegulationViewSet, basename='regulation')

app_name = 'api'

urlpatterns = [
    # Authentication endpoints
    path('auth/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/token/verify/', TokenVerifyView.as_view(), name='token_verify'),

    # API endpoints
    path('v1/', include(router.urls)),

    # Custom API endpoints
    path('v1/dashboard/stats/', include('dashboard.api.urls')),
    path('v1/reports/', include('reports.api.urls')),
    path('v1/notifications/', include('notifications.api.urls')),
]
