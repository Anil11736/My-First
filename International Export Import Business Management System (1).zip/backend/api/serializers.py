from rest_framework import serializers
from django.contrib.auth.models import User
from shipments.models import Shipment, ShipmentItem, ShipmentTracking
from inventory.models import Product, Category, Supplier, Stock, StockMovement
from documents.models import Document, DocumentType, ShippingDocument
from financials.models import Invoice, InvoiceItem, Payment, Currency, ExchangeRate


class UserSerializer(serializers.ModelSerializer):
    """Serializer for User model"""

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'date_joined', 'is_active']
        read_only_fields = ['id', 'date_joined']


class CategorySerializer(serializers.ModelSerializer):
    """Serializer for Category model"""

    class Meta:
        model = Category
        fields = ['id', 'name', 'description', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class SupplierSerializer(serializers.ModelSerializer):
    """Serializer for Supplier model"""

    class Meta:
        model = Supplier
        fields = [
            'id', 'name', 'contact_person', 'email', 'phone', 'address',
            'city', 'country', 'postal_code', 'tax_id', 'payment_terms',
            'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class ProductSerializer(serializers.ModelSerializer):
    """Serializer for Product model"""
    category_name = serializers.CharField(source='category.name', read_only=True)
    supplier_name = serializers.CharField(source='supplier.name', read_only=True)

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'description', 'sku', 'category', 'category_name',
            'supplier', 'supplier_name', 'unit_price', 'currency', 'weight',
            'dimensions', 'hs_code', 'origin_country', 'is_active',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'category_name', 'supplier_name']


class StockSerializer(serializers.ModelSerializer):
    """Serializer for Stock model"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_sku = serializers.CharField(source='product.sku', read_only=True)

    class Meta:
        model = Stock
        fields = [
            'id', 'product', 'product_name', 'product_sku', 'quantity',
            'reserved_quantity', 'available_quantity', 'reorder_level',
            'warehouse_location', 'last_updated'
        ]
        read_only_fields = ['id', 'available_quantity', 'last_updated']


class StockMovementSerializer(serializers.ModelSerializer):
    """Serializer for Stock Movement model"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    user_name = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = StockMovement
        fields = [
            'id', 'product', 'product_name', 'movement_type', 'quantity',
            'reference_number', 'notes', 'user', 'user_name', 'created_at'
        ]
        read_only_fields = ['id', 'created_at', 'product_name', 'user_name']


class DocumentTypeSerializer(serializers.ModelSerializer):
    """Serializer for Document Type model"""

    class Meta:
        model = DocumentType
        fields = ['id', 'name', 'description', 'is_required', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class DocumentSerializer(serializers.ModelSerializer):
    """Serializer for Document model"""
    document_type_name = serializers.CharField(source='document_type.name', read_only=True)
    uploaded_by_name = serializers.CharField(source='uploaded_by.username', read_only=True)
    file_size = serializers.SerializerMethodField()

    class Meta:
        model = Document
        fields = [
            'id', 'title', 'document_type', 'document_type_name', 'file',
            'file_size', 'description', 'uploaded_by', 'uploaded_by_name',
            'upload_date', 'is_verified', 'verification_date', 'expiry_date'
        ]
        read_only_fields = [
            'id', 'upload_date', 'document_type_name', 'uploaded_by_name', 'file_size'
        ]

    def get_file_size(self, obj):
        """Get file size in human readable format"""
        if obj.file:
            size = obj.file.size
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        return None


class ShippingDocumentSerializer(serializers.ModelSerializer):
    """Serializer for Shipping Document model"""
    document_title = serializers.CharField(source='document.title', read_only=True)

    class Meta:
        model = ShippingDocument
        fields = [
            'id', 'shipment', 'document', 'document_title', 'is_original',
            'copies_required', 'status', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'document_title']


class CurrencySerializer(serializers.ModelSerializer):
    """Serializer for Currency model"""

    class Meta:
        model = Currency
        fields = ['id', 'code', 'name', 'symbol', 'is_active', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class ExchangeRateSerializer(serializers.ModelSerializer):
    """Serializer for Exchange Rate model"""
    from_currency_code = serializers.CharField(source='from_currency.code', read_only=True)
    to_currency_code = serializers.CharField(source='to_currency.code', read_only=True)

    class Meta:
        model = ExchangeRate
        fields = [
            'id', 'from_currency', 'from_currency_code', 'to_currency',
            'to_currency_code', 'rate', 'date', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'from_currency_code', 'to_currency_code']


class ShipmentTrackingSerializer(serializers.ModelSerializer):
    """Serializer for Shipment Tracking model"""

    class Meta:
        model = ShipmentTracking
        fields = [
            'id', 'shipment', 'status', 'location', 'description',
            'timestamp', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class ShipmentItemSerializer(serializers.ModelSerializer):
    """Serializer for Shipment Item model"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_sku = serializers.CharField(source='product.sku', read_only=True)
    total_value = serializers.SerializerMethodField()

    class Meta:
        model = ShipmentItem
        fields = [
            'id', 'shipment', 'product', 'product_name', 'product_sku',
            'quantity', 'unit_price', 'total_value', 'weight', 'dimensions'
        ]
        read_only_fields = ['id', 'product_name', 'product_sku', 'total_value']

    def get_total_value(self, obj):
        """Calculate total value for the item"""
        return obj.quantity * obj.unit_price


class ShipmentSerializer(serializers.ModelSerializer):
    """Serializer for Shipment model"""
    items = ShipmentItemSerializer(many=True, read_only=True)
    tracking = ShipmentTrackingSerializer(many=True, read_only=True)
    documents = ShippingDocumentSerializer(many=True, read_only=True)
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    total_value = serializers.SerializerMethodField()
    total_weight = serializers.SerializerMethodField()

    class Meta:
        model = Shipment
        fields = [
            'id', 'shipment_number', 'shipment_type', 'status', 'origin_country',
            'destination_country', 'origin_port', 'destination_port', 'departure_date',
            'arrival_date', 'estimated_delivery', 'carrier', 'tracking_number',
            'container_number', 'seal_number', 'total_value', 'total_weight',
            'currency', 'incoterms', 'special_instructions', 'created_by',
            'created_by_name', 'created_at', 'updated_at', 'items', 'tracking', 'documents'
        ]
        read_only_fields = [
            'id', 'shipment_number', 'created_at', 'updated_at', 'created_by_name',
            'total_value', 'total_weight', 'items', 'tracking', 'documents'
        ]

    def get_total_value(self, obj):
        """Calculate total shipment value"""
        return sum(item.quantity * item.unit_price for item in obj.items.all())

    def get_total_weight(self, obj):
        """Calculate total shipment weight"""
        return sum(item.weight * item.quantity for item in obj.items.all() if item.weight)


class InvoiceItemSerializer(serializers.ModelSerializer):
    """Serializer for Invoice Item model"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_sku = serializers.CharField(source='product.sku', read_only=True)
    line_total = serializers.SerializerMethodField()

    class Meta:
        model = InvoiceItem
        fields = [
            'id', 'invoice', 'product', 'product_name', 'product_sku',
            'description', 'quantity', 'unit_price', 'line_total', 'tax_rate', 'tax_amount'
        ]
        read_only_fields = ['id', 'product_name', 'product_sku', 'line_total']

    def get_line_total(self, obj):
        """Calculate line total including tax"""
        subtotal = obj.quantity * obj.unit_price
        return subtotal + obj.tax_amount


class InvoiceSerializer(serializers.ModelSerializer):
    """Serializer for Invoice model"""
    items = InvoiceItemSerializer(many=True, read_only=True)
    shipment_number = serializers.CharField(source='shipment.shipment_number', read_only=True)
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    currency_code = serializers.CharField(source='currency.code', read_only=True)
    subtotal = serializers.SerializerMethodField()
    total_tax = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            'id', 'invoice_number', 'invoice_type', 'shipment', 'shipment_number',
            'customer_name', 'customer_address', 'customer_email', 'invoice_date',
            'due_date', 'currency', 'currency_code', 'subtotal', 'total_tax',
            'total_amount', 'status', 'notes', 'created_by', 'created_by_name',
            'created_at', 'updated_at', 'items'
        ]
        read_only_fields = [
            'id', 'invoice_number', 'created_at', 'updated_at', 'shipment_number',
            'created_by_name', 'currency_code', 'subtotal', 'total_tax', 'items'
        ]

    def get_subtotal(self, obj):
        """Calculate invoice subtotal"""
        return sum(item.quantity * item.unit_price for item in obj.items.all())

    def get_total_tax(self, obj):
        """Calculate total tax amount"""
        return sum(item.tax_amount for item in obj.items.all())


class PaymentSerializer(serializers.ModelSerializer):
    """Serializer for Payment model"""
    invoice_number = serializers.CharField(source='invoice.invoice_number', read_only=True)
    currency_code = serializers.CharField(source='currency.code', read_only=True)
    processed_by_name = serializers.CharField(source='processed_by.username', read_only=True)

    class Meta:
        model = Payment
        fields = [
            'id', 'payment_number', 'invoice', 'invoice_number', 'amount',
            'currency', 'currency_code', 'payment_method', 'payment_date',
            'reference_number', 'status', 'notes', 'processed_by',
            'processed_by_name', 'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'payment_number', 'created_at', 'updated_at', 'invoice_number',
            'currency_code', 'processed_by_name'
        ]


# Nested serializers for detailed views
class ShipmentDetailSerializer(ShipmentSerializer):
    """Detailed serializer for Shipment with all related data"""
    items = ShipmentItemSerializer(many=True, read_only=True)
    tracking = ShipmentTrackingSerializer(many=True, read_only=True)
    documents = ShippingDocumentSerializer(many=True, read_only=True)
    invoices = InvoiceSerializer(many=True, read_only=True)


class InvoiceDetailSerializer(InvoiceSerializer):
    """Detailed serializer for Invoice with all related data"""
    items = InvoiceItemSerializer(many=True, read_only=True)
    payments = PaymentSerializer(many=True, read_only=True)
    shipment = ShipmentSerializer(read_only=True)


class ProductDetailSerializer(ProductSerializer):
    """Detailed serializer for Product with stock information"""
    stock = StockSerializer(read_only=True)
    recent_movements = StockMovementSerializer(many=True, read_only=True, source='stockmovement_set')

    class Meta(ProductSerializer.Meta):
        fields = ProductSerializer.Meta.fields + ['stock', 'recent_movements']
