from django.apps import AppConfig


class ApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api'
    verbose_name = 'API'

    def ready(self):
        """
        Perform initialization tasks when the app is ready.
        This method is called once Django has loaded all models.
        """
        pass
